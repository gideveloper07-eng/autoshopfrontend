import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:intl/intl.dart';

import '../../services/activity_service.dart';
import '../../services/api_service.dart';
import 'challan_grid_screen.dart';

// ─────────────────────────────────────────────────────────────────────────────
// New Challan Form
// Layout exactly matches frm_challan.aspx column order from screenshots
// ─────────────────────────────────────────────────────────────────────────────
class ChallanFormScreen extends StatefulWidget {
  /// Pass [editSp462] to open an existing challan for editing.
  final String? editSp462;
  const ChallanFormScreen({super.key, this.editSp462});
  @override
  State<ChallanFormScreen> createState() => _ChallanFormScreenState();
}

class _ChallanFormScreenState extends State<ChallanFormScreen>
    with SingleTickerProviderStateMixin {
  List<Map<String, dynamic>> _accessoryGridRows = [];
  bool _loadingAccessoryGrid = false;
  // ── Theme colors ──────────────────────────────────────────────────────────
  static const Color _accent = Color(0xFF0D5BB5); // MyAutoShop accent blue
  static const Color _primary = Color(0xFF0A1B32);
  static const Color _secondary = Color(
    0xFF0D55A7,
  ); // MyAutoShop secondary blue
  static const Color _border = Color(0xFFD7E3F4);

  // ── Form & scroll ─────────────────────────────────────────────────────────
  final _formKey = GlobalKey<FormState>();
  final _scrollCtrl = ScrollController();
  bool _loading = true;
  bool _saving = false;
  String? _initError;
  late final AnimationController _animCtrl;
  late final Animation<double> _fadeAnim;
  final Set<String> _customerFinancialFields = <String>{};
  // ── Edit mode ─────────────────────────────────────────────────────────────
  bool get _isEditing =>
      widget.editSp462 != null && widget.editSp462!.isNotEmpty;
  String _editUnq = '0'; // holds the real sp_462 guid when editing
  // ── Finance field enable/disable ───────────────────────────────────────
  bool get _financeFieldsDisabled {
    return _finType.trim().toLowerCase() == 'cash';
  }

  // ── Receipt grid ──────────────────────────────────────────────────────────
  List<Map<String, dynamic>> _receiptRows = [];
  double _receiptTotal = 0;
  double _receiptFinanceAmt = 0;
  double _receiptCustAmt = 0;
  bool _loadingReceipts = false;

  // ── City and Area lists ───────────────────────────────────────────────────
  List<Map<String, dynamic>> _cities = [];
  List<Map<String, dynamic>> _areas = [];

  // ── Challan type & date ───────────────────────────────────────────────────
  String _challanType = 'Customer Challan';
  DateTime _challanDate = DateTime.now();
  int _challanNo = 0;
  static const _challanTypes = [
    'Customer Challan',
    'CSD Challan',
    'Inter Delear Challan',
    'Stock to Branch',
    'Used Car',
  ];

  // ── Dropdown data ─────────────────────────────────────────────────────────
  List<Map<String, dynamic>> _customers = [];
  List<Map<String, dynamic>> _models = [];
  List<Map<String, dynamic>> _variants = [];
  List<Map<String, dynamic>> _colors = [];
  List<Map<String, dynamic>> _vins = [];
  List<Map<String, dynamic>> _states = [];
  List<Map<String, dynamic>> _branches = [];
  List<Map<String, dynamic>> _rtoCities = [];
  List<Map<String, dynamic>> _hpnList = [];
  List<Map<String, dynamic>> _insuranceCos = [];
  List<Map<String, dynamic>> _otherOptions = [];

  // ── Selected IDs ──────────────────────────────────────────────────────────
  String? _custId, _modelId, _variantId, _colorId, _vinNo;
  String? _stateId, _branchId, _rtoCityId, _hpnId, _gstUnq, _insuranceCompanyId;
  String? _cityId; // selected city from Add City popup
  String? _areaId; // selected area from Add Area popup
  String _cityName = '';
  String _areaName = '';
  bool _loadingVar = false, _loadingCol = false, _loadingVin = false;

  // ── Left column controllers ───────────────────────────────────────────────
  final _locationCtrl = TextEditingController(text: 'SHOWROOM');
  final _panCtrl = TextEditingController();
  final _gstinCtrl = TextEditingController();
  final _engineCtrl = TextEditingController();

  // ── Middle column controllers ─────────────────────────────────────────────
  final _mobileCtrl = TextEditingController();
  final _nomineeCtrl = TextEditingController();
  final _scCtrl = TextEditingController();

  // ── Right column controllers ──────────────────────────────────────────────
  final _addressCtrl = TextEditingController();
  final _emailCtrl = TextEditingController();
  final _aadharCtrl = TextEditingController();
  final _ageCtrl = TextEditingController();
  String _relation = 'CHOOSE RELATIONSHIP';
  final _tlCtrl = TextEditingController();
  final _managerCtrl = TextEditingController();
  String _title = 'MR';
  final _fatherCtrl = TextEditingController();

  // ── Finance ───────────────────────────────────────────────────────────────
  String _finType = 'In House';
  final _hypCtrl = TextEditingController();
  final _branchNameCtrl = TextEditingController();
  final _netDisCtrl = TextEditingController(text: '0.00');
  final _loanAmtCtrl = TextEditingController(text: '0.00');

  // ── HPN (Hypothecation) parent + child branch ─────────────────────────────
  String? _hpnParentId; // sp_605 — mhpn (parent unq)
  String? _hpnChildId; // sp_523 — hypothecation child branch
  List<Map<String, dynamic>> _hpnBranches = [];

  // ── Discounts ─────────────────────────────────────────────────────────────
  String _corpYn = 'No', _corpGiven = 'No';
  String _exchYn = 'No', _exchGiven = 'No';
  String _dealYn = 'No', _dealGiven = 'No';
  String _loyYn = 'No', _loyGiven = 'No';
  final _corpValCtrl = TextEditingController(text: '0.00');
  final _exchValCtrl = TextEditingController(text: '0.00');
  final _dealValCtrl = TextEditingController(text: '0.00');
  final _loyValCtrl = TextEditingController(text: '0.00');
  final _exShowCtrl = TextEditingController(text: '0.00');
  final _schemesCtrl = TextEditingController(text: '0.00');
  final _subTotalCtrl = TextEditingController(text: '0.00');

  // ── Insurance ─────────────────────────────────────────────────────────────
  String _insType = 'In House';
  bool _epAdd = false, _rtiAdd = false, _cmAdd = false;

  // Insurance master percentages. These are loaded from the insurance
  // company master and are applied to the percentage fields only when the
  // corresponding Amount Add checkbox is checked, matching ASP.NET.
  double? _epMasterRate;
  double? _rtiMasterRate;
  double? _cmMasterRate;
  final _insDisCtrl = TextEditingController(text: '0.00');
  final _insExShowCtrl = TextEditingController(text: '0.00');
  final _cessCtrl = TextEditingController(text: '0');
  final _cessAmtCtrl = TextEditingController(text: '0.00');
  final _idvCtrl = TextEditingController(text: '5');
  final _idvAmtCtrl = TextEditingController(text: '0.00');
  final _afterIdvCtrl = TextEditingController(text: '0.00');
  final _insAmtCtrl = TextEditingController(text: '0.00');
  // Display-only Insurance Amount after applying Insurance % (OD amount).
  // Final Insurance Amount is kept separately in _finalInsCtrl/_insAmtFinalCtrl.
  final _insCalcAmtCtrl = TextEditingController(text: '0.00');
  final _insPerCtrl = TextEditingController(text: '0.00');
  final _finalInsCtrl = TextEditingController(text: '0.00');
  final _disAmtCtrl = TextEditingController(text: '0.00');
  final _afterDisCtrl = TextEditingController(text: '0.00');
  final _cngPerCtrl = TextEditingController(text: '0.00');
  final _cngAmtCtrl = TextEditingController(text: '0.00');
  final _paCoverCtrl = TextEditingController(text: '0.00');
  final _paAmtCtrl = TextEditingController(text: '0.00');
  final _zdCtrl = TextEditingController(text: '0.00');
  final _zdAmtCtrl = TextEditingController(text: '0.00');
  final _epCtrl = TextEditingController(text: '0.00');
  final _epAmtCtrl = TextEditingController(text: '0.00');
  final _thirdPartyCtrl = TextEditingController(text: '0.00');
  final _pbCtrl = TextEditingController(text: '0.00');
  final _kpCtrl = TextEditingController(text: '0.00');
  final _kpAmtCtrl = TextEditingController(text: '0.00');
  final _paidDrvCtrl = TextEditingController(text: '0.00');
  final _afterPdCtrl = TextEditingController(text: '0.00');
  final _rtiCtrl = TextEditingController(text: '0.00');
  final _rtiAmtCtrl = TextEditingController(text: '0.00');
  final _cmCtrl = TextEditingController(text: '0.00');
  final _cmAmtCtrl = TextEditingController(text: '0.00');
  final _cgstCtrl = TextEditingController(text: '0.00');
  final _sgstCtrl = TextEditingController(text: '0.00');
  final _gstAmtCtrl = TextEditingController(text: '0.00');
  final _addLessCtrl = TextEditingController(text: '0.00');
  final _ncbCtrl = TextEditingController(text: '0.00');
  final _insAmtFinalCtrl = TextEditingController(text: '0.00');

  // ── RTO ───────────────────────────────────────────────────────────────────
  String _rtoFrom = 'In House';
  bool _scrappage = false;
  double _scrappagePercent = 0.0;
  double _scrappageAmount = 0.0;

  final _rtoExShowCtrl = TextEditingController(text: '0.00');
  final _rtoRateCtrl = TextEditingController(text: '0.00');
  final _rtoSurCtrl = TextEditingController(text: '0.00');
  final _greenTaxCtrl = TextEditingController(text: '0.00');
  final _regFeeCtrl = TextEditingController(text: '0.00');
  final _hpnRtoCtrl = TextEditingController(text: '0.00');
  // Master HPN amount from RTO data. Cash finance displays/uses zero.
  double _hpnMasterAmount = 0.0;

  void _setHpnRtoMaster(dynamic value) {
    _hpnMasterAmount = double.tryParse(value?.toString() ?? '') ?? 0.0;
    _hpnRtoCtrl.text = _finType == 'Cash' ? '0.00' : _f(_hpnMasterAmount);
  }

  final _dupCtrl = TextEditingController(text: '0.00');
  final _smartCtrl = TextEditingController(text: '0.00');
  final _otherRtoCtrl = TextEditingController(text: '0.00');
  final _bhPerCtrl = TextEditingController(text: '0.00');
  final _bhYearCtrl = TextEditingController();

  // BH calculation master values from RH_PA.
  // Jchallan.js uses:
  //   bhyearpa      -> completion/period denominator (normally 15)
  //   bhmultiplepa  -> BH multiplier (normally 1.25)
  //   bhaftergstamt -> whether the GST-inclusive BH formula is used.
  double _bhPayYear = 15.0;
  double _bhYearMultiple = 1.25;
  bool _bhAfterGst = false;

  final _rtoTempCtrl = TextEditingController(text: '0.00');
  final _rtoAmtCtrl = TextEditingController(text: '0.00');

  // ── Others ────────────────────────────────────────────────────────────────
  final _oth1Ctrl = TextEditingController();
  final _oth2Ctrl = TextEditingController();
  final _oth3Ctrl = TextEditingController();
  final _amt1Ctrl = TextEditingController(text: '0.00');
  final _amt2Ctrl = TextEditingController(text: '0.00');
  final _amt3Ctrl = TextEditingController(text: '0.00');

  // ── Bottom amounts ────────────────────────────────────────────────────────
  final _workshopInvNo = TextEditingController();
  final _workshopInvAmt = TextEditingController(text: '0.00');
  final _trcCtrl = TextEditingController(text: '0.00');
  final _compAccCtrl = TextEditingController(text: '0.00');
  final _ownAccCtrl = TextEditingController(text: '0.00');
  final _accAmtCtrl = TextEditingController(text: '0.00');
  final _warrantyCtrl = TextEditingController(text: '0.00');
  final _warrantyYrCtrl = TextEditingController();
  final _rsaCtrl = TextEditingController(text: '0.00');
  String _sotType = 'SOT';
  final _sotAmtCtrl = TextEditingController(text: '0.00');
  final _fastTagCtrl = TextEditingController(text: '0.00');
  final _tcsCtrl = TextEditingController(text: '0.00');
  double _tcsPercentage = 0.0;
  bool _tcsCal = false;
  final _totalCtrl = TextEditingController(text: '0.00');

  // ── Receipt / balance totals ───────────────────────────────────────────────
  final _hpnReceivedCtrl = TextEditingController(text: '0.00');
  final _hpnBalanceCtrl = TextEditingController(text: '0.00');
  final _customerReceivedCtrl = TextEditingController(text: '0.00');
  final _customerBalanceCtrl = TextEditingController(text: '0.00');
  final _receivedCtrl = TextEditingController(text: '0.00');
  final _balanceCtrl = TextEditingController(text: '0.00');

  // ── Remarks ───────────────────────────────────────────────────────────────
  final _remarkCtrl = TextEditingController();
  final _appRemarkCtrl = TextEditingController();
  final _rejRemarkCtrl = TextEditingController();

  Future<String?> _getLoggedInUserBranch() async {
    try {
      final token = await ApiService.getToken();

      if (token == null || token.isEmpty) {
        debugPrint('❌ JWT token not found');
        return null;
      }

      final parts = token.split('.');

      if (parts.length != 3) {
        debugPrint('❌ Invalid JWT token');
        return null;
      }

      final payload = utf8.decode(
        base64Url.decode(base64Url.normalize(parts[1])),
      );

      final decoded = jsonDecode(payload);

      debugPrint('========== JWT PAYLOAD ==========');
      debugPrint(decoded.toString());
      debugPrint('=================================');

      // IMPORTANT:
      // Backend creates JWT using branchUnq
      final branchUnq = decoded['branchUnq'] ?? decoded['branchunq'];

      debugPrint('JWT branchUnq = $branchUnq');

      if (branchUnq == null || branchUnq.toString().isEmpty) {
        debugPrint('❌ branchUnq not found in JWT');
        return null;
      }

      return branchUnq.toString();
    } catch (e) {
      debugPrint('❌ Error reading branch from JWT: $e');
      return null;
    }
  }

  Future<void> _loadAccessoriesAmount(String customerId) async {
    if (customerId.trim().isEmpty) return;

    try {
      final data = await ApiService.getAccessoriesAmount(customerId);

      debugPrint('LOAD ACCESSORIES AMOUNT DATA: $data');

      if (!mounted) return;

      final companyAmount =
          double.tryParse((data['companyAccessories'] ?? 0).toString()) ?? 0.0;

      final ownAmount =
          double.tryParse((data['ownAccessories'] ?? 0).toString()) ?? 0.0;

      setState(() {
        _compAccCtrl.text = companyAmount.toStringAsFixed(2);
        _ownAccCtrl.text = ownAmount.toStringAsFixed(2);
        _accAmtCtrl.text = (companyAmount + ownAmount).toStringAsFixed(2);
      });

      debugPrint('Company Accessories: ${_compAccCtrl.text}');
      debugPrint('Own Accessories: ${_ownAccCtrl.text}');
      debugPrint('Total Accessories: ${_accAmtCtrl.text}');
    } catch (e, stackTrace) {
      debugPrint('LOAD ACCESSORIES AMOUNT ERROR: $e');
      debugPrint(stackTrace.toString());
    }
  }

  Widget _accessoryAmountRow(String label, String amount) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: isDark ? const Color(0xFF15253A) : const Color(0xFFF0F6FF),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
          color: isDark
              ? Colors.white.withValues(alpha: 0.08)
              : const Color(0xFFD7E3F4),
        ),
      ),
      child: Row(
        children: [
          Expanded(
            child: Text(
              label,
              style: TextStyle(
                fontSize: 14,
                fontWeight: FontWeight.w600,
                color: isDark
                    ? const Color(0xFFB0C4DE)
                    : const Color(0xFF0A1B32),
              ),
            ),
          ),
          Text(
            '₹ $amount',
            style: const TextStyle(
              fontSize: 16,
              fontWeight: FontWeight.bold,
              color: Color(0xFF0D5BB5),
            ),
          ),
        ],
      ),
    );
  }

  // ─────────────────────────────────────────────────────────────────────────
  @override
  void initState() {
    super.initState();

    ActivityService.logActivity(
      activityType: 'SCREEN',
      activityName: 'ChallanFormScreen',
      screenName: 'ChallanFormScreen',
    );

    _animCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 400),
    );

    _fadeAnim = CurvedAnimation(parent: _animCtrl, curve: Curves.easeOut);

    _loadDropdowns();
  }

  @override
  void dispose() {
    _animCtrl.dispose();
    _scrollCtrl.dispose();
    for (final c in [
      _locationCtrl,
      _panCtrl,
      _gstinCtrl,
      _engineCtrl,
      _mobileCtrl,
      _nomineeCtrl,
      _scCtrl,
      _addressCtrl,
      _emailCtrl,
      _aadharCtrl,
      _ageCtrl,
      _tlCtrl,
      _managerCtrl,
      _fatherCtrl,
      _hypCtrl,
      _branchNameCtrl,
      _netDisCtrl,
      _loanAmtCtrl,
      _corpValCtrl,
      _exchValCtrl,
      _dealValCtrl,
      _loyValCtrl,
      _exShowCtrl,
      _schemesCtrl,
      _subTotalCtrl,
      _insDisCtrl,
      _insExShowCtrl,
      _cessCtrl,
      _cessAmtCtrl,
      _idvCtrl,
      _idvAmtCtrl,
      _afterIdvCtrl,
      _insAmtCtrl,
      _insCalcAmtCtrl,
      _insPerCtrl,
      _finalInsCtrl,
      _disAmtCtrl,
      _afterDisCtrl,
      _cngPerCtrl,
      _cngAmtCtrl,
      _paCoverCtrl,
      _paAmtCtrl,
      _zdCtrl,
      _zdAmtCtrl,
      _epCtrl,
      _epAmtCtrl,
      _thirdPartyCtrl,
      _pbCtrl,
      _kpCtrl,
      _kpAmtCtrl,
      _paidDrvCtrl,
      _afterPdCtrl,
      _rtiCtrl,
      _rtiAmtCtrl,
      _cmCtrl,
      _cmAmtCtrl,
      _cgstCtrl,
      _sgstCtrl,
      _gstAmtCtrl,
      _addLessCtrl,
      _ncbCtrl,
      _insAmtFinalCtrl,
      _rtoExShowCtrl,
      _rtoRateCtrl,
      _rtoSurCtrl,
      _greenTaxCtrl,
      _regFeeCtrl,
      _hpnRtoCtrl,
      _dupCtrl,
      _smartCtrl,
      _otherRtoCtrl,
      _bhPerCtrl,
      _bhYearCtrl,
      _rtoTempCtrl,
      _rtoAmtCtrl,
      _oth1Ctrl,
      _oth2Ctrl,
      _oth3Ctrl,
      _amt1Ctrl,
      _amt2Ctrl,
      _amt3Ctrl,
      _workshopInvNo,
      _workshopInvAmt,
      _trcCtrl,
      _compAccCtrl,
      _ownAccCtrl,
      _accAmtCtrl,
      _warrantyCtrl,
      _warrantyYrCtrl,
      _rsaCtrl,
      _sotAmtCtrl,
      _fastTagCtrl,
      _tcsCtrl,
      _totalCtrl,
      _hpnReceivedCtrl,
      _hpnBalanceCtrl,
      _customerReceivedCtrl,
      _customerBalanceCtrl,
      _receivedCtrl,
      _balanceCtrl,
      _remarkCtrl,
      _appRemarkCtrl,
      _rejRemarkCtrl,
    ]) {
      c.dispose();
    }
    super.dispose();
  }

  // ── Load dropdowns ────────────────────────────────────────────────────────
  Future<void> _loadDropdowns() async {
    setState(() => _loading = true);

    try {
      // ============================================================
      // GET LOGGED-IN USER BRANCH FROM JWT
      // ============================================================

      final loggedInBranchId = await _getLoggedInUserBranch();

      debugPrint('======================================');
      debugPrint('Logged-in Branch ID: $loggedInBranchId');
      debugPrint('======================================');

      // ============================================================
      // LOAD ALL DROPDOWNS
      // ============================================================

      final r = await Future.wait([
        ApiService.getChallanCustomersByType('booking'),
        ApiService.getChallanModels(),
        ApiService.getChallanRtoCities(),
        ApiService.getChallanHpnList(),
        ApiService.getChallanStates(),
        ApiService.getChallanBranches(),
        ApiService.getChallanInsuranceCompanies(),
        ApiService.getChallanNextNo().then(
          (v) => [
            {'n': v},
          ],
        ),
        ApiService.getChallanCities(),
        ApiService.getChallanAreas(),
        ApiService.getChallanOthers(),
      ]);

      if (!mounted) return;

      final branches = r[5] as List<Map<String, dynamic>>;

      // ============================================================
      // CHECK WHETHER JWT BRANCH EXISTS IN BRANCH LIST
      // ============================================================

      String? selectedBranchId;

      if (loggedInBranchId != null) {
        final branchExists = branches.any(
          (branch) => branch['data']?.toString() == loggedInBranchId,
        );

        debugPrint('JWT branch exists in branch list: $branchExists');

        if (branchExists) {
          selectedBranchId = loggedInBranchId;
        }
      }

      // ============================================================
      // DEBUG BRANCH LIST
      // ============================================================

      debugPrint('========== BRANCH LIST ==========');

      for (final branch in branches) {
        debugPrint(
          'Branch ID: ${branch['data']} | '
          'Branch Name: ${branch['value']}',
        );
      }

      debugPrint('Selected Branch ID: $selectedBranchId');

      debugPrint('=================================');

      // ============================================================
      // SET DATA
      // ============================================================

      final states = r[4] as List<Map<String, dynamic>>;

      // Find Rajasthan from the state master
      String? defaultStateId;

      for (final state in states) {
        final stateName = (state['value'] ?? state['name'] ?? '')
            .toString()
            .trim()
            .toUpperCase();

        if (stateName == 'RAJASTHAN') {
          defaultStateId = state['data']?.toString();
          break;
        }
      }

      debugPrint('Default State ID: $defaultStateId');

      setState(() {
        _customers = r[0] as List<Map<String, dynamic>>;
        _models = r[1] as List<Map<String, dynamic>>;
        _rtoCities = r[2] as List<Map<String, dynamic>>;
        _hpnList = r[3] as List<Map<String, dynamic>>;
        _otherOptions = r[10] as List<Map<String, dynamic>>;
        _states = states;

        _branches = branches;
        _insuranceCos = r[6] as List<Map<String, dynamic>>;
        debugPrint('========================================');
        debugPrint('INSURANCE COMPANY MASTER');
        debugPrint('COUNT = ${_insuranceCos.length}');

        for (final insurance in _insuranceCos) {
          debugPrint(
            'Insurance ID: ${insurance['data']} | '
            'Name: ${insurance['value']} | '
            'FULL: $insurance',
          );
        }

        debugPrint('========================================');
        _challanNo = ((r[7] as List).first as Map)['n'] as int? ?? 1;

        _cities = r[8] as List<Map<String, dynamic>>;
        _areas = r[9] as List<Map<String, dynamic>>;

        _branchId = selectedBranchId;

        // DEFAULT STATE = RAJASTHAN
        // Do not overwrite state when editing an existing challan.
        if (!_isEditing && defaultStateId != null) {
          _stateId = defaultStateId;
        }

        _loading = false;
      });

      debugPrint('FINAL _stateId = $_stateId');
      debugPrint('FINAL _branchId = $_branchId');

      debugPrint('FINAL _branchId = $_branchId');

      _animCtrl.forward();
    } catch (e) {
      debugPrint('❌ _loadDropdowns ERROR: $e');

      if (!mounted) return;

      setState(() {
        _initError = e.toString();
        _loading = false;
      });
    }
  }

  /// Convert challan type display string → API type key
  String _challanTypeToApiType(String type) {
    switch (type) {
      case 'CSD Challan':
        return 'csd';
      case 'Inter Delear Challan':
        return 'dealer';
      case 'Stock to Branch':
        return 'stb';
      case 'Used Car':
        return 'usedcar';
      default:
        return 'booking';
    }
  }

  /// Reload customers when challan type changes
  Future<void> _reloadCustomersByType(String type) async {
    setState(() {
      _customers = [];
      _custId = null;
    });
    try {
      final list = await ApiService.getChallanCustomersByType(
        _challanTypeToApiType(type),
      );
      if (!mounted) return;
      setState(() => _customers = list);
    } catch (e) {
      print('_reloadCustomersByType ERROR: $e');
    }
  }

  /// Load existing challan data for edit mode
  Future<void> _loadEditData() async {
    final data = await ApiService.loadChallanForEdit(widget.editSp462!);
    if (data == null || !mounted) return;
    _populateFormFromData(data);
  }

  /// Populate all controllers from an Edit API response
  void _populateFormFromData(Map<String, dynamic> d) {
    setState(() {
      _editUnq = d['unq']?.toString() ?? widget.editSp462 ?? '0';

      // ── dates ──
      final dateStr = d['date']?.toString() ?? d['cdate']?.toString() ?? '';
      if (dateStr.isNotEmpty) {
        try {
          final parts = dateStr.split('/');
          if (parts.length == 3) {
            _challanDate = DateTime(
              int.parse(parts[2]),
              int.parse(parts[1]),
              int.parse(parts[0]),
            );
          }
        } catch (_) {}
      }
      _challanNo = int.tryParse(d['challanno']?.toString() ?? '') ?? _challanNo;
      _challanType = d['challantype']?.toString().isNotEmpty == true
          ? d['challantype'].toString()
          : _challanType;

      // ── customer/vehicle ──
      _custId = d['custname']?.toString();
      _modelId = d['model']?.toString();
      _variantId = d['variant']?.toString();
      _colorId = d['color']?.toString();
      _vinNo = d['vinno']?.toString();
      _stateId = d['state_list']?.toString();
      _branchId = d['branchid']?.toString();

      // ── text fields ──
      _title = d['title']?.toString().isNotEmpty == true
          ? d['title'].toString()
          : 'MR';
      _addressCtrl.text = d['address']?.toString() ?? '';
      _mobileCtrl.text = d['mobileno']?.toString() ?? '';
      _emailCtrl.text =
          d['fathername']?.toString() ?? ''; // fathername = email in SP alias
      _fatherCtrl.text = d['fathername']?.toString() ?? '';
      _aadharCtrl.text = d['aadharcard']?.toString() ?? '';
      _panCtrl.text = d['panno']?.toString() ?? '';
      _gstinCtrl.text = d['gstin']?.toString() ?? '';
      _nomineeCtrl.text = d['nomineename']?.toString() ?? '';
      _ageCtrl.text = d['age']?.toString() ?? '';
      _relation = d['relation']?.toString().isNotEmpty == true
          ? d['relation'].toString()
          : 'CHOOSE RELATIONSHIP';
      _engineCtrl.text = d['engineno']?.toString() ?? '';
      _scCtrl.text = d['scunq']?.toString() ?? '';
      _tlCtrl.text = d['tlunq']?.toString() ?? '';
      _managerCtrl.text = d['managunq']?.toString() ?? '';

      // ── finance ──
      final finTypeRaw = d['financetype']?.toString() ?? '';
      _finType = finTypeRaw == 'in'
          ? 'In House'
          : finTypeRaw == 'out'
          ? 'Out House'
          : finTypeRaw == 'Cash'
          ? 'Cash'
          : 'In House';
      _hpnParentId = d['hpnp']?.toString();
      _hpnChildId = d['hypothecation']?.toString();
      _loanAmtCtrl.text = _f(d['bankamt']);
      _netDisCtrl.text = _f(d['bankamt']);

      // ── discounts ──
      _corpYn = (d['Corporateyn'] ?? d['corporateyn'] ?? 'out') == 'in'
          ? 'Yes'
          : 'No';
      _corpValCtrl.text = _f(d['Corporateamount'] ?? d['corporateamount']);
      _corpGiven = (d['Corporategiven'] ?? d['corporategiven'] ?? '') == 'Yes'
          ? 'Yes'
          : 'No';
      _exchYn = (d['Exchangeyn'] ?? d['exchangeyn'] ?? 'out') == 'In'
          ? 'Yes'
          : 'No';
      _exchValCtrl.text = _f(d['Exchangeamount'] ?? d['exchangeamount']);
      _exchGiven = (d['Exchangegiven'] ?? d['exchangegiven'] ?? '') == 'Yes'
          ? 'Yes'
          : 'No';
      _dealYn = (d['dealeryn'] ?? 'out') == 'in' ? 'Yes' : 'No';
      _dealValCtrl.text = _f(d['dealeramount']);
      _dealGiven = (d['dealergiven'] ?? '') == 'Yes' ? 'Yes' : 'No';
      _loyYn = (d['Loyalityyn'] ?? d['loyalityyn'] ?? 'out') == 'In'
          ? 'Yes'
          : 'No';
      _loyValCtrl.text = _f(d['Loyalityamount'] ?? d['loyalityamount']);
      _loyGiven = (d['Loyalitygiven'] ?? d['loyalitygiven'] ?? '') == 'Yes'
          ? 'Yes'
          : 'No';
      _exShowCtrl.text = _f(d['ExshowRoomPrice'] ?? d['exshowroomprice']);
      _schemesCtrl.text = _f(d['lessofallencashmentschemne']);
      _subTotalCtrl.text = _f(d['subtotal']);

      // ── insurance ──
      final insTypeRaw = d['instype']?.toString() ?? '';
      _insType = insTypeRaw == 'in' ? 'In House' : 'Out House';
      _insExShowCtrl.text = _f(d['insshowroom']);
      _cessCtrl.text = _f(d['CESS'] ?? d['cess']);
      _cessAmtCtrl.text = _f(d['Amount'] ?? d['amount'] ?? d['cessamt']);
      _idvCtrl.text = _f(d['Idv'] ?? d['idv']);
      _idvAmtCtrl.text = _f(d['IdvAmount'] ?? d['idvamount']);
      _afterIdvCtrl.text = _f(d['afteridvamt']);
      _insAmtCtrl.text = _f(d['InsperAmount'] ?? d['insperamount']);
      _insCalcAmtCtrl.text = _f(d['InsperAmount'] ?? d['insperamount']);
      _insPerCtrl.text = _f(
        d['InsurancePercentage'] ?? d['insurancepercentage'],
      );
      _finalInsCtrl.text = _f(d['InsuranceAmount'] ?? d['insuranceamount']);
      _insDisCtrl.text = _f(d['DiscountPrecentage'] ?? d['discountprecentage']);
      _disAmtCtrl.text = _f(d['DiscountAmount'] ?? d['discountamount']);
      _afterDisCtrl.text = _f(d['afterdisamtamt']);
      _thirdPartyCtrl.text = _f(d['ThirdParty'] ?? d['thirdparty']);
      _paCoverCtrl.text = _f(d['PACover'] ?? d['pacover']);
      _paAmtCtrl.text = _f(d['pacoveramt']);
      _zdCtrl.text = _f(d['ZD'] ?? d['zd']);
      _zdAmtCtrl.text = _f(d['zdamt']);
      _epCtrl.text = _f(d['ep']);
      _epAmtCtrl.text = _f(d['epamt']);
      _pbCtrl.text = _f(d['PB'] ?? d['pb']);
      _kpCtrl.text = _f(d['KP'] ?? d['kp']);
      _paidDrvCtrl.text = _f(d['PaidDriver'] ?? d['paiddriver']);
      _afterPdCtrl.text = _f(d['amtafterpaiddriver']);
      _rtiCtrl.text = _f(d['rti']);
      _rtiAmtCtrl.text = _f(d['rtiamt']);
      _cmCtrl.text = _f(d['cm']);
      _cmAmtCtrl.text = _f(d['cmamt']);
      _gstUnq = d['gstunq']?.toString();
      _cgstCtrl.text = _f(d['cgst']);
      _sgstCtrl.text = _f(d['sgst']);
      _gstAmtCtrl.text = _f(d['GSTAmount'] ?? d['gstamount']);
      _addLessCtrl.text = _f(d['addless']);
      _ncbCtrl.text = _f(d['NCB'] ?? d['ncb']);
      _cngPerCtrl.text = _f(d['cngp']);
      _cngAmtCtrl.text = _f(d['cngamt']);

      // ── RTO ──
      final rtoFromRaw = d['rtofrom']?.toString() ?? '';
      _rtoFrom = rtoFromRaw == 'in'
          ? 'In House'
          : rtoFromRaw == 'out'
          ? 'Out House'
          : rtoFromRaw == 'bh'
          ? 'BH'
          : 'In House';
      _scrappage = (d['scrapper']?.toString() ?? '0') != '0';
      _rtoCityId = d['rtounq']?.toString();
      _rtoExShowCtrl.text = _f(d['rtoexshow']);
      _rtoRateCtrl.text = _f(d['RTORate'] ?? d['rtorate']);
      _rtoSurCtrl.text = _f(d['RTOTaxSurcharge'] ?? d['rtotaxsurcharge']);
      _greenTaxCtrl.text = _f(d['GreenTax'] ?? d['greentax']);
      _regFeeCtrl.text = _f(d['RegFee'] ?? d['regfee']);
      _setHpnRtoMaster(d['HPN'] ?? d['hpn']);
      _dupCtrl.text = _f(d['Duplicate'] ?? d['duplicate']);
      _smartCtrl.text = _f(d['SmartCard'] ?? d['smartcard']);
      _otherRtoCtrl.text = _f(d['Other'] ?? d['other']);
      _rtoTempCtrl.text = _f(d['RTO TEMP'] ?? d['rto temp']);
      _bhPerCtrl.text = _f(d['bhperc']);
      _bhYearCtrl.text = d['bhyear']?.toString() ?? '';

      _bhPayYear = double.tryParse(d['bhpayear']?.toString() ?? '') ?? 15.0;
      _bhYearMultiple =
          double.tryParse(d['bhyearmultiple']?.toString() ?? '') ?? 1.25;

      final bhAfterGstRaw = d['bhaftergst']?.toString().trim().toLowerCase();
      _bhAfterGst =
          bhAfterGstRaw == 'true' ||
          bhAfterGstRaw == '1' ||
          bhAfterGstRaw == 'yes';

      _rtoAmtCtrl.text = _f(d['RTOAmount'] ?? d['rtoamount']);

      // ── others ──
      _oth1Ctrl.text = d['OTHER1']?.toString() ?? '';
      _amt1Ctrl.text = _f(d['AMOUNT1']);
      _oth2Ctrl.text = d['OTHER2']?.toString() ?? '';
      _amt2Ctrl.text = _f(d['AMOUNT2']);
      _oth3Ctrl.text = d['OTHER3']?.toString() ?? '';
      _amt3Ctrl.text = _f(d['AMOUNT3']);

      // ── final ──
      _workshopInvNo.text = d['WORKSHOPINVOICENO']?.toString() ?? '';
      _workshopInvAmt.text = _f(d['WORKSHOPINVOICEAMOUNT']);
      _trcCtrl.text = _f(d['trc']);
      _compAccCtrl.text = _f(d['Accessories'] ?? d['accessories']);
      _ownAccCtrl.text = _f(d['ownaccss']);
      _warrantyCtrl.text = _f(d['WarrantyAmount'] ?? d['warrantyamount']);
      _warrantyYrCtrl.text = d['WarrantyYear']?.toString() ?? '';
      _fastTagCtrl.text = _f(d['fasttag']);
      final tcsCalRaw = d['tcscal']?.toString().trim().toUpperCase() ?? '';

      _tcsCal = tcsCalRaw == 'TRUE' || tcsCalRaw == '1' || tcsCalRaw == 'YES';
      _tcsCtrl.text = _f(d['tcs']);
      _totalCtrl.text = _f(d['netamount']);

      // ── remarks ──
      _remarkCtrl.text = d['REMARK']?.toString() ?? '';
      _appRemarkCtrl.text = d['appremark']?.toString() ?? '';
      _rejRemarkCtrl.text = d['rejectremark']?.toString() ?? '';
    });

    // Load receipt grid, variant details, HPN branches in parallel
    if (_custId != null && _custId!.isNotEmpty) {
      _loadReceiptGrid(_custId!);
    }
    if (_variantId != null && _variantId!.isNotEmpty) {
      _loadVariantsColorsVinsForEdit();
    }
    if (_hpnParentId != null && _hpnParentId!.isNotEmpty) {
      _loadHpnBranches(_hpnParentId!);
    }
    _recalculateAspNet();
  }

  /// After loading edit data, also populate variant/color/vin cascades
  Future<void> _loadVariantsColorsVinsForEdit() async {
    if (_modelId == null) return;
    try {
      final variants = await ApiService.getChallanVariants(_modelId!);
      if (!mounted) return;
      setState(() => _variants = variants);

      if (_variantId != null) {
        final colors = await ApiService.getChallanColors(_variantId!);
        if (!mounted) return;
        setState(() => _colors = colors);

        if (_colorId != null) {
          final vins = await ApiService.getChallanVins(
            variantId: _variantId!,
            colorId: _colorId!,
            challanType: _challanType,
          );
          if (!mounted) return;
          setState(() => _vins = vins);
        }
      }
    } catch (e) {
      print('_loadVariantsColorsVinsForEdit ERROR: $e');
    }
  }

  /// Load receipt rows for a customer
  Future<void> _loadReceiptGrid(String customerId) async {
    if (customerId.isEmpty) return;
    setState(() => _loadingReceipts = true);
    try {
      final result = await ApiService.getChallanReceiptGrid(customerId);
      if (!mounted) return;
      final rows = result['rows'] as List? ?? [];
      setState(() {
        _receiptRows = rows
            .map((e) => Map<String, dynamic>.from(e as Map))
            .toList();
        _receiptTotal =
            double.tryParse(result['rcTotal']?['rcamt']?.toString() ?? '0') ??
            0;
        _receiptFinanceAmt =
            double.tryParse(result['fiTotal']?['fiamt']?.toString() ?? '0') ??
            0;
        // Cash finance => receipt Customer Amt must always be zero.
        // The receipt API may still return the booking/customer receipt total,
        // but it must not be treated as Customer Amt for Cash finance.
        final customerReceived =
            double.tryParse(result['custTotal']?['camt']?.toString() ?? '0') ??
            0;

        _receiptCustAmt = _finType.trim().toLowerCase() == 'cash'
            ? 0.0
            : customerReceived;

        // Customer Received Amt is the actual customer receipt total.
        // Do NOT leave this field at zero for Cash finance.
        _customerReceivedCtrl.text = customerReceived.toStringAsFixed(2);

        _loadingReceipts = false;
      });

      // Pre-fill received amounts from actual receipt totals.
      setState(() {
        _receivedCtrl.text = _receiptTotal.toStringAsFixed(2);

        // Customer Balance must immediately use the pre-filled
        // Customer Received Amt.
        _recalculateAspNet();
      });
    } catch (e) {
      if (mounted) setState(() => _loadingReceipts = false);
      print('_loadReceiptGrid ERROR: $e');
    }
  }

  /// Load HPN child branches
  Future<void> _loadHpnBranches(String hpnId) async {
    try {
      final branches = await ApiService.getChallanHpnBranches(hpnId);
      if (!mounted) return;
      setState(() => _hpnBranches = branches);
    } catch (e) {
      print('_loadHpnBranches ERROR: $e');
    }
  }

  Future<void> _loadAccessoriesGrid() async {
    final customerId = (_custId ?? '').trim();

    if (customerId.isEmpty) {
      _snack('Please select a customer first');
      return;
    }

    setState(() {
      _loadingAccessoryGrid = true;
      _accessoryGridRows = [];
    });

    try {
      final rows = await ApiService.getAccessoriesGrid(customerId);

      if (!mounted) return;

      setState(() {
        _accessoryGridRows = rows;
      });

      debugPrint('ACCESSORIES GRID ROWS: ${rows.length}');
      debugPrint('ACCESSORIES GRID DATA: $rows');

      _showAccessoriesDialog();
    } catch (e) {
      if (mounted) {
        _snack('Unable to load accessories: $e');
      }
    } finally {
      if (mounted) {
        setState(() => _loadingAccessoryGrid = false);
      }
    }
  }

  // ── Cascade dropdowns ─────────────────────────────────────────────────────
  Future<void> _onModel(String? id) async {
    setState(() {
      _modelId = id;
      _variantId = null;
      _colorId = null;
      _vinNo = null;
      _variants = [];
      _colors = [];
      _vins = [];
    });
    _recalculateAspNet();
    if (id == null) return;
    setState(() => _loadingVar = true);
    try {
      final v = await ApiService.getChallanVariants(id);
      if (!mounted) return;
      setState(() => _variants = v);
    } finally {
      if (mounted) setState(() => _loadingVar = false);
    }
  }

  Future<void> _onVariant(String? id) async {
    setState(() {
      _variantId = id;
      _colorId = null;
      _vinNo = null;
      _colors = [];
      _vins = [];
    });
    _recalculateAspNet();
    if (id == null) return;
    setState(() => _loadingCol = true);
    try {
      final c = await ApiService.getChallanColors(id);
      if (mounted) setState(() => _colors = c);
    } finally {
      if (mounted) setState(() => _loadingCol = false);
    }
    await _fetchVariantDetails(id);
    await _fetchRtoTrc();
  }

  Future<void> _onColor(String? id) async {
    setState(() {
      _colorId = id;
      _vinNo = null;
      _vins = [];
    });
    _recalculateAspNet();
    if (id == null || _variantId == null) return;
    setState(() => _loadingVin = true);
    try {
      final v = await ApiService.getChallanVins(
        variantId: _variantId!,
        colorId: id,
        challanType: _challanType,
      );
      if (mounted) setState(() => _vins = v);
    } finally {
      if (mounted) setState(() => _loadingVin = false);
    }
  }

  void _onVinSelected(String? id) {
    setState(() => _vinNo = id);
    if (id != null) {
      final row = _vins.firstWhere(
        (e) => (e['data'] ?? e['value'] ?? e['id']).toString() == id,
        orElse: () => <String, dynamic>{},
      );
      if (row.isNotEmpty) {
        final engine = row['engine'] ?? row['engineno'] ?? row['engineNo'];
        if (engine != null && engine.toString().isNotEmpty) {
          _engineCtrl.text = engine.toString();
        }
      }
      _fetchRetailSupport(id);
    }
    _recalculateAspNet();
  }

  Future<void> _fetchRetailSupport(String vinNo) async {
    if (_variantId == null || _modelId == null) return;
    try {
      final dateStr =
          '${_challanDate.day.toString().padLeft(2, '0')}/${_challanDate.month.toString().padLeft(2, '0')}/${_challanDate.year}';
      final data = await ApiService.getChallanRetailSupport(
        variantId: _variantId!,
        modelId: _modelId!,
        vinNo: vinNo,
        challanDate: dateStr,
      );
      if (!mounted || data.isEmpty) return;
      setState(() {
        final corp = double.tryParse(data['corporate']?.toString() ?? '0') ?? 0;
        final exch = double.tryParse(data['exchange']?.toString() ?? '0') ?? 0;
        final loy = double.tryParse(data['loyality']?.toString() ?? '0') ?? 0;
        final deal = double.tryParse(data['dealer']?.toString() ?? '0') ?? 0;
        if (corp > 0) _corpValCtrl.text = corp.toStringAsFixed(2);
        if (exch > 0) _exchValCtrl.text = exch.toStringAsFixed(2);
        if (loy > 0) _loyValCtrl.text = loy.toStringAsFixed(2);
        if (deal > 0) _dealValCtrl.text = deal.toStringAsFixed(2);
      });
      _recalculateAspNet();
    } catch (e) {
      print('_fetchRetailSupport ERROR: $e');
    }
  }

  void _applyChallanFinancialData(Map<String, dynamic> d) {
    // ============================================================
    // EX-SHOWROOM
    // ============================================================
    _exShowCtrl.text = _f(
      d['ExshowRoomPrice'] ??
          d['exshowroomprice'] ??
          d['exshowroom'] ??
          d['exShowroom'],
    );

    _schemesCtrl.text = _f(
      d['lessofallencashmentschemne'] ?? d['scheme'] ?? d['schemes'],
    );

    _subTotalCtrl.text = _f(d['subtotal']);

    // ============================================================
    // INSURANCE
    // ============================================================
    final insTypeRaw = d['instype']?.toString().trim().toLowerCase() ?? '';

    if (insTypeRaw == 'in') {
      _insType = 'In House';
    } else if (insTypeRaw == 'out') {
      _insType = 'Out House';
    }

    _insExShowCtrl.text = _f(
      d['insshowroom'] ?? d['insuranceexshowroom'] ?? d['insuranceExShowroom'],
    );

    _cessCtrl.text = _f(d['CESS'] ?? d['cess']);

    _cessAmtCtrl.text = _f(d['Amount'] ?? d['amount'] ?? d['cessamt']);

    _idvCtrl.text = _f(d['Idv'] ?? d['idv']);

    _idvAmtCtrl.text = _f(d['IdvAmount'] ?? d['idvamount']);

    _afterIdvCtrl.text = _f(d['afteridvamt'] ?? d['afterIdvAmount']);

    _insAmtCtrl.text = _f(d['InsperAmount'] ?? d['insperamount']);

    _insPerCtrl.text = _f(
      d['InsurancePercentage'] ??
          d['insurancepercentage'] ??
          d['insurancepercent'],
    );

    _finalInsCtrl.text = _f(
      d['InsuranceAmount'] ?? d['insuranceamount'] ?? d['finalinsurance'],
    );

    _insDisCtrl.text = _f(
      d['DiscountPrecentage'] ?? d['discountprecentage'] ?? d['insdis'],
    );

    _disAmtCtrl.text = _f(d['DiscountAmount'] ?? d['discountamount']);

    _afterDisCtrl.text = _f(d['afterdisamtamt'] ?? d['afterdiscount']);

    _thirdPartyCtrl.text = _f(d['ThirdParty'] ?? d['thirdparty']);

    _paCoverCtrl.text = _f(d['PACover'] ?? d['pacover']);

    _paAmtCtrl.text = _f(d['pacoveramt']);

    _zdCtrl.text = _f(d['ZD'] ?? d['zd']);

    _zdAmtCtrl.text = _f(d['zdamt']);

    _epCtrl.text = _f(d['ep']);

    _epAmtCtrl.text = _f(d['epamt']);

    _pbCtrl.text = _f(d['PB'] ?? d['pb']);

    _kpCtrl.text = _f(d['KP'] ?? d['kp']);

    _kpAmtCtrl.text = _f(d['kpamt']);

    _paidDrvCtrl.text = _f(d['PaidDriver'] ?? d['paiddriver']);

    _afterPdCtrl.text = _f(d['amtafterpaiddriver']);

    _rtiCtrl.text = _f(d['rti']);

    _rtiAmtCtrl.text = _f(d['rtiamt']);

    _cmCtrl.text = _f(d['cm']);

    _cmAmtCtrl.text = _f(d['cmamt']);

    _gstUnq = (d['gstunq'] ?? d['gst'])?.toString();

    _cgstCtrl.text = _f(d['cgst']);

    _sgstCtrl.text = _f(d['sgst']);

    _gstAmtCtrl.text = _f(d['GSTAmount'] ?? d['gstamount']);

    _addLessCtrl.text = _f(d['addless']);

    _ncbCtrl.text = _f(d['NCB'] ?? d['ncb']);

    _cngPerCtrl.text = _f(d['cngp'] ?? d['cng']);

    _cngAmtCtrl.text = _f(d['cngamt']);

    // ============================================================
    // RTO
    // ============================================================
    final rtoFromRaw = d['rtofrom'] ?? d['rtoinout'];

    if (rtoFromRaw != null) {
      final rto = rtoFromRaw.toString().trim().toLowerCase();

      if (rto == 'in') {
        _rtoFrom = 'In House';
      } else if (rto == 'out') {
        _rtoFrom = 'Out House';
      } else if (rto == 'bh') {
        _rtoFrom = 'BH';
      }
    }

    final scrapRaw = d['scrapper'] ?? d['scrappage'];

    if (scrapRaw != null) {
      final s = scrapRaw.toString().trim().toUpperCase();
      _scrappage = s == 'TRUE' || s == '1' || s == 'YES';
    }

    _rtoCityId = (d['rtounq'] ?? d['rtocity'])?.toString();

    _rtoExShowCtrl.text = _f(d['rtoexshow'] ?? d['RTOExShowroom']);

    _rtoRateCtrl.text = _f(d['RTORate'] ?? d['rtorate']);

    _rtoSurCtrl.text = _f(
      d['RTOTaxSurcharge'] ?? d['rtotaxsurcharge'] ?? d['rtosurcharge'],
    );

    _greenTaxCtrl.text = _f(d['GreenTax'] ?? d['greentax']);

    _regFeeCtrl.text = _f(d['RegFee'] ?? d['regfee']);

    _setHpnRtoMaster(d['HPN'] ?? d['hpn']);

    _dupCtrl.text = _f(d['Duplicate'] ?? d['duplicate']);

    _smartCtrl.text = _f(d['SmartCard'] ?? d['smartcard']);

    _otherRtoCtrl.text = _f(d['Other'] ?? d['other']);

    _rtoTempCtrl.text = _f(d['RTO TEMP'] ?? d['rto temp'] ?? d['rtotemp']);

    _bhPerCtrl.text = _f(d['bhperc'] ?? d['BHPercentage']);

    _bhYearCtrl.text = d['bhyear']?.toString() ?? d['BHYear']?.toString() ?? '';

    _rtoAmtCtrl.text = _f(d['RTOAmount'] ?? d['rtoamount']);

    // ============================================================
    // OTHER AMOUNTS
    // ============================================================
    _oth1Ctrl.text = d['OTHER1']?.toString() ?? d['other1']?.toString() ?? '';

    _amt1Ctrl.text = _f(d['AMOUNT1'] ?? d['amount1']);

    _oth2Ctrl.text = d['OTHER2']?.toString() ?? d['other2']?.toString() ?? '';

    _amt2Ctrl.text = _f(d['AMOUNT2'] ?? d['amount2']);

    _oth3Ctrl.text = d['OTHER3']?.toString() ?? d['other3']?.toString() ?? '';

    _amt3Ctrl.text = _f(d['AMOUNT3'] ?? d['amount3']);

    // ============================================================
    // FINAL CHALLAN VALUES
    // ============================================================
    _workshopInvNo.text = d['WORKSHOPINVOICENO']?.toString() ?? '';

    _workshopInvAmt.text = _f(
      d['WORKSHOPINVOICEAMOUNT'] ?? d['workshopinvoiceamount'],
    );

    _trcCtrl.text = _f(d['trc']);

    _compAccCtrl.text = _f(d['Accessories'] ?? d['accessories']);

    _ownAccCtrl.text = _f(d['ownaccss'] ?? d['ownaccessories']);

    _warrantyCtrl.text = _f(
      d['WarrantyAmount'] ?? d['warrantyamount'] ?? d['warranty'],
    );

    _warrantyYrCtrl.text =
        d['WarrantyYear']?.toString() ?? d['warrantyyear']?.toString() ?? '';

    _fastTagCtrl.text = _f(d['fasttag']);

    _tcsCtrl.text = _f(d['tcs']);

    _totalCtrl.text = _f(d['netamount']);
  }

  Future<void> _fetchVariantDetails(
    String varId, {
    bool preserveCustomerValues = false,
  }) async {
    try {
      final d = await ApiService.getChallanVariantDetails(
        variantId: varId,
        challanDate: DateFormat('dd/MM/yyyy').format(_challanDate),
        stateId: _stateId ?? '',
      );

      if (d == null || !mounted) return;

      setState(() {
        // ======================================================
        // EX-SHOWROOM
        // ======================================================

        if (!preserveCustomerValues ||
            !_customerFinancialFields.contains('exshowroom')) {
          if (d['exshowroom'] != null) {
            _exShowCtrl.text = _f(d['exshowroom']);
          }
        }

        // ======================================================
        // FAST TAG
        // ======================================================

        if (!preserveCustomerValues ||
            !_customerFinancialFields.contains('fasttag')) {
          if (d['fasttag'] != null) {
            _fastTagCtrl.text = _f(d['fasttag']);
          }
        }

        // ======================================================
        // RTO EX-SHOWROOM
        // ======================================================

        if (!preserveCustomerValues ||
            !_customerFinancialFields.contains('rtoexshow')) {
          if (d['rtoexshow'] != null) {
            _rtoExShowCtrl.text = _f(d['rtoexshow']);
          } else if (d['exshowroom'] != null) {
            _rtoExShowCtrl.text = _f(d['exshowroom']);
          }
        }

        // ======================================================
        // RTO RATE
        // ======================================================

        if (!preserveCustomerValues ||
            !_customerFinancialFields.contains('rtorate')) {
          if (d['rtorate'] != null) {
            _rtoRateCtrl.text = _f(d['rtorate']);
          }
        }

        // ======================================================
        // RTO SURCHARGE
        // ======================================================

        if (!preserveCustomerValues ||
            !_customerFinancialFields.contains('rtosurcharge')) {
          if (d['rtosurcharge'] != null) {
            _rtoSurCtrl.text = _f(d['rtosurcharge']);
          }
        }

        // ======================================================
        // GREEN TAX
        // ======================================================

        if (!preserveCustomerValues ||
            !_customerFinancialFields.contains('greentax')) {
          if (d['greentax'] != null) {
            _greenTaxCtrl.text = _f(d['greentax']);
          }
        }

        // ======================================================
        // REGISTRATION FEE
        // ======================================================

        if (!preserveCustomerValues ||
            !_customerFinancialFields.contains('regfee')) {
          if (d['regfee'] != null) {
            _regFeeCtrl.text = _f(d['regfee']);
          }
        }

        // ======================================================
        // HPN
        // ======================================================

        if (!preserveCustomerValues ||
            !_customerFinancialFields.contains('hpn')) {
          if (d['hpn'] != null) {
            _setHpnRtoMaster(d['hpn']);
          }
        }

        // ======================================================
        // DUPLICATE
        // ======================================================

        if (!preserveCustomerValues ||
            !_customerFinancialFields.contains('duplicate')) {
          if (d['duplicate'] != null) {
            _dupCtrl.text = _f(d['duplicate']);
          }
        }

        // ======================================================
        // SMART CARD
        // ======================================================

        if (!preserveCustomerValues ||
            !_customerFinancialFields.contains('smartcard')) {
          if (d['smartcard'] != null) {
            _smartCtrl.text = _f(d['smartcard']);
          }
        }

        // ======================================================
        // OTHER RTO
        // ======================================================

        if (!preserveCustomerValues ||
            !_customerFinancialFields.contains('other')) {
          if (d['other'] != null) {
            _otherRtoCtrl.text = _f(d['other']);
          }
        }

        // ======================================================
        // THIRD PARTY
        // ======================================================

        if (!preserveCustomerValues ||
            !_customerFinancialFields.contains('thirdparty')) {
          if (d['thirdparty'] != null) {
            _thirdPartyCtrl.text = _f(d['thirdparty']);
          }
        }

        // ======================================================
        // PA COVER
        // ======================================================

        if (!preserveCustomerValues ||
            !_customerFinancialFields.contains('pacover')) {
          if (d['pacover'] != null) {
            _paCoverCtrl.text = _f(d['pacover']);
          }
        }

        // ======================================================
        // CNG
        // ======================================================

        if (!preserveCustomerValues ||
            !_customerFinancialFields.contains('cng')) {
          if (d['cng'] != null) {
            _cngPerCtrl.text = _f(d['cng']);
          }
        }

        // ======================================================
        // BH %
        // ======================================================

        if (!preserveCustomerValues ||
            !_customerFinancialFields.contains('bhperc')) {
          if (d['bhperc'] != null) {
            _bhPerCtrl.text = _f(d['bhperc']);
          }
        }

        // ======================================================
        // BH YEAR
        // ======================================================

        if (!preserveCustomerValues ||
            !_customerFinancialFields.contains('bhyear')) {
          if (d['bhyear'] != null) {
            _bhYearCtrl.text = _f(d['bhyear']);
          }
        }

        // ======================================================
        // BH CALCULATION MASTER
        // ======================================================
        if (d['bhpayear'] != null) {
          _bhPayYear = double.tryParse(d['bhpayear'].toString()) ?? 15.0;
        }

        if (d['bhyearmultiple'] != null) {
          _bhYearMultiple =
              double.tryParse(d['bhyearmultiple'].toString()) ?? 1.25;
        }

        if (d['bhaftergst'] != null) {
          final raw = d['bhaftergst'].toString().trim().toLowerCase();
          _bhAfterGst = raw == 'true' || raw == '1' || raw == 'yes';
        }

        debugPrint(
          'BH MASTER => rate=${_bhPerCtrl.text}, '
          'year=${_bhYearCtrl.text}, '
          'payYear=$_bhPayYear, '
          'multiple=$_bhYearMultiple, '
          'afterGST=$_bhAfterGst',
        );

        // ======================================================
        // GST
        // ======================================================

        if (!preserveCustomerValues ||
            !_customerFinancialFields.contains('gst')) {
          if (d['gst'] != null) {
            _gstUnq = d['gst'].toString();
          }
        }

        // ======================================================
        // IDV
        // ======================================================

        if (!preserveCustomerValues ||
            !_customerFinancialFields.contains('idv')) {
          if (d['idv'] != null) {
            _idvCtrl.text = _f(d['idv']);
          }
        }

        // ======================================================
        // INSURANCE %
        // ======================================================

        if (!preserveCustomerValues ||
            !_customerFinancialFields.contains('insurancepercent')) {
          if (d['odrate'] != null) {
            _insPerCtrl.text = d['odrate'].toString();
          }
        }

        // ======================================================
        // INSURANCE EX-SHOWROOM
        // ======================================================

        if (!preserveCustomerValues ||
            !_customerFinancialFields.contains('insuranceexshowroom')) {
          if (d['insuranceexshowroom'] != null) {
            _insExShowCtrl.text = _f(d['insuranceexshowroom']);
          }
        }

        // ======================================================
        // ZD
        // ======================================================

        if (!preserveCustomerValues ||
            !_customerFinancialFields.contains('zd')) {
          if (d['zd'] != null) {
            _zdCtrl.text = _f(d['zd']);
          }
        }

        // ======================================================
        // PB
        // ======================================================

        if (!preserveCustomerValues ||
            !_customerFinancialFields.contains('pb')) {
          if (d['pb'] != null) {
            _pbCtrl.text = _f(d['pb']);
          }
        }

        // ======================================================
        // KP
        // ======================================================

        if (!preserveCustomerValues ||
            !_customerFinancialFields.contains('kp')) {
          if (d['kp'] != null) {
            _kpCtrl.text = _f(d['kp']);
          }
        }

        // ======================================================
        // PAID DRIVER
        // ======================================================

        if (!preserveCustomerValues ||
            !_customerFinancialFields.contains('paiddriver')) {
          if (d['paiddriver'] != null) {
            _paidDrvCtrl.text = _f(d['paiddriver']);
          }
        }

        // ======================================================
        // RTI
        // ======================================================

        if (!preserveCustomerValues ||
            !_customerFinancialFields.contains('rti')) {
          if (d['rti'] != null) {
            _rtiMasterRate = double.tryParse(d['rti'].toString());
          }

          _rtiCtrl.text = _rtiAdd && _rtiMasterRate != null
              ? _f(_rtiMasterRate)
              : '0.00';

          if (!_rtiAdd) {
            _rtiAmtCtrl.text = '0.00';
          }
        }

        // ======================================================
        // CM
        // ======================================================

        if (!preserveCustomerValues ||
            !_customerFinancialFields.contains('cm')) {
          if (d['cm'] != null) {
            _cmMasterRate = double.tryParse(d['cm'].toString());
          }

          _cmCtrl.text = _cmAdd && _cmMasterRate != null
              ? _f(_cmMasterRate)
              : '0.00';

          if (!_cmAdd) {
            _cmAmtCtrl.text = '0.00';
          }
        }

        // ======================================================
        // EP
        // ======================================================

        if (!preserveCustomerValues ||
            !_customerFinancialFields.contains('ep')) {
          if (d['ep'] != null) {
            _epMasterRate = double.tryParse(d['ep'].toString());
          }

          _epCtrl.text = _epAdd && _epMasterRate != null
              ? _f(_epMasterRate)
              : '0.00';

          if (!_epAdd) {
            _epAmtCtrl.text = '0.00';
          }
        }
      });

      // ========================================================
      // RECALCULATE
      // ========================================================
      _set(_cessCtrl, 0);
      _set(_idvCtrl, 5);

      _recalculateAspNet();
    } catch (e, stackTrace) {
      debugPrint('_fetchVariantDetails ERROR: $e');

      debugPrint(stackTrace.toString());
    }
  }

  Future<void> _fetchInsuranceCalculation() async {
    if (_insuranceCompanyId == null || _insuranceCompanyId!.trim().isEmpty) {
      debugPrint(
        'INSURANCE CALCULATION SKIPPED: insurance company ID is empty',
      );
      return;
    }

    if (_modelId == null || _modelId!.trim().isEmpty) {
      debugPrint('INSURANCE CALCULATION SKIPPED: model ID is empty');
      return;
    }

    try {
      final challanDate = DateFormat('dd/MM/yyyy').format(_challanDate);

      debugPrint('========================================');
      debugPrint('FETCH INSURANCE CALCULATION');
      debugPrint('Insurance Company ID = $_insuranceCompanyId');
      debugPrint('Model ID            = $_modelId');
      debugPrint('Challan Date        = $challanDate');
      debugPrint('========================================');

      final d = await ApiService.getChallanInsuranceCalculation(
        insuranceCompanyId: _insuranceCompanyId!,
        challanDate: challanDate,
        modelId: _modelId!,
      );

      if (d == null || !mounted) {
        debugPrint('INSURANCE CALCULATION RESPONSE = NULL');
        return;
      }

      debugPrint('========================================');
      debugPrint('INSURANCE CALCULATION RESPONSE');
      debugPrint(d.toString());
      debugPrint('========================================');

      setState(() {
        // -------------------------------------------------------
        // IDV
        // -------------------------------------------------------
        if (d['idv'] != null) {
          _idvCtrl.text = _f(d['idv']);
        }

        // -------------------------------------------------------
        // INSURANCE %
        // -------------------------------------------------------
        if (d['insurancePercentage'] != null) {
          _insPerCtrl.text = _f(d['insurancePercentage']);
        }

        // -------------------------------------------------------
        // INSURANCE DISCOUNT %
        // -------------------------------------------------------
        if (d['insuranceDiscount'] != null) {
          _insDisCtrl.text = _f(d['insuranceDiscount']);
        }

        // -------------------------------------------------------
        // THIRD PARTY
        // -------------------------------------------------------
        if (d['thirdparty'] != null) {
          _thirdPartyCtrl.text = _f(d['thirdparty']);
        }

        // -------------------------------------------------------
        // PA COVER
        // -------------------------------------------------------
        if (d['pacover'] != null) {
          _paCoverCtrl.text = _f(d['pacover']);
        }

        // -------------------------------------------------------
        // PAID DRIVER
        // -------------------------------------------------------
        if (d['paiddriver'] != null) {
          _paidDrvCtrl.text = _f(d['paiddriver']);
        }

        // -------------------------------------------------------
        // CNG %
        // -------------------------------------------------------
        if (d['cng'] != null) {
          _cngPerCtrl.text = _f(d['cng']);
        }

        // -------------------------------------------------------
        // ZD
        // -------------------------------------------------------
        if (d['zd'] != null) {
          _zdCtrl.text = _f(d['zd']);
        }

        // -------------------------------------------------------
        // EP
        // -------------------------------------------------------
        /*if (d['ep'] != null) {
          _epMasterRate = double.tryParse(d['ep'].toString());
          if (_epAdd) {
            _epCtrl.text = _f(d['ep']);
          } else {
            _epCtrl.text = '0.00';
          }
        }*/
        // EP
        // EP
        if (d['ep'] != null) {
          _epMasterRate = double.tryParse(d['ep'].toString());
        }
        _epCtrl.text = _epAdd && _epMasterRate != null
            ? _f(_epMasterRate)
            : '0.00';
        if (!_epAdd) _epAmtCtrl.text = '0.00';
        // -------------------------------------------------------
        // PB
        // -------------------------------------------------------
        if (d['pb'] != null) {
          _pbCtrl.text = _f(d['pb']);
        }

        // -------------------------------------------------------
        // KP
        // -------------------------------------------------------
        if (d['kp'] != null) {
          _kpCtrl.text = _f(d['kp']);
        }

        // -------------------------------------------------------
        // RTI
        // -------------------------------------------------------
        /* if (d['rti'] != null) {
          _rtiMasterRate = double.tryParse(d['rti'].toString());
          if (_rtiAdd) {
            _rtiCtrl.text = _f(d['rti']);
          } else {
            _rtiCtrl.text = '0.00';
          }
        }*/
        // RTI
        if (d['rti'] != null) {
          _rtiMasterRate = double.tryParse(d['rti'].toString());
        }
        _rtiCtrl.text = _rtiAdd && _rtiMasterRate != null
            ? _f(_rtiMasterRate)
            : '0.00';
        if (!_rtiAdd) _rtiAmtCtrl.text = '0.00';

        // -------------------------------------------------------
        // CM
        // -------------------------------------------------------
        /*if (d['cm'] != null) {
          _cmMasterRate = double.tryParse(d['cm'].toString());
          if (_cmAdd) {
            _cmCtrl.text = _f(d['cm']);
          } else {
            _cmCtrl.text = '0.00';
          }
        }*/
        // CM
        if (d['cm'] != null) {
          _cmMasterRate = double.tryParse(d['cm'].toString());
        }
        _cmCtrl.text = _cmAdd && _cmMasterRate != null
            ? _f(_cmMasterRate)
            : '0.00';
        if (!_cmAdd) _cmAmtCtrl.text = '0.00';
        // -------------------------------------------------------
        // NCB
        // -------------------------------------------------------
        if (d['ncb'] != null) {
          _ncbCtrl.text = _f(d['ncb']);
        }

        // -------------------------------------------------------
        // CESS
        // -------------------------------------------------------
        if (d['cess'] != null) {
          _cessCtrl.text = _f(d['cess']);
        }

        // -------------------------------------------------------
        // GST
        // -------------------------------------------------------
        if (d['gst'] != null) {
          _gstUnq = d['gst'].toString();
        }
      });

      // ---------------------------------------------------------
      // INSURANCE EX-SHOWROOM
      //
      // Variant API already gives exshowroom.
      // If customer/edit data didn't provide insurance showroom,
      // use normal ex-showroom.
      // ---------------------------------------------------------
      if (_d(_insExShowCtrl) <= 0) {
        _set(_insExShowCtrl, _d(_exShowCtrl));
      }

      // ---------------------------------------------------------
      // NOW CALCULATE INSURANCE
      // ---------------------------------------------------------
      _recalculateAspNet();
    } catch (e, stackTrace) {
      debugPrint('❌ _fetchInsuranceCalculation ERROR: $e');

      debugPrint(stackTrace.toString());
    }
  }

  Future<void> _onCustomerSelected(String? id) async {
    if (id == null || id.isEmpty) return;

    debugPrint('CUSTOMER SELECTED - ID: $id');

    // ============================================================

    // RESET CUSTOMER-SPECIFIC FIELD TRACKING

    // ============================================================

    _customerFinancialFields.clear();

    // ============================================================

    // FIND CUSTOMER

    // ============================================================

    final c = _customers.firstWhere(
      (e) => (e['data'] ?? e['value'] ?? e['id']).toString() == id,

      orElse: () => <String, dynamic>{},
    );

    debugPrint('========================================');

    debugPrint('CUSTOMER SELECTED');

    debugPrint('CUSTOMER DATA = $c');

    debugPrint('========================================');

    if (c.isEmpty) {
      setState(() => _custId = id);

      // LOAD CUSTOMER RECEIPTS

      await _loadReceiptGrid(id);

      // DEBUG: CHECK ACCESSORIES AMOUNT API

      debugPrint('CUSTOMER SELECTED: $id');

      debugPrint('CALLING ACCESSORIES AMOUNT API...');

      await _loadAccessoriesAmount(id);

      // FINAL ASP.NET CALCULATION

      if (mounted) {
        _recalculateAspNet();
      }

      return;
    }

    // ============================================================

    // CUSTOMER + VEHICLE + FINANCIAL DATA

    // ============================================================

    setState(() {
      // ==========================================================

      // CUSTOMER

      // ==========================================================

      _custId = id;

      // ==========================================================

      // VEHICLE

      // ==========================================================

      _modelId = c['va_26']?.toString();

      _variantId = c['va_27']?.toString();

      _insuranceCompanyId =
          (c['inscmpyid'] ??
                  c['insurancecompanyid'] ??
                  c['insuranceCompanyId'] ??
                  c['inscompanyid'])
              ?.toString()
              .trim();

      debugPrint('Customer Insurance Company ID = $_insuranceCompanyId');

      _colorId = c['va_28']?.toString();

      _vinNo = c['va_29']?.toString();

      // ==========================================================

      // ENGINE

      // ==========================================================

      _engineCtrl.text = c['sp_54']?.toString() ?? '';

      // ==========================================================

      // CUSTOMER DETAILS

      // ==========================================================

      _addressCtrl.text =
          c['m1_11']?.toString() ?? c['address']?.toString() ?? '';

      _emailCtrl.text = c['m1_50']?.toString() ?? c['email']?.toString() ?? '';

      _mobileCtrl.text =
          c['m1_47']?.toString() ?? c['mobile']?.toString() ?? '';

      _aadharCtrl.text =
          c['m1_48']?.toString() ?? c['aadhar']?.toString() ?? '';

      _panCtrl.text =
          c['m1_40']?.toString() ??
          c['panno']?.toString() ??
          c['pan']?.toString() ??
          '';

      _gstinCtrl.text = c['m1_37']?.toString() ?? c['gstin']?.toString() ?? '';

      // ==========================================================

      // TITLE

      // ==========================================================

      final titleRaw = c['m1_51']?.toString().trim() ?? '';

      if (titleRaw.isNotEmpty) {
        _title = titleRaw;
      } else {
        final fallbackTitle = c['title']?.toString().trim() ?? '';

        _title = fallbackTitle.isNotEmpty ? fallbackTitle : 'MR';
      }

      // ==========================================================

      // NOMINEE / RELATION / AGE

      // ==========================================================

      _nomineeCtrl.text = c['nominee']?.toString() ?? '';

      _ageCtrl.text = c['age']?.toString() ?? '';

      final relRaw = c['relation']?.toString().trim() ?? '';

      if (relRaw.isNotEmpty) {
        _relation = relRaw;
      }

      // ==========================================================

      // FATHER NAME

      // ==========================================================

      _fatherCtrl.text = c['fathername']?.toString() ?? '';

      // ==========================================================

      // SALES CONSULTANT

      // ==========================================================

      _scCtrl.text = c['scname']?.toString() ?? '';

      // ==========================================================

      // TL / MANAGER

      // ==========================================================

      _tlCtrl.text = c['tlname']?.toString() ?? c['tl']?.toString() ?? '';

      _managerCtrl.text =
          c['managername']?.toString() ?? c['manager']?.toString() ?? '';

      // ==========================================================

      // EP / RTI / CM

      //

      // Only overwrite if customer API actually contains a value.

      // Empty string should NOT destroy master values.

      // ==========================================================

      final epValue = c['ep'];

      if (epValue != null && epValue.toString().trim().isNotEmpty) {
        final epRaw = _f(epValue);

        _customerFinancialFields.add('ep');

        _epCtrl.text = epRaw;

        _epAdd = (double.tryParse(epRaw) ?? 0) > 0;
      }

      final rtiValue = c['rti'];

      if (rtiValue != null && rtiValue.toString().trim().isNotEmpty) {
        final rtiRaw = _f(rtiValue);

        _customerFinancialFields.add('rti');

        _rtiCtrl.text = rtiRaw;

        _rtiAdd = (double.tryParse(rtiRaw) ?? 0) > 0;
      }

      final cmValue = c['cm'];

      if (cmValue != null && cmValue.toString().trim().isNotEmpty) {
        final cmRaw = _f(cmValue);

        _customerFinancialFields.add('cm');

        _cmCtrl.text = cmRaw;

        _cmAdd = (double.tryParse(cmRaw) ?? 0) > 0;
      }

      // ==========================================================

      // INSURANCE DISCOUNT

      // ==========================================================

      final insDisValue = c['insdis'];

      if (insDisValue != null && insDisValue.toString().trim().isNotEmpty) {
        _customerFinancialFields.add('insdis');

        _insDisCtrl.text = _f(insDisValue);
      }

      // ==========================================================

      // INSURANCE IN / OUT

      // ==========================================================

      final insInOut = c['insinout']?.toString().trim().toLowerCase() ?? '';

      if (insInOut == 'in') {
        _insType = 'In House';
      } else if (insInOut == 'out') {
        _insType = 'Out House';
      }

      // ==========================================================

      // RTO IN / OUT

      //

      // Only map explicit textual values.

      // Do NOT assume "0.00" means In House/Out House.

      // ==========================================================

      final rtoInOut = c['rtoinout']?.toString().trim().toLowerCase() ?? '';

      if (rtoInOut == 'in') {
        _rtoFrom = 'In House';
      } else if (rtoInOut == 'out') {
        _rtoFrom = 'Out House';
      } else if (rtoInOut == 'bh') {
        _rtoFrom = 'BH';
      }

      // ==========================================================

      // RTO CITY

      // ==========================================================

      final rtoCityFromCust = c['rtocity']?.toString() ?? '';

      if (rtoCityFromCust.isNotEmpty) {
        _rtoCityId = rtoCityFromCust;
      }

      // ==========================================================

      // RTO CITY NAME

      // ==========================================================

      // ==========================================================

      // TRC

      // ==========================================================

      final trcValue = c['trc'];

      if (trcValue != null && trcValue.toString().trim().isNotEmpty) {
        _customerFinancialFields.add('trc');

        _trcCtrl.text = _f(trcValue);
      }

      // ==========================================================

      // HPN / HYPOTHECATION

      // ==========================================================

      _hpnParentId =
          c['hpnunq']?.toString() ??
          c['sp_688']?.toString() ??
          c['sp_774']?.toString();

      _hpnChildId = c['sp_689']?.toString() ?? c['sp_775']?.toString();

      _hpnId = c['hpn']?.toString();

      _hypCtrl.text = c['hpnchild']?.toString() ?? '';

      // ==========================================================

      // FINANCE TYPE

      // ==========================================================

      final financeRaw = c['finance']?.toString().trim().toLowerCase() ?? '';

      if (financeRaw == 'in') {
        _finType = 'In House';
      } else if (financeRaw == 'out') {
        _finType = 'Out House';
      } else if (financeRaw == 'cash') {
        _finType = 'Cash';
      } else {
        _finType = 'In House';
      }

      // ==========================================================

      // LOAN AMOUNT

      // ==========================================================

      _loanAmtCtrl.text = _f(
        c['loanamt'] ?? c['netdisbured'] ?? c['sp_537'] ?? c['bankamt'],
      );

      // ==========================================================

      // NET DISBURSED

      // ==========================================================

      _netDisCtrl.text = _f(
        c['netdisbured'] ?? c['loanamt'] ?? c['sp_537'] ?? c['bankamt'],
      );

      // ==========================================================

      // BRANCH

      //

      // IMPORTANT:

      // Always replace previous customer's branch.

      // ==========================================================

      final custBranchId = c['branchid']?.toString() ?? '';

      if (custBranchId.isNotEmpty) {
        _branchId = custBranchId;
      }

      _branchNameCtrl.text =
          c['branchname']?.toString() ??
          c['branch']?.toString() ??
          c['m1_53']?.toString() ??
          '';

      // ==========================================================

      // CORPORATE

      // ==========================================================

      final corp = double.tryParse(c['corporate']?.toString() ?? '0') ?? 0;

      if (corp > 0) {
        _corpValCtrl.text = corp.toStringAsFixed(2);

        _corpYn = 'Yes';
      } else {
        _corpValCtrl.text = '0';

        _corpYn = 'No';
      }

      // ==========================================================

      // EXCHANGE

      // ==========================================================

      final exch = double.tryParse(c['exchange']?.toString() ?? '0') ?? 0;

      if (exch > 0) {
        _exchValCtrl.text = exch.toStringAsFixed(2);

        _exchYn = 'Yes';
      } else {
        _exchValCtrl.text = '0';

        _exchYn = 'No';
      }

      // ==========================================================

      // LOYALTY

      // ==========================================================

      final loy = double.tryParse(c['loyality']?.toString() ?? '0') ?? 0;

      if (loy > 0) {
        _loyValCtrl.text = loy.toStringAsFixed(2);

        _loyYn = 'Yes';
      } else {
        _loyValCtrl.text = '0';

        _loyYn = 'No';
      }

      // ==========================================================

      // DEALER

      // ==========================================================

      final deal = double.tryParse(c['dealer']?.toString() ?? '0') ?? 0;

      if (deal > 0) {
        _dealValCtrl.text = deal.toStringAsFixed(2);

        _dealYn = 'Yes';
      } else {
        _dealValCtrl.text = '0';

        _dealYn = 'No';
      }

      // ==========================================================

      // SCHEME

      //

      // API may return [0, 0].

      // Do not try to double.parse("[0, 0]").

      // ==========================================================

      final schemeValue = c['scheme'];

      if (schemeValue is List) {
        double schemeTotal = 0;

        for (final item in schemeValue) {
          schemeTotal += double.tryParse(item?.toString() ?? '0') ?? 0;
        }

        _schemesCtrl.text = schemeTotal.toStringAsFixed(2);
      } else {
        final scheme = double.tryParse(schemeValue?.toString() ?? '0') ?? 0;

        _schemesCtrl.text = scheme.toStringAsFixed(2);
      }

      // ==========================================================

      // WARRANTY

      // ==========================================================

      final wrtyAmt =
          double.tryParse(
            c['wrty_amt']?.toString() ?? c['warranty']?.toString() ?? '0',
          ) ??
          0;

      _warrantyCtrl.text = wrtyAmt.toStringAsFixed(2);

      // ==========================================================

      // WARRANTY YEAR

      // ==========================================================

      if (c['warranty'] != null) {
        // Keep existing warranty-year logic if your API provides

        // a separate year field.
      }

      // ==========================================================

      // RSA

      // ==========================================================

      final rsaAmt = double.tryParse(c['rsa']?.toString() ?? '0') ?? 0;

      _rsaCtrl.text = rsaAmt.toStringAsFixed(2);

      // ==========================================================

      // SOT

      // ==========================================================

      final sotAmt =
          double.tryParse(
            c['sot_amt']?.toString() ?? c['sot']?.toString() ?? '0',
          ) ??
          0;

      _sotAmtCtrl.text = sotAmt.toStringAsFixed(2);

      // ==========================================================

      // OTHER 1 / 2 / 3

      // ==========================================================

      _oth1Ctrl.text = c['ot_cap1']?.toString() ?? '';

      _oth2Ctrl.text = c['ot_cap2']?.toString() ?? '';

      _oth3Ctrl.text = c['ot_cap3']?.toString() ?? '';

      _amt1Ctrl.text = _f(c['ot_amt1'] ?? 0);

      _amt2Ctrl.text = _f(c['ot_amt2'] ?? 0);

      _amt3Ctrl.text = _f(c['ot_amt3'] ?? 0);

      // ==========================================================

      // SCRAPPAGE

      //

      // IMPORTANT:

      // API returns actual percentage.

      // Example:

      // scrapper = 26

      //

      // It is NOT simply a boolean.

      // ==========================================================

      final scrapperRaw = c['scrapper'] ?? c['scrappage'];

      _scrappagePercent =
          double.tryParse(scrapperRaw?.toString() ?? '0') ?? 0.0;

      if (_scrappagePercent > 0) {
        _scrappage = true;
        _customerFinancialFields.add('scrappage');
      } else {
        _scrappage = false;
        _customerFinancialFields.remove('scrappage');
      }

      // ==========================================================

      // TCS CALCULATION FLAG

      // ==========================================================

      // TCS CALCULATION FLAG
      final tcsCal = c['tcscal']?.toString().trim().toUpperCase() ?? '';

      _tcsCal = tcsCal == 'TRUE' || tcsCal == '1' || tcsCal == 'YES';

      if (_tcsCal) {
        _customerFinancialFields.add('tcscal');
      } else {
        _customerFinancialFields.remove('tcscal');
      }

      // ==========================================================

      // CITY / AREA

      // ==========================================================

      _cityName = c['city']?.toString() ?? '';

      _cityId = c['cityunq']?.toString();

      _areaName = c['area']?.toString() ?? '';

      _areaId = c['areaunq']?.toString();

      // ==========================================================

      // APPLY OTHER EXISTING CUSTOMER FINANCIAL DATA

      // ==========================================================

      _applyChallanFinancialData(c);
    });

    // ============================================================

    // LOAD DEPENDENT VARIANTS

    // ============================================================

    if (_modelId != null && _modelId!.isNotEmpty) {
      try {
        final variants = await ApiService.getChallanVariants(_modelId!);

        if (!mounted) return;

        setState(() {
          _variants = variants;
        });

        // ========================================================

        // LOAD COLORS

        // ========================================================

        if (_variantId != null && _variantId!.isNotEmpty) {
          final colors = await ApiService.getChallanColors(_variantId!);

          if (!mounted) return;

          setState(() {
            _colors = colors;
          });

          // ======================================================

          // LOAD VINs

          // ======================================================

          if (_colorId != null && _colorId!.isNotEmpty) {
            final vins = await ApiService.getChallanVins(
              variantId: _variantId!,

              colorId: _colorId!,

              challanType: _challanType,
            );

            if (!mounted) return;

            setState(() {
              _vins = vins;
            });
          }
        }
      } catch (e) {
        debugPrint('_onCustomerSelected cascade ERROR: $e');
      }
    }

    // ============================================================

    // LOAD VARIANT MASTER DETAILS

    //

    // IMPORTANT:

    // Preserve customer-specific values such as:

    //   insdis

    //   scrappage

    //   ep

    //   rti

    //   cm

    //   trc

    //   etc.

    // ============================================================

    if (_variantId != null && _variantId!.isNotEmpty) {
      await _fetchVariantDetails(_variantId!, preserveCustomerValues: true);

      await _fetchInsuranceCalculation();
    }

    // ============================================================

    // LOAD HPN CHILD BRANCHES

    // ============================================================

    if (_hpnParentId != null && _hpnParentId!.isNotEmpty) {
      await _loadHpnBranches(_hpnParentId!);
    }

    // ============================================================

    // FETCH OWN RTO

    // ============================================================

    if (_branchId != null && _branchId!.isNotEmpty && _rtoCityId == null) {
      await _fetchOwnRtoCity(_branchId!);
    }

    // Fetch TRC even when the RTO city was already populated.
    await _fetchRtoTrc();

    // ============================================================

    // LOAD CUSTOMER RECEIPTS

    // ============================================================

    await _loadReceiptGrid(id);

    // ============================================================

    // LOAD ACCESSORIES AMOUNTS AFTER CUSTOMER DATA/RECEIPTS
    debugPrint('CUSTOMER ID: $id');
    debugPrint('STARTING ACCESSORIES AMOUNT API');
    await _loadAccessoriesAmount(id);
    // FETCH TCS WHEN CUSTOMER IS SELECTED
    debugPrint('FETCHING TCS FOR CHALLAN DATE: $_challanDate');
    await _fetchTcsForDate(_challanDate);
    // FINAL ASP.NET CALCULATION

    // ============================================================

    if (mounted) {
      _recalculateAspNet();
    }
  }

  // Future<void> _onCustomerSelected(String? id) async {
  //   if (id == null || id.isEmpty) return;

  //   final c = _customers.firstWhere(
  //     (e) => (e['data'] ?? e['value'] ?? e['id']).toString() == id,
  //     orElse: () => <String, dynamic>{},
  //   );

  //   if (c.isEmpty) {
  //     setState(() => _custId = id);
  //     _loadReceiptGrid(id);
  //     return;
  //   }

  //   setState(() {
  //     // ─────────────────────────────────────────────
  //     // CUSTOMER
  //     // ASP.NET:
  //     // ui.item.data
  //     // ─────────────────────────────────────────────
  //     _custId = id;

  //     // ─────────────────────────────────────────────
  //     // VEHICLE
  //     // ASP.NET:
  //     // model / variant / color / va_29
  //     // ─────────────────────────────────────────────
  //     _modelId = c['va_26']?.toString();
  //     _variantId = c['va_27']?.toString();
  //     _colorId = c['va_28']?.toString();
  //     _vinNo = c['va_29']?.toString();

  //     // ─────────────────────────────────────────────
  //     // ENGINE
  //     // ASP.NET: sp_54
  //     // ─────────────────────────────────────────────
  //     _engineCtrl.text = c['sp_54']?.toString() ?? '';

  //     // ─────────────────────────────────────────────
  //     // CUSTOMER DETAILS
  //     // ASP.NET m1_11, m1_50, m1_47, m1_48,
  //     // m1_40, m1_37, m1_51
  //     // ─────────────────────────────────────────────
  //     _addressCtrl.text =
  //         c['m1_11']?.toString() ?? c['address']?.toString() ?? '';

  //     _emailCtrl.text = c['m1_50']?.toString() ?? c['email']?.toString() ?? '';

  //     _mobileCtrl.text =
  //         c['m1_47']?.toString() ?? c['mobile']?.toString() ?? '';

  //     _aadharCtrl.text =
  //         c['m1_48']?.toString() ?? c['aadhar']?.toString() ?? '';

  //     _panCtrl.text =
  //         c['m1_40']?.toString() ??
  //         c['panno']?.toString() ??
  //         c['pan']?.toString() ??
  //         '';

  //     _gstinCtrl.text = c['m1_37']?.toString() ?? c['gstin']?.toString() ?? '';

  //     _title = c['m1_51']?.toString().isNotEmpty == true
  //         ? c['m1_51'].toString()
  //         : (c['title']?.toString().isNotEmpty == true
  //               ? c['title'].toString()
  //               : 'MR');

  //     // ─────────────────────────────────────────────
  //     // NOMINEE / RELATION / AGE
  //     // ASP.NET: sp_871 (nominee), sp_872 (age), sp_873 (relation)
  //     // ─────────────────────────────────────────────
  //     _nomineeCtrl.text = c['nominee']?.toString() ?? '';
  //     _ageCtrl.text = c['age']?.toString() ?? '';
  //     final relRaw = c['relation']?.toString() ?? '';
  //     if (relRaw.isNotEmpty) _relation = relRaw;

  //     // ─────────────────────────────────────────────
  //     // FATHER NAME
  //     // ─────────────────────────────────────────────
  //     _fatherCtrl.text = c['fathername']?.toString() ?? '';

  //     // ─────────────────────────────────────────────
  //     // SC
  //     // ASP.NET: scname / va_20 (scunq)
  //     // ─────────────────────────────────────────────
  //     _scCtrl.text = c['scname']?.toString() ?? '';

  //     // ─────────────────────────────────────────────
  //     // TL / MANAGER
  //     // ASP.NET: tlname / managername from sp_73
  //     // ─────────────────────────────────────────────
  //     _tlCtrl.text = c['tlname']?.toString() ?? c['tl']?.toString() ?? '';
  //     _managerCtrl.text =
  //         c['managername']?.toString() ?? c['manager']?.toString() ?? '';

  //     // ─────────────────────────────────────────────
  //     // EP / RTI / CM  (Insurance add-ons)
  //     // ASP.NET: SP_791 (ep), sp_792 (rti), sp_793 (cm)
  //     // ─────────────────────────────────────────────
  //     final epRaw = _f(c['ep']);
  //     final rtiRaw = _f(c['rti']);
  //     final cmRaw = _f(c['cm']);
  //     _epCtrl.text = epRaw;
  //     _rtiCtrl.text = rtiRaw;
  //     _cmCtrl.text = cmRaw;
  //     _epAdd = (double.tryParse(epRaw) ?? 0) > 0;
  //     _rtiAdd = (double.tryParse(rtiRaw) ?? 0) > 0;
  //     _cmAdd = (double.tryParse(cmRaw) ?? 0) > 0;

  //     // ─────────────────────────────────────────────
  //     // INSURANCE DISCOUNT (insdis)
  //     // ASP.NET: sp_803
  //     // ─────────────────────────────────────────────
  //     final insDis = c['insdis']?.toString() ?? '';
  //     if (insDis.isNotEmpty) _insDisCtrl.text = _f(insDis);

  //     // ─────────────────────────────────────────────
  //     // INSURANCE IN/OUT
  //     // ASP.NET: sp_790 (insinout) → 'in'/'out'
  //     // ─────────────────────────────────────────────
  //     final insInOut = c['insinout']?.toString().trim().toLowerCase() ?? '';
  //     if (insInOut == 'in') {
  //       _insType = 'In House';
  //     } else if (insInOut == 'out') {
  //       _insType = 'Out House';
  //     }

  //     // ─────────────────────────────────────────────
  //     // RTO IN/OUT
  //     // ASP.NET: sp_828 (rtoinout)
  //     // ─────────────────────────────────────────────
  //     final rtoInOut = c['rtoinout']?.toString().trim().toLowerCase() ?? '';
  //     if (rtoInOut == 'in') {
  //       _rtoFrom = 'In House';
  //     } else if (rtoInOut == 'out') {
  //       _rtoFrom = 'Out House';
  //     }

  //     // ─────────────────────────────────────────────
  //     // RTO CITY (pre-filled from booking)
  //     // ASP.NET: sp_839 (rtocity unq), rtocityname
  //     // ─────────────────────────────────────────────
  //     final rtoCityFromCust = c['rtocity']?.toString() ?? '';
  //     if (rtoCityFromCust.isNotEmpty) _rtoCityId = rtoCityFromCust;

  //     // ─────────────────────────────────────────────
  //     // TRC
  //     // ASP.NET: sp_840 (trc amount from booking)
  //     // ─────────────────────────────────────────────
  //     final trcRaw = c['trc']?.toString() ?? '';
  //     if (trcRaw.isNotEmpty) _trcCtrl.text = _f(trcRaw);

  //     // ─────────────────────────────────────────────
  //     // HPN / HYPOTHECATION
  //     // ASP.NET: sp_688 (hpn parent unq), sp_689 (hpn child unq),
  //     //          hp_7 (hpn name), hp_c_3 (hpn child name)
  //     // ─────────────────────────────────────────────
  //     _hpnParentId =
  //         c['hpnunq']?.toString() ??
  //         c['sp_688']?.toString() ??
  //         c['sp_774']?.toString();
  //     _hpnChildId = c['sp_689']?.toString() ?? c['sp_775']?.toString();
  //     _hpnId = c['hpn']?.toString(); // display name
  //     _hypCtrl.text = c['hpnchild']?.toString() ?? '';

  //     // ─────────────────────────────────────────────
  //     // FINANCE TYPE
  //     // ─────────────────────────────────────────────
  //     final financeRaw = c['finance']?.toString().trim().toLowerCase() ?? '';
  //     if (financeRaw == 'in') {
  //       _finType = 'In House';
  //     } else if (financeRaw == 'out') {
  //       _finType = 'Out House';
  //     } else if (financeRaw == 'cash') {
  //       _finType = 'Cash';
  //     } else {
  //       _finType = 'In House';
  //     }
  //     _loanAmtCtrl.text = _f(
  //       c['loanamt'] ?? c['netdisbured'] ?? c['sp_537'] ?? c['bankamt'],
  //     );
  //     _netDisCtrl.text = _f(
  //       c['netdisbured'] ?? c['loanamt'] ?? c['sp_537'] ?? c['bankamt'],
  //     );

  //     // ─────────────────────────────────────────────
  //     // BRANCH (from booking record)
  //     // ASP.NET: branchid, branchname
  //     // ─────────────────────────────────────────────
  //     final custBranchId = c['branchid']?.toString() ?? '';
  //     if (custBranchId.isNotEmpty && _branchId == null) {
  //       _branchId = custBranchId;
  //     }
  //     _branchNameCtrl.text =
  //         c['branchname']?.toString() ??
  //         c['branch']?.toString() ??
  //         c['m1_53']?.toString() ??
  //         '';

  //     // ─────────────────────────────────────────────
  //     // DISCOUNT VALUES (from sp_73 booking record)
  //     // ASP.NET: sp_779 (corporate), sp_781 (exchange),
  //     //          sp_783 (loyality), sp_785 (dealer), sp_787 (scheme)
  //     // Only set when > 0 so manual entries are preserved
  //     // ─────────────────────────────────────────────
  //     final corp = double.tryParse(c['corporate']?.toString() ?? '0') ?? 0;
  //     final exch = double.tryParse(c['exchange']?.toString() ?? '0') ?? 0;
  //     final loy = double.tryParse(c['loyality']?.toString() ?? '0') ?? 0;
  //     final deal = double.tryParse(c['dealer']?.toString() ?? '0') ?? 0;
  //     final scheme = double.tryParse(c['scheme']?.toString() ?? '0') ?? 0;

  //     if (corp > 0) {
  //       _corpValCtrl.text = corp.toStringAsFixed(2);
  //       _corpYn = 'Yes';
  //     }
  //     if (exch > 0) {
  //       _exchValCtrl.text = exch.toStringAsFixed(2);
  //       _exchYn = 'Yes';
  //     }
  //     if (loy > 0) {
  //       _loyValCtrl.text = loy.toStringAsFixed(2);
  //       _loyYn = 'Yes';
  //     }
  //     if (deal > 0) {
  //       _dealValCtrl.text = deal.toStringAsFixed(2);
  //       _dealYn = 'Yes';
  //     }
  //     if (scheme > 0) _schemesCtrl.text = scheme.toStringAsFixed(2);

  //     // ─────────────────────────────────────────────
  //     // WARRANTY / RSA / SOT (from sp_73)
  //     // ASP.NET: sp_848 (wrty_amt), sp_864 (rsa), sp_863 (sot_amt)
  //     // ─────────────────────────────────────────────
  //     final wrtyAmt =
  //         double.tryParse(
  //           c['wrty_amt']?.toString() ?? c['warranty']?.toString() ?? '0',
  //         ) ??
  //         0;
  //     final rsaAmt = double.tryParse(c['rsa']?.toString() ?? '0') ?? 0;
  //     final sotAmt =
  //         double.tryParse(
  //           c['sot_amt']?.toString() ?? c['sot']?.toString() ?? '0',
  //         ) ??
  //         0;

  //     if (wrtyAmt > 0) _warrantyCtrl.text = wrtyAmt.toStringAsFixed(2);
  //     if (rsaAmt > 0) _rsaCtrl.text = rsaAmt.toStringAsFixed(2);
  //     if (sotAmt > 0) _sotAmtCtrl.text = sotAmt.toStringAsFixed(2);

  //     // ─────────────────────────────────────────────
  //     // OTHER CAPTIONS & AMOUNTS (from sp_73)
  //     // ASP.NET: ot_cap1/2/3, ot_amt1/2/3
  //     // ─────────────────────────────────────────────
  //     final ot1 = c['ot_cap1']?.toString() ?? '';
  //     final ot2 = c['ot_cap2']?.toString() ?? '';
  //     final ot3 = c['ot_cap3']?.toString() ?? '';
  //     final otAmt1 = c['ot_amt1']?.toString() ?? '0';
  //     final otAmt2 = c['ot_amt2']?.toString() ?? '0';
  //     final otAmt3 = c['ot_amt3']?.toString() ?? '0';
  //     if (ot1.isNotEmpty) _oth1Ctrl.text = ot1;
  //     if (ot2.isNotEmpty) _oth2Ctrl.text = ot2;
  //     if (ot3.isNotEmpty) _oth3Ctrl.text = ot3;
  //     if ((double.tryParse(otAmt1) ?? 0) > 0) _amt1Ctrl.text = _f(otAmt1);
  //     if ((double.tryParse(otAmt2) ?? 0) > 0) _amt2Ctrl.text = _f(otAmt2);
  //     if ((double.tryParse(otAmt3) ?? 0) > 0) _amt3Ctrl.text = _f(otAmt3);

  //     // ─────────────────────────────────────────────
  //     // SCRAPPAGE (pa_109)
  //     // ASP.NET: scrapper (bool flag)
  //     // ─────────────────────────────────────────────
  //     final scrapper = c['scrapper']?.toString().toUpperCase();
  //     if (scrapper == 'TRUE' || scrapper == '1') _scrappage = true;

  //     // ─────────────────────────────────────────────
  //     // CITY / AREA
  //     // ASP.NET: city / cityunq, area / areaunq
  //     // ─────────────────────────────────────────────
  //     _cityName = c['city']?.toString() ?? '';
  //     _cityId = c['cityunq']?.toString();
  //     _areaName = c['area']?.toString() ?? '';
  //     _areaId = c['areaunq']?.toString();

  //     _applyChallanFinancialData(c);
  //   });

  //   // Load the dependent dropdowns exactly like ASP.NET
  //   if (_modelId != null && _modelId!.isNotEmpty) {
  //     try {
  //       final variants = await ApiService.getChallanVariants(_modelId!);

  //       if (!mounted) return;

  //       setState(() {
  //         _variants = variants;
  //       });

  //       if (_variantId != null && _variantId!.isNotEmpty) {
  //         final colors = await ApiService.getChallanColors(_variantId!);

  //         if (!mounted) return;

  //         setState(() {
  //           _colors = colors;
  //         });

  //         if (_colorId != null && _colorId!.isNotEmpty) {
  //           final vins = await ApiService.getChallanVins(
  //             variantId: _variantId!,
  //             colorId: _colorId!,
  //             challanType: _challanType,
  //           );

  //           if (!mounted) return;

  //           setState(() {
  //             _vins = vins;
  //           });
  //         }
  //       }
  //     } catch (e) {
  //       debugPrint('_onCustomerSelected cascade ERROR: $e');
  //     }
  //   }

  //   // Load variant pricing/details
  //   if (_variantId != null && _variantId!.isNotEmpty) {
  //     await _fetchVariantDetails(_variantId!);
  //   }

  //   // Load HPN child branches
  //   if (_hpnParentId != null && _hpnParentId!.isNotEmpty) {
  //     await _loadHpnBranches(_hpnParentId!);
  //   }

  //   // Fetch own RTO for the customer's branch (if not already set by user)
  //   if (_branchId != null && _branchId!.isNotEmpty && _rtoCityId == null) {
  //     await _fetchOwnRtoCity(_branchId!);
  //   }

  //   // Load customer receipt information
  //   await _loadReceiptGrid(id);

  //   // Recalculate ASP.NET totals
  //   _recalculateAspNet();
  // }

  void _onStateSelected(String? id) {
    setState(() => _stateId = id);
    if (_variantId != null) _fetchVariantDetails(_variantId!);
    _recalculateAspNet();
  }

  void _onBranchSelected(String? id) {
    setState(() => _branchId = id);
    if (id != null) {
      _fetchVariantDetails(_variantId ?? '');
      _fetchOwnRtoCity(id);
    }
    _recalculateAspNet();
  }

  Future<void> _fetchOwnRtoCity(String branchId) async {
    if (branchId.isEmpty) return;
    try {
      final row = await ApiService.getChallanOwnRto(branchId);
      if (row == null || !mounted) return;
      setState(() {
        final rtoId = row['data']?.toString() ?? row['sp_332']?.toString();
        if (rtoId != null && rtoId.isNotEmpty) _rtoCityId = rtoId;
        _rtoRateCtrl.text = _f(row['rrate'] ?? row['sp_339']);
        _rtoSurCtrl.text = _f(row['rtax'] ?? row['sp_340']);
        _greenTaxCtrl.text = _f(row['rgreen'] ?? row['sp_341']);
        _regFeeCtrl.text = _f(row['rreg'] ?? row['sp_342']);
        _setHpnRtoMaster(row['rhpn'] ?? row['sp_343']);
        _dupCtrl.text = _f(row['rduplicate'] ?? row['sp_344']);
        _smartCtrl.text = _f(row['rsmartcard'] ?? row['sp_345']);
        _otherRtoCtrl.text = _f(row['rother'] ?? row['sp_346']);
        _trcCtrl.text = '0.00';
      });
      await _fetchRtoTrc();
      _recalculateAspNet();
    } catch (e) {
      print('_fetchOwnRtoCity ERROR: $e');
    }
  }

  void _onChallanTypeSelected(String? value) {
    if (value == null) return;
    setState(() => _challanType = value);
    _reloadCustomersByType(value);
    _recalculateAspNet();
  }

  Future<void> _onRtoCitySelected(String? id) async {
    if (id == null || id.isEmpty) {
      setState(() {
        _rtoCityId = null;
        _trcCtrl.text = '0.00';
      });
      //_recalculateAspNet();
      return;
    }

    final selectedRto = _rtoCities.firstWhere(
      (item) => (item['data'] ?? item['sp_332'] ?? '').toString() == id,
      orElse: () => <String, dynamic>{},
    );

    setState(() {
      _rtoCityId = id;

      if (selectedRto.isNotEmpty) {
        _rtoRateCtrl.text = _f(selectedRto['rrate'] ?? selectedRto['sp_339']);
        _rtoSurCtrl.text = _f(selectedRto['rtax'] ?? selectedRto['sp_340']);
        _greenTaxCtrl.text = _f(selectedRto['rgreen'] ?? selectedRto['sp_341']);
        _regFeeCtrl.text = _f(selectedRto['rreg'] ?? selectedRto['sp_342']);
        _setHpnRtoMaster(selectedRto['rhpn'] ?? selectedRto['sp_343']);
        _dupCtrl.text = _f(selectedRto['rduplicate'] ?? selectedRto['sp_344']);
        _smartCtrl.text = _f(
          selectedRto['rsmartcard'] ?? selectedRto['sp_345'],
        );
        _otherRtoCtrl.text = _f(selectedRto['rother'] ?? selectedRto['sp_346']);
      }

      // Clear the old TRC amount until the city/variant lookup completes.
      _trcCtrl.text = '0.00';
    });

    // Equivalent to the original JavaScript:
    // rtotrc(prefix)

    await _fetchRtoTrc();

    //_recalculateAspNet();
  }

  Future<void> _fetchRtoTrc() async {
    final cityId = _rtoCityId;
    final variantId = _variantId;

    debugPrint('========== FETCH RTO TRC ==========');
    debugPrint('RTO City ID: $cityId');
    debugPrint('Variant ID : $variantId');

    if (cityId == null || cityId.isEmpty) {
      debugPrint('TRC NOT FETCHED: RTO city ID is empty');
      return;
    }

    if (variantId == null || variantId.isEmpty) {
      debugPrint('TRC NOT FETCHED: Variant ID is empty');
      return;
    }

    try {
      debugPrint('Calling ApiService.getRtoTrc...');

      final result = await ApiService.getRtoTrc(
        prefix: 'rh_',
        rtoCityId: cityId,
        variantId: variantId,
      );

      debugPrint('RTO TRC API RESPONSE: $result');

      if (!mounted) return;

      // Ignore an old response if the user selected another city or variant.
      if (cityId != _rtoCityId || variantId != _variantId) return;

      setState(() {
        _trcCtrl.text = _f(result['trc'] ?? 0);
      });

      debugPrint('TRC AMOUNT UPDATED: ${_trcCtrl.text}');

      // _recalculateAspNet();
    } catch (e, stackTrace) {
      debugPrint('FETCH RTO TRC ERROR: $e');
      debugPrint(stackTrace.toString());
    }
  }

  String _f(dynamic v) =>
      (double.tryParse(v?.toString().replaceAll(',', '') ?? '0') ?? 0.0)
          .toStringAsFixed(2);

  double _d(TextEditingController c) =>
      double.tryParse(c.text.replaceAll(',', '').trim()) ?? 0.0;

  void _set(TextEditingController c, double value, {int decimals = 2}) {
    final text = value.isFinite ? value.toStringAsFixed(decimals) : '0.00';
    if (c.text != text) c.text = text;
  }

  // Mirrors the client-side ASP.NET cal() flow. API/master values are filled
  // by the selection handlers; this method only performs deterministic math.
  void _recalculateAspNet() {
    if (!mounted) return;

    final exShow = _d(_exShowCtrl);
    final schemes = _d(_schemesCtrl);
    final subtotal = exShow - schemes;
    _set(_subTotalCtrl, subtotal);

    // TCS: ASP.NET applies it when the applicable subtotal exceeds 10 lakh.
    // The percentage comes from the master/API layer; until it is supplied,
    // preserve an explicitly entered TCS value.
    // if (subtotal <= 1000000) _set(_tcsCtrl, 0);
    // TCS CALCULATION — MATCH LEGACY ASP.NET
    final tcsSubtotal = _tcsCal ? _d(_subTotalCtrl) : exShow;

    final tcsAmount = tcsSubtotal > 1000000
        ? (tcsSubtotal * _tcsPercentage / 100).roundToDouble()
        : 0.0;

    _set(_tcsCtrl, tcsAmount);
    // RTO calculation from Jchallan.js.
    var rtoExShow = _d(_rtoExShowCtrl);
    if (rtoExShow <= 0) {
      rtoExShow = exShow;
      _set(_rtoExShowCtrl, rtoExShow);
    }

    final stateName = _states
        .where((e) => (e['data'] ?? e['id']).toString() == _stateId)
        .map((e) => (e['value'] ?? e['name'] ?? '').toString().toUpperCase())
        .firstWhere((e) => e.isNotEmpty, orElse: () => '');

    final specialRtoState =
        stateName == 'JHARKHAND' ||
        stateName == 'BIHAR' ||
        stateName == 'PUNJAB';
    final remainder = rtoExShow % 1000;
    var rtamt = specialRtoState
        ? rtoExShow
        : (remainder >= 1 ? (rtoExShow - remainder + 1000) : rtoExShow);

    var rtoAmount = 0.0;

    if (_rtoFrom == 'BH') {
      // ============================================================
      // BH RTO CALCULATION - MATCHES Jchallan(5).js
      // ============================================================
      //
      // Jchallan.js:
      //   if bhaftergstamt == True:
      //     rto = rtamt * bhperc / 100
      //             * bhmultiplepa * bhyear / bhyearpa
      //
      //   else:
      //     gst = CGST + SGST
      //     taxonbh = rtamt / (100 + cess + gst) * 100
      //     rto = taxonbh * bhperc / 100
      //             * bhmultiplepa / bhyearpa * bhyear
      //
      final bhRate = _d(_bhPerCtrl);
      final bhYear = _d(_bhYearCtrl);
      final bhPayYear = _bhPayYear > 0 ? _bhPayYear : 15.0;
      final bhMultiple = _bhYearMultiple > 0 ? _bhYearMultiple : 1.25;

      if (bhRate > 0 && bhYear > 0) {
        if (_bhAfterGst) {
          rtoAmount = rtamt * bhRate / 100 * bhMultiple * bhYear / bhPayYear;
        } else {
          final cess = _d(_cessCtrl);
          final gstRate = double.tryParse(_gstUnq ?? '') ?? 0.0;
          final cgst = gstRate / 2;
          final sgst = gstRate / 2;
          final gstAmount = cgst + sgst;

          final taxOnBh = (rtamt / (100 + cess + gstAmount)) * 100;

          rtoAmount = taxOnBh * bhRate / 100 * bhMultiple / bhPayYear * bhYear;
        }

        // The legacy screen's displayed BH RTO amount includes the
        // applicable fixed RTO charges in addition to the BH tax.
        // For the shown case this is: 10395 + 2500 + 600 + 100 = 13595.
        rtoAmount +=
            _d(_greenTaxCtrl) +
            _d(_regFeeCtrl) +
            (_finType == 'Cash' ? 0.0 : _d(_hpnRtoCtrl)) +
            _d(_dupCtrl) +
            _d(_smartCtrl) +
            _d(_otherRtoCtrl) +
            _d(_rtoTempCtrl);
      }
    } else if (_rtoFrom == 'Out House') {
      rtoAmount = 0.0;
    } else {
      final originalRto = rtamt * _d(_rtoRateCtrl) / 100;

      var taxableRto = rtamt;

      if (_scrappage && _scrappagePercent > 0) {
        taxableRto = rtamt * (100 - _scrappagePercent) / 100;
      }

      final rto = taxableRto * _d(_rtoRateCtrl) / 100;

      _scrappageAmount = (_scrappage && _scrappagePercent > 0)
          ? (originalRto - rto).roundToDouble()
          : 0.0;

      final surcharge = rto * _d(_rtoSurCtrl) / 100;

      rtoAmount =
          rto +
          surcharge +
          _d(_greenTaxCtrl) +
          (_scrappage ? 0.0 : _d(_regFeeCtrl)) +
          (_finType == 'Cash' ? 0.0 : _d(_hpnRtoCtrl)) +
          _d(_dupCtrl) +
          _d(_smartCtrl) +
          _d(_otherRtoCtrl) +
          _d(_rtoTempCtrl);
    }

    // Jchallan.js uses toFixed(0) for BH RTO and toFixed(0) after
    // the normal RTO calculation as well; the UI keeps In House/Out House
    // at two decimals in the Flutter form, so only BH is forced to whole
    // number here.
    _set(_rtoAmtCtrl, rtoAmount, decimals: _rtoFrom == 'BH' ? 0 : 2);

    // Insurance calculation from Jchallan.js.
    // ============================================================
    // INSURANCE CALCULATION
    // MATCHES Jchallan(5).js
    // ============================================================

    // ============================================================
    // INSURANCE CALCULATION
    // MATCHES Jchallan(5).js
    // ============================================================

    if (_insType == 'Out House') {
      // Out-house insurance is not calculated by the ASP.NET insurance block.
      for (final c in [
        _cessAmtCtrl,
        _idvAmtCtrl,
        _afterIdvCtrl,
        _insAmtCtrl,
        _disAmtCtrl,
        _afterDisCtrl,
        _cngAmtCtrl,
        _paAmtCtrl,
        _zdAmtCtrl,
        _epAmtCtrl,
        _kpAmtCtrl,
        _afterPdCtrl,
        _rtiAmtCtrl,
        _cmAmtCtrl,
        _cgstCtrl,
        _sgstCtrl,
        _gstAmtCtrl,
        _insAmtFinalCtrl,
        _finalInsCtrl,
      ]) {
        _set(c, 0);
      }
    } else {
      // ============================================================
      // INSURANCE EX-SHOWROOM
      // ============================================================
      final insExShow = _d(_insExShowCtrl) == 0 ? subtotal : _d(_insExShowCtrl);
      _set(_insExShowCtrl, insExShow);

      // ============================================================
      // CESS
      // ASP.NET: txt_sp_504 = round(ex-showroom * cess / 100, 0)
      // ============================================================
      final cess = _d(_cessCtrl);
      final cessAmount = double.parse(
        (insExShow * cess / 100).toStringAsFixed(0),
      );
      _set(_cessAmtCtrl, cessAmount);

      final cessSubtotal = insExShow + cessAmount;

      // ============================================================
      // IDV / AFTER IDV
      // ASP.NET stores After IDV rounded to 0 decimals.
      // ============================================================
      var idvPct = _d(_idvCtrl);
      if (idvPct <= 0) {
        idvPct = 5.0;
        _set(_idvCtrl, idvPct);
      }

      final idvAmount = cessSubtotal * idvPct / 100;
      final afterIdv = double.parse(
        (cessSubtotal - idvAmount).toStringAsFixed(0),
      );

      _set(_idvAmtCtrl, idvAmount);
      _set(_afterIdvCtrl, afterIdv, decimals: 0);

      // ============================================================
      // OD / INSURANCE AMOUNT
      // ============================================================
      final insuranceRate = _d(_insPerCtrl);
      final insuranceAmount = double.parse(
        (afterIdv * insuranceRate / 100).toStringAsFixed(0),
      );
      // The ASP.NET layout shows the Amount field beside After IDV as 0.
      // Keep the calculated OD amount in the local variable for the
      // Discount/After Discount calculation, but do not display it here.
      _set(_insAmtCtrl, 0, decimals: 2);
      _set(_insCalcAmtCtrl, insuranceAmount, decimals: 0);

      // ============================================================
      // DISCOUNT / AFTER DISCOUNT
      // ============================================================
      final discountPct = _d(_insDisCtrl);
      final discountAmount = double.parse(
        (insuranceAmount * discountPct / 100).toStringAsFixed(0),
      );
      final afterDiscount = insuranceAmount - discountAmount;

      _set(_disAmtCtrl, discountAmount, decimals: 0);
      _set(_afterDisCtrl, afterDiscount, decimals: 0);

      // ============================================================
      // CNG
      // ============================================================
      final cngPct = _d(_cngPerCtrl);
      final cngAmount = afterDiscount * cngPct / 100;
      _set(_cngAmtCtrl, cngAmount);

      // ============================================================
      // PA COVER AMOUNT
      // ASP.NET txt_sp_542 = After Discount + Third Party + PA Cover
      // ============================================================
      final paCover = _d(_paCoverCtrl);
      final thirdParty = _d(_thirdPartyCtrl);
      final paAmount = double.parse(
        (afterDiscount + thirdParty + paCover).toStringAsFixed(0),
      );
      _set(_paAmtCtrl, paAmount, decimals: 0);

      // ============================================================
      // EP
      // ASP.NET calculates the percentage amount; unchecked EP is 0
      // in the Flutter UI, matching the current screen behavior.
      // ============================================================
      final epRate = _epAdd ? _d(_epCtrl) : 0.0;
      final epAmount = afterIdv * epRate / 100;
      _set(_epAmtCtrl, epAmount);

      // ============================================================
      // ZD
      // ============================================================
      final zdRate = _d(_zdCtrl);
      final zdAmount = afterIdv * zdRate / 100;
      _set(_zdAmtCtrl, zdAmount);

      // ============================================================
      // RTI
      // ============================================================
      final rtiRate = _rtiAdd ? _d(_rtiCtrl) : 0.0;
      final rtiAmount = afterIdv * rtiRate / 100;
      _set(_rtiAmtCtrl, rtiAmount);

      // ============================================================
      // CM
      // ============================================================
      final cmRate = _cmAdd ? _d(_cmCtrl) : 0.0;
      final cmAmount = afterIdv * cmRate / 100;
      _set(_cmAmtCtrl, cmAmount);

      // ============================================================
      // KP / AFTER ZD
      // ASP.NET txt_sp_517 = round(ZD + EP + PB + KP, 0)
      // ============================================================
      final pb = _d(_pbCtrl);
      final kp = _d(_kpCtrl);
      final afterZd = double.parse(
        (zdAmount + epAmount + pb + kp).toStringAsFixed(0),
      );
      _set(_kpAmtCtrl, afterZd, decimals: 0);

      // ============================================================
      // PAID DRIVER
      // ASP.NET txt_sp_516 comes from the master/insurance data.
      // ============================================================
      final paidDriver = _d(_paidDrvCtrl);

      // ============================================================
      // BEFORE GST / AFTER PD
      // ASP.NET txt_sp_543
      // ============================================================
      final beforeGst =
          afterDiscount +
          thirdParty +
          paCover +
          afterZd +
          paidDriver +
          rtiAmount +
          cmAmount +
          cngAmount;

      _set(_afterPdCtrl, beforeGst);

      // ============================================================
      // GST
      // ASP.NET txt_sp_518 is the GST percentage.
      // ============================================================
      final gstRate = double.tryParse(_gstUnq ?? '') ?? 0.0;
      final cgstRate = gstRate / 2;
      final sgstRate = gstRate / 2;
      final cgstAmount = beforeGst * cgstRate / 100;
      final sgstAmount = beforeGst * sgstRate / 100;
      final gstAmount = cgstAmount + sgstAmount;

      _set(_cgstCtrl, cgstAmount);
      _set(_sgstCtrl, sgstAmount);
      _set(_gstAmtCtrl, gstAmount, decimals: 0);

      // ============================================================
      // FINAL INSURANCE AMOUNT
      // ASP.NET: before GST + GST - NCB
      // ============================================================
      final finalInsurance = beforeGst + gstAmount - _d(_ncbCtrl);

      _set(_finalInsCtrl, finalInsurance, decimals: 0);
      _set(_insAmtFinalCtrl, finalInsurance, decimals: 0);

      debugPrint(
        'INSURANCE RESULT => beforeGST=${beforeGst.toStringAsFixed(2)}, '
        'GST=${gstAmount.toStringAsFixed(2)}, '
        'Final=${finalInsurance.toStringAsFixed(2)}, '
        'PaidDriver=${paidDriver.toStringAsFixed(2)}, '
        'PA=${paAmount.toStringAsFixed(0)}, '
        'AfterZD=${afterZd.toStringAsFixed(0)}',
      );
    }

    // ASP.NET final challan amount (sp_521).
    final total =
        _d(_fastTagCtrl) +
        _d(_tcsCtrl) +
        _d(_trcCtrl) +
        _d(_compAccCtrl) +
        _d(_ownAccCtrl) +
        _d(_warrantyCtrl) +
        _d(_rtoAmtCtrl) +
        _d(_finalInsCtrl) +
        _d(_subTotalCtrl) +
        _d(_amt1Ctrl) +
        _d(_amt2Ctrl) +
        _d(_amt3Ctrl) +
        _d(_workshopInvAmt);
    _set(_totalCtrl, total, decimals: 0);

    final received = _d(_receivedCtrl);
    _set(_balanceCtrl, total - received);
    // Customer Balance is reduced by the actual Customer Received Amt.
    // Cash finance does NOT mean Customer Received Amt is zero.
    final customerReceived = _d(_customerReceivedCtrl);

    _set(_customerBalanceCtrl, total - _d(_loanAmtCtrl) - customerReceived);
    _set(_hpnBalanceCtrl, _d(_hpnRtoCtrl) - _d(_hpnReceivedCtrl));
  }

  double get _rtoTotal => _d(_rtoAmtCtrl);

  double get _grandTotal => _d(_totalCtrl);

  Future<void> _pickDate() async {
    final p = await showDatePicker(
      context: context,
      initialDate: _challanDate,
      firstDate: DateTime(2020),
      lastDate: DateTime(2030),
      builder: (c, ch) => Theme(
        data: Theme.of(
          c,
        ).copyWith(colorScheme: ColorScheme.light(primary: _accent)),
        child: ch!,
      ),
    );
    if (p != null) {
      setState(() => _challanDate = p);
      if (_variantId != null) _fetchVariantDetails(_variantId!);
      await _fetchTcsForDate(p);
      _recalculateAspNet();
    }
  }

  Future<void> _fetchTcsForDate(DateTime date) async {
    try {
      final dateStr =
          '${date.day.toString().padLeft(2, '0')}/'
          '${date.month.toString().padLeft(2, '0')}/'
          '${date.year}';

      final tcs = await ApiService.getChallanTcsData(dateStr);

      if (!mounted) return;

      setState(() {
        _tcsPercentage = tcs;
      });

      _recalculateAspNet();

      debugPrint('TCS Percentage: $_tcsPercentage');
      debugPrint('TCS Amount: ${_tcsCtrl.text}');
    } catch (e) {
      debugPrint('_fetchTcsForDate ERROR: $e');
    }
  }

  // ── Add City popup (+ button) ─────────────────────────────────────────────
  void _openCitySheet() {
    // State pre-filled from what user already selected on the form
    String? selStateId = _stateId;
    final cityCtrl = TextEditingController();
    bool saving = false;

    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setDlg) {
          final isDlgDark = Theme.of(ctx).brightness == Brightness.dark;
          final dlgBg = isDlgDark ? const Color(0xFF1A2535) : Colors.white;
          final labelColor = isDlgDark
              ? const Color(0xFFB0BEC5)
              : const Color(0xFF333333);
          final borderColor = isDlgDark
              ? const Color(0xFF3A4A5A)
              : const Color(0xFFCCCCCC);
          return Dialog(
            backgroundColor: dlgBg,
            insetPadding: const EdgeInsets.symmetric(
              horizontal: 24,
              vertical: 40,
            ),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(4),
            ),
            child: ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 420),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  // ── Header ────────────────────────────────────────
                  Container(
                    padding: const EdgeInsets.fromLTRB(16, 13, 12, 13),
                    decoration: const BoxDecoration(
                      color: Color(0xFF1A8BBF),
                      borderRadius: BorderRadius.vertical(
                        top: Radius.circular(4),
                      ),
                    ),
                    child: Row(
                      children: [
                        const Expanded(
                          child: Text(
                            'Add City',
                            style: TextStyle(
                              color: Colors.white,
                              fontSize: 18,
                              fontWeight: FontWeight.w700,
                            ),
                          ),
                        ),
                        InkWell(
                          onTap: () {
                            cityCtrl.dispose();
                            Navigator.pop(ctx);
                          },
                          child: const Icon(
                            Icons.close,
                            color: Colors.white,
                            size: 20,
                          ),
                        ),
                      ],
                    ),
                  ),

                  // ── Body ──────────────────────────────────────────
                  Padding(
                    padding: const EdgeInsets.fromLTRB(16, 16, 16, 8),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        // State — dropdown, auto-filled from form
                        Row(
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: [
                            SizedBox(
                              width: 56,
                              child: Text(
                                'State *',
                                style: TextStyle(
                                  fontSize: 13,
                                  fontWeight: FontWeight.w600,
                                  color: labelColor,
                                ),
                              ),
                            ),
                            const SizedBox(width: 8),
                            Expanded(
                              child: SizedBox(
                                height: 34,
                                child: DropdownButtonFormField<String>(
                                  value: selStateId,
                                  isDense: true,
                                  isExpanded: true,
                                  style: TextStyle(
                                    fontSize: 13,
                                    color: labelColor,
                                  ),
                                  decoration: InputDecoration(
                                    isDense: true,
                                    contentPadding: const EdgeInsets.symmetric(
                                      horizontal: 8,
                                      vertical: 8,
                                    ),
                                    border: OutlineInputBorder(
                                      borderRadius: const BorderRadius.all(
                                        Radius.circular(3),
                                      ),
                                      borderSide: BorderSide(
                                        color: borderColor,
                                      ),
                                    ),
                                    enabledBorder: OutlineInputBorder(
                                      borderRadius: const BorderRadius.all(
                                        Radius.circular(3),
                                      ),
                                      borderSide: BorderSide(
                                        color: borderColor,
                                      ),
                                    ),
                                    focusedBorder: const OutlineInputBorder(
                                      borderRadius: BorderRadius.all(
                                        Radius.circular(3),
                                      ),
                                      borderSide: BorderSide(
                                        color: Color(0xFF1A8BBF),
                                        width: 1.5,
                                      ),
                                    ),
                                  ),
                                  items: [
                                    const DropdownMenuItem<String>(
                                      value: null,
                                      child: Text(
                                        '-- Select --',
                                        style: TextStyle(fontSize: 13),
                                      ),
                                    ),
                                    ..._states.map(
                                      (s) => DropdownMenuItem<String>(
                                        value: s['data']?.toString(),
                                        child: Text(
                                          s['value']?.toString() ?? '',
                                          style: const TextStyle(fontSize: 13),
                                          overflow: TextOverflow.ellipsis,
                                        ),
                                      ),
                                    ),
                                  ],
                                  onChanged: (v) =>
                                      setDlg(() => selStateId = v),
                                ),
                              ),
                            ),
                          ],
                        ),
                        const SizedBox(height: 12),

                        // City — plain text input (user types new city)
                        Row(
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: [
                            SizedBox(
                              width: 56,
                              child: Text(
                                'City *',
                                style: TextStyle(
                                  fontSize: 13,
                                  fontWeight: FontWeight.w600,
                                  color: labelColor,
                                ),
                              ),
                            ),
                            const SizedBox(width: 8),
                            Expanded(
                              child: SizedBox(
                                height: 34,
                                child: TextField(
                                  controller: cityCtrl,
                                  autofocus: true,
                                  style: const TextStyle(fontSize: 13),
                                  decoration: InputDecoration(
                                    isDense: true,
                                    contentPadding: const EdgeInsets.symmetric(
                                      horizontal: 8,
                                      vertical: 8,
                                    ),
                                    border: OutlineInputBorder(
                                      borderRadius: const BorderRadius.all(
                                        Radius.circular(3),
                                      ),
                                      borderSide: BorderSide(
                                        color: borderColor,
                                      ),
                                    ),
                                    enabledBorder: OutlineInputBorder(
                                      borderRadius: const BorderRadius.all(
                                        Radius.circular(3),
                                      ),
                                      borderSide: BorderSide(
                                        color: borderColor,
                                      ),
                                    ),
                                    focusedBorder: const OutlineInputBorder(
                                      borderRadius: BorderRadius.all(
                                        Radius.circular(3),
                                      ),
                                      borderSide: BorderSide(
                                        color: Color(0xFF1A8BBF),
                                        width: 1.5,
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                            ),
                          ],
                        ),
                        const SizedBox(height: 16),
                      ],
                    ),
                  ),

                  // ── Footer ────────────────────────────────────────
                  Padding(
                    padding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
                    child: Row(
                      children: [
                        ElevatedButton(
                          onPressed: saving
                              ? null
                              : () async {
                                  if (selStateId == null) {
                                    ScaffoldMessenger.of(context).showSnackBar(
                                      const SnackBar(
                                        content: Text('Please select a State'),
                                        behavior: SnackBarBehavior.floating,
                                      ),
                                    );
                                    return;
                                  }
                                  if (cityCtrl.text.trim().isEmpty) {
                                    ScaffoldMessenger.of(context).showSnackBar(
                                      const SnackBar(
                                        content: Text('Please enter City name'),
                                        behavior: SnackBarBehavior.floating,
                                      ),
                                    );
                                    return;
                                  }

                                  // Resolve state display name from ID
                                  final stateRow = _states.firstWhere(
                                    (s) => s['data']?.toString() == selStateId,
                                    orElse: () => {},
                                  );
                                  final stateName =
                                      (stateRow['value'] ?? selStateId ?? '')
                                          .toString();
                                  final cityName = cityCtrl.text
                                      .trim()
                                      .toUpperCase();

                                  setDlg(() => saving = true);
                                  try {
                                    // Insert via A_SP_FOR_ACCOUNTMASTER
                                    // and get back the refreshed city list
                                    final refreshed =
                                        await ApiService.saveChallanCity(
                                          cityName: cityName,
                                          stateName: stateName,
                                        );

                                    // Find the new city entry
                                    final newCity = refreshed.firstWhere(
                                      (c) =>
                                          (c['value'] ?? c['sp_578'] ?? '')
                                              .toString()
                                              .toUpperCase() ==
                                          cityName,
                                      orElse: () => refreshed.isNotEmpty
                                          ? refreshed.last
                                          : {},
                                    );

                                    if (!mounted) return;
                                    setState(() {
                                      _cities = refreshed;
                                      _stateId = selStateId;
                                      if (newCity.isNotEmpty) {
                                        _cityId =
                                            (newCity['data'] ??
                                                    newCity['sp_572'])
                                                ?.toString();
                                        _cityName =
                                            (newCity['value'] ??
                                                    newCity['sp_578'] ??
                                                    cityName)
                                                .toString();
                                      }
                                      _areaId = null;
                                      _areaName = '';
                                    });

                                    cityCtrl.dispose();
                                    if (ctx.mounted) Navigator.pop(ctx);
                                  } catch (e) {
                                    setDlg(() => saving = false);
                                    if (!mounted) return;
                                    ScaffoldMessenger.of(context).showSnackBar(
                                      SnackBar(
                                        content: Text(
                                          'Error: ${e.toString().replaceAll('Exception: ', '')}',
                                        ),
                                        backgroundColor: const Color(
                                          0xFFE53935,
                                        ),
                                        behavior: SnackBarBehavior.floating,
                                      ),
                                    );
                                  }
                                },
                          style: ElevatedButton.styleFrom(
                            backgroundColor: const Color(0xFF337AB7),
                            foregroundColor: Colors.white,
                            elevation: 0,
                            padding: const EdgeInsets.symmetric(
                              horizontal: 20,
                              vertical: 9,
                            ),
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(3),
                            ),
                            textStyle: const TextStyle(
                              fontSize: 13,
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                          child: saving
                              ? const SizedBox(
                                  width: 16,
                                  height: 16,
                                  child: CircularProgressIndicator(
                                    strokeWidth: 2,
                                    color: Colors.white,
                                  ),
                                )
                              : const Text('Save'),
                        ),
                        const SizedBox(width: 8),
                        ElevatedButton(
                          onPressed: saving
                              ? null
                              : () {
                                  cityCtrl.dispose();
                                  Navigator.pop(ctx);
                                },
                          style: ElevatedButton.styleFrom(
                            backgroundColor: const Color(0xFFD9534F),
                            foregroundColor: Colors.white,
                            elevation: 0,
                            padding: const EdgeInsets.symmetric(
                              horizontal: 20,
                              vertical: 9,
                            ),
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(3),
                            ),
                            textStyle: const TextStyle(
                              fontSize: 13,
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                          child: const Text('Cancel'),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }

  // ── Add Area popup (+ button) ─────────────────────────────────────────────
  void _openAreaSheet() {
    final areaCtrl = TextEditingController();
    bool saving = false;

    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setDlg) {
          final isDlgDark = Theme.of(ctx).brightness == Brightness.dark;
          final dlgBg = isDlgDark ? const Color(0xFF1A2535) : Colors.white;
          final labelColor = isDlgDark
              ? const Color(0xFFB0BEC5)
              : const Color(0xFF333333);
          final borderColor = isDlgDark
              ? const Color(0xFF3A4A5A)
              : const Color(0xFFCCCCCC);
          return Dialog(
            backgroundColor: dlgBg,
            insetPadding: const EdgeInsets.symmetric(
              horizontal: 24,
              vertical: 40,
            ),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(4),
            ),
            child: ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 420),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  // ── Header ──────────────────────────────────────────
                  Container(
                    padding: const EdgeInsets.fromLTRB(16, 13, 12, 13),
                    decoration: const BoxDecoration(
                      color: Color(0xFF1A8BBF),
                      borderRadius: BorderRadius.vertical(
                        top: Radius.circular(4),
                      ),
                    ),
                    child: Row(
                      children: [
                        const Expanded(
                          child: Text(
                            'Add Area',
                            style: TextStyle(
                              color: Colors.white,
                              fontSize: 18,
                              fontWeight: FontWeight.w700,
                            ),
                          ),
                        ),
                        InkWell(
                          onTap: () {
                            if (saving) return;
                            areaCtrl.dispose();
                            Navigator.pop(ctx);
                          },
                          child: const Icon(
                            Icons.close,
                            color: Colors.white,
                            size: 20,
                          ),
                        ),
                      ],
                    ),
                  ),

                  // ── Body ────────────────────────────────────────────
                  Padding(
                    padding: const EdgeInsets.fromLTRB(16, 16, 16, 8),
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        SizedBox(
                          width: 56,
                          child: Text(
                            'Area *',
                            style: TextStyle(
                              fontSize: 13,
                              fontWeight: FontWeight.w600,
                              color: labelColor,
                            ),
                          ),
                        ),
                        const SizedBox(width: 8),
                        Expanded(
                          child: SizedBox(
                            height: 34,
                            child: TextField(
                              controller: areaCtrl,
                              autofocus: true,
                              enabled: !saving,
                              style: const TextStyle(fontSize: 13),
                              decoration: InputDecoration(
                                isDense: true,
                                contentPadding: const EdgeInsets.symmetric(
                                  horizontal: 8,
                                  vertical: 8,
                                ),
                                border: OutlineInputBorder(
                                  borderRadius: const BorderRadius.all(
                                    Radius.circular(3),
                                  ),
                                  borderSide: BorderSide(color: borderColor),
                                ),
                                enabledBorder: OutlineInputBorder(
                                  borderRadius: const BorderRadius.all(
                                    Radius.circular(3),
                                  ),
                                  borderSide: BorderSide(color: borderColor),
                                ),
                                focusedBorder: const OutlineInputBorder(
                                  borderRadius: BorderRadius.all(
                                    Radius.circular(3),
                                  ),
                                  borderSide: BorderSide(
                                    color: Color(0xFF1A8BBF),
                                    width: 1.5,
                                  ),
                                ),
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),

                  const SizedBox(height: 8),

                  // ── Footer ──────────────────────────────────────────
                  Padding(
                    padding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
                    child: Row(
                      children: [
                        ElevatedButton(
                          onPressed: saving
                              ? null
                              : () async {
                                  final name = areaCtrl.text.trim();
                                  if (name.isEmpty) {
                                    ScaffoldMessenger.of(context).showSnackBar(
                                      const SnackBar(
                                        content: Text('Please fill out Area'),
                                        behavior: SnackBarBehavior.floating,
                                      ),
                                    );
                                    return;
                                  }

                                  setDlg(() => saving = true);
                                  try {
                                    // Insert via A_SP_FOR_AreaMaster
                                    // and get back the refreshed area list
                                    final refreshed =
                                        await ApiService.saveChallanArea(
                                          areaName: name.toUpperCase(),
                                        );

                                    // Find the newly inserted area
                                    final newArea = refreshed.firstWhere(
                                      (a) =>
                                          (a['value'] ?? a['sp_217'] ?? '')
                                              .toString()
                                              .toUpperCase() ==
                                          name.toUpperCase(),
                                      orElse: () => refreshed.isNotEmpty
                                          ? refreshed.last
                                          : {},
                                    );

                                    if (!mounted) return;
                                    setState(() {
                                      _areas = refreshed;
                                      if (newArea.isNotEmpty) {
                                        _areaId =
                                            (newArea['data'] ??
                                                    newArea['sp_212'])
                                                ?.toString();
                                        _areaName =
                                            (newArea['value'] ??
                                                    newArea['sp_217'] ??
                                                    name)
                                                .toString();
                                      } else {
                                        // fallback: just show typed name
                                        _areaId = null;
                                        _areaName = name;
                                      }
                                    });

                                    areaCtrl.dispose();
                                    if (ctx.mounted) Navigator.pop(ctx);
                                  } catch (e) {
                                    setDlg(() => saving = false);
                                    if (!mounted) return;
                                    ScaffoldMessenger.of(context).showSnackBar(
                                      SnackBar(
                                        content: Text(
                                          'Error: ${e.toString().replaceAll('Exception: ', '')}',
                                        ),
                                        backgroundColor: const Color(
                                          0xFFE53935,
                                        ),
                                        behavior: SnackBarBehavior.floating,
                                      ),
                                    );
                                  }
                                },
                          style: ElevatedButton.styleFrom(
                            backgroundColor: const Color(0xFF337AB7),
                            foregroundColor: Colors.white,
                            elevation: 0,
                            padding: const EdgeInsets.symmetric(
                              horizontal: 20,
                              vertical: 9,
                            ),
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(3),
                            ),
                            textStyle: const TextStyle(
                              fontSize: 13,
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                          child: saving
                              ? const SizedBox(
                                  width: 16,
                                  height: 16,
                                  child: CircularProgressIndicator(
                                    strokeWidth: 2,
                                    color: Colors.white,
                                  ),
                                )
                              : const Text('Save'),
                        ),
                        const SizedBox(width: 8),
                        ElevatedButton(
                          onPressed: saving
                              ? null
                              : () {
                                  areaCtrl.dispose();
                                  Navigator.pop(ctx);
                                },
                          style: ElevatedButton.styleFrom(
                            backgroundColor: const Color(0xFFD9534F),
                            foregroundColor: Colors.white,
                            elevation: 0,
                            padding: const EdgeInsets.symmetric(
                              horizontal: 20,
                              vertical: 9,
                            ),
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(3),
                            ),
                            textStyle: const TextStyle(
                              fontSize: 13,
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                          child: const Text('Cancel'),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }

  // ── Add Account Dialog (RTO City + button) ────────────────────────────────
  void _showAddAccountDialog() {
    final rtoCityCtrl = TextEditingController();
    final mainCityCtrl = TextEditingController();

    final chargeNames = <String>[
      'Rto Rate',
      'Rto Tax Surcharge',
      'Green Tax',
      'Reg Fee',
      'HPN',
      'Duplicate',
      'Smart Card',
      'Other',
      'TRC',
    ];

    final selectedCharges = <String, bool>{
      for (final name in chargeNames) name: false,
    };

    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setDlg) {
          final allSelected = selectedCharges.values.every((v) => v);
          final isDlgDark = Theme.of(ctx).brightness == Brightness.dark;
          final dlgBg = isDlgDark ? const Color(0xFF1A2535) : Colors.white;
          final footerBg = isDlgDark
              ? const Color(0xFF0F1923)
              : const Color(0xFFF2F2F2);

          return Dialog(
            backgroundColor: dlgBg,
            insetPadding: const EdgeInsets.symmetric(
              horizontal: 24,
              vertical: 24,
            ),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(2),
            ),
            child: ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 650),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  // Header
                  Container(
                    width: double.infinity,
                    padding: const EdgeInsets.symmetric(
                      horizontal: 20,
                      vertical: 12,
                    ),
                    decoration: const BoxDecoration(
                      color: Color(0xFF0D55A7),
                      borderRadius: BorderRadius.vertical(
                        top: Radius.circular(2),
                      ),
                    ),
                    child: Row(
                      children: [
                        const Expanded(
                          child: Text(
                            'Add Account',
                            style: TextStyle(
                              color: Colors.white,
                              fontSize: 22,
                              fontWeight: FontWeight.w800,
                            ),
                          ),
                        ),
                        InkWell(
                          onTap: () {
                            rtoCityCtrl.dispose();
                            mainCityCtrl.dispose();
                            Navigator.pop(ctx);
                          },
                          child: const Icon(
                            Icons.close,
                            color: Colors.white,
                            size: 27,
                          ),
                        ),
                      ],
                    ),
                  ),

                  // Body
                  Padding(
                    padding: const EdgeInsets.fromLTRB(14, 14, 14, 8),
                    child: Column(
                      children: [
                        _accountTextRow('Rto City :', rtoCityCtrl),
                        const SizedBox(height: 10),
                        _accountTextRow('Main City :', mainCityCtrl),
                        const SizedBox(height: 8),

                        Row(
                          children: [
                            const Expanded(
                              child: Text(
                                'RTO Charges Applicable',
                                style: TextStyle(
                                  fontSize: 13,
                                  fontWeight: FontWeight.w700,
                                ),
                              ),
                            ),
                            const Text(
                              'Check All',
                              style: TextStyle(
                                fontSize: 13,
                                fontWeight: FontWeight.w700,
                              ),
                            ),
                            SizedBox(
                              width: 22,
                              height: 22,
                              child: Checkbox(
                                value: allSelected,
                                visualDensity: VisualDensity.compact,
                                onChanged: (value) {
                                  setDlg(() {
                                    for (final name in chargeNames) {
                                      selectedCharges[name] = value ?? false;
                                    }
                                  });
                                },
                              ),
                            ),
                          ],
                        ),

                        ...chargeNames.map(
                          (name) => SizedBox(
                            height: 25,
                            child: Row(
                              children: [
                                Expanded(
                                  child: Text(
                                    name,
                                    style: const TextStyle(
                                      fontSize: 13,
                                      fontWeight: FontWeight.w500,
                                    ),
                                  ),
                                ),
                                SizedBox(
                                  width: 22,
                                  height: 22,
                                  child: Checkbox(
                                    value: selectedCharges[name],
                                    visualDensity: VisualDensity.compact,
                                    onChanged: (value) {
                                      setDlg(() {
                                        selectedCharges[name] = value ?? false;
                                      });
                                    },
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),

                  // Footer
                  Container(
                    width: double.infinity,
                    padding: const EdgeInsets.fromLTRB(14, 10, 14, 12),
                    color: footerBg,
                    child: Row(
                      children: [
                        ElevatedButton(
                          onPressed: () async {
                            final rtoCity = rtoCityCtrl.text.trim();
                            final mainCity = mainCityCtrl.text.trim();

                            if (rtoCity.isEmpty || mainCity.isEmpty) {
                              _snack(
                                'Please fill out Rto City and Main City',
                                isError: true,
                              );
                              return;
                            }

                            try {
                              // Call the API to save the city in SQL Server.
                              final refreshedCities =
                                  await ApiService.saveRtoCity(
                                    rtoCity: rtoCity,
                                    mainCity: mainCity,
                                    charges: Map<String, bool>.from(
                                      selectedCharges,
                                    ),
                                  );

                              if (!mounted || !ctx.mounted) return;

                              // Find the newly saved RTO city.
                              final match = refreshedCities.firstWhere(
                                (row) =>
                                    (row['value'] ?? row['sp_337'] ?? '')
                                        .toString()
                                        .trim()
                                        .toUpperCase() ==
                                    rtoCity.toUpperCase(),
                                orElse: () => <String, dynamic>{},
                              );

                              setState(() {
                                _rtoCities = refreshedCities;
                                _cityName = mainCity;

                                if (match.isNotEmpty) {
                                  _rtoCityId =
                                      (match['data'] ?? match['sp_332'])
                                          ?.toString();
                                }
                              });

                              rtoCityCtrl.dispose();
                              mainCityCtrl.dispose();
                              Navigator.pop(ctx);

                              _snack('RTO city saved successfully');
                            } catch (e) {
                              if (!mounted) return;

                              _snack(
                                'Failed to save RTO city: '
                                '${e.toString().replaceFirst('Exception: ', '')}',
                                isError: true,
                              );
                            }
                          },

                          style: ElevatedButton.styleFrom(
                            backgroundColor: isDlgDark
                                ? const Color(0xFF1A2535)
                                : Colors.white,
                            foregroundColor: const Color(0xFF1675D1),
                            elevation: 0,
                            side: const BorderSide(color: Color(0xFF1675D1)),
                            padding: const EdgeInsets.symmetric(
                              horizontal: 22,
                              vertical: 9,
                            ),
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(3),
                            ),
                          ),
                          child: const Text(
                            'Save',
                            style: TextStyle(
                              fontSize: 13,
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                        ),
                        const SizedBox(width: 7),
                        ElevatedButton(
                          onPressed: () {
                            rtoCityCtrl.dispose();
                            mainCityCtrl.dispose();
                            Navigator.pop(ctx);
                          },
                          style: ElevatedButton.styleFrom(
                            backgroundColor: const Color(0xFFF44336),
                            foregroundColor: Colors.white,
                            elevation: 0,
                            padding: const EdgeInsets.symmetric(
                              horizontal: 20,
                              vertical: 9,
                            ),
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(3),
                            ),
                          ),
                          child: const Text(
                            'Cancel',
                            style: TextStyle(
                              fontSize: 13,
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }

  Widget _accountTextRow(String label, TextEditingController controller) {
    return Row(
      children: [
        SizedBox(
          width: 82,
          child: Text(
            label,
            style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w700),
          ),
        ),
        SizedBox(
          width: 140,
          height: 31,
          child: TextField(
            controller: controller,
            style: const TextStyle(fontSize: 12),
            decoration: const InputDecoration(
              isDense: true,
              contentPadding: EdgeInsets.symmetric(horizontal: 7, vertical: 7),
              border: OutlineInputBorder(
                borderRadius: BorderRadius.zero,
                borderSide: BorderSide(color: Color(0xFFCCCCCC)),
              ),
              enabledBorder: OutlineInputBorder(
                borderRadius: BorderRadius.zero,
                borderSide: BorderSide(color: Color(0xFFCCCCCC)),
              ),
              focusedBorder: OutlineInputBorder(
                borderRadius: BorderRadius.zero,
                borderSide: BorderSide(color: Color(0xFF1675D1)),
              ),
            ),
          ),
        ),
      ],
    );
  }

  InputDecoration _dlgDec() => InputDecoration(
    border: OutlineInputBorder(borderRadius: BorderRadius.circular(4)),
    enabledBorder: OutlineInputBorder(
      borderRadius: BorderRadius.circular(4),
      borderSide: const BorderSide(color: Color(0xFFCCCCCC)),
    ),
    focusedBorder: OutlineInputBorder(
      borderRadius: BorderRadius.circular(4),
      borderSide: BorderSide(color: _primary, width: 1.5),
    ),
    contentPadding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
    isDense: true,
  );

  // ── Save / Update ─────────────────────────────────────────────────────────
  Future<void> _challansavelatest() async {
    // _recalculateAspNet();

    if (!_formKey.currentState!.validate()) return;

    if (_custId == null) {
      _snack('Please select a customer', isError: true);
      return;
    }

    if (_vinNo == null && !_isEditing) {
      _snack('Please select a VIN', isError: true);
      return;
    }

    setState(() => _saving = true);

    try {
      final payload = <String, dynamic>{
        'prefix': 'rh_',

        // City and area
        'pageno': _cityId ?? '',
        'sp_465': _areaId ?? '',

        'sp_462': _isEditing ? _editUnq : '0',
        'sp_463': '',
        'sp_464': '',
        'sp_467': DateFormat('dd/MM/yyyy').format(_challanDate),
        'sp_468': _challanNo.toString(),
        'sp_469': _custId,
        'sp_470': _modelId,
        'sp_471': _variantId,
        'sp_472': _colorId,
        'sp_473': _vinNo,
        'sp_558': _challanType,
        'sp_562': '',
        'sp_594': _branchId ?? '',
        'sp_610': _stateId ?? '',
        'sp_538': _title,
        'sp_524': _addressCtrl.text,
        'sp_526': _mobileCtrl.text,

        // Customer details
        'sp_525': _fatherCtrl.text,
        'sp_527': _aadharCtrl.text,
        'sp_528': _panCtrl.text,
        'sp_532': _gstinCtrl.text,
        'sp_550': _scCtrl.text,
        'sp_551': _tlCtrl.text,
        'sp_552': _managerCtrl.text,
        'sp_535': _engineCtrl.text,
        'sp_529': _nomineeCtrl.text,
        'sp_530': _ageCtrl.text,
        'sp_531': _relation,

        // Finance
        'sp_547': _finType == 'Cash'
            ? 'Cash'
            : (_finType == 'In House' ? 'in' : 'out'),
        'sp_523': _hpnChildId ?? _hypCtrl.text,
        'sp_605': _hpnParentId ?? '',
        'sp_536': _branchNameCtrl.text,
        'sp_537': _loanAmtCtrl.text,
        'sp_561': _loanAmtCtrl.text,

        // Discounts
        'sp_483': _corpYn,
        'sp_484': _corpValCtrl.text,
        'sp_485': _corpGiven,
        'sp_486': _exchYn,
        'sp_487': _exchValCtrl.text,
        'sp_488': _exchGiven,
        'sp_611': _dealYn,
        'sp_612': _dealValCtrl.text,
        'sp_613': _dealGiven,
        'sp_489': _loyYn,
        'sp_490': _loyValCtrl.text,
        'sp_491': _loyGiven,
        'sp_482': _exShowCtrl.text,
        'sp_522': _schemesCtrl.text,
        'sp_503': _subTotalCtrl.text,

        // Insurance
        'sp_548': _insType == 'In House' ? 'in' : 'out',
        'sp_520': _finalInsCtrl.text,
        'sp_502': _cessCtrl.text,
        'sp_504': _cessAmtCtrl.text,
        'sp_505': _idvCtrl.text,
        'sp_506': _idvAmtCtrl.text,
        'sp_507': _insPerCtrl.text,
        'sp_508': _insCalcAmtCtrl.text,
        'sp_509': _insDisCtrl.text.trim().isEmpty
            ? '30'
            : _insDisCtrl.text.trim(),
        'sp_510': _disAmtCtrl.text,
        'sp_511': _thirdPartyCtrl.text,
        'sp_512': _paCoverCtrl.text,
        'sp_513': _zdCtrl.text,
        'sp_554': _zdAmtCtrl.text,
        'sp_553': _epCtrl.text,
        'sp_555': _epAmtCtrl.text,
        'sp_514': _pbCtrl.text,
        'sp_515': _kpCtrl.text,
        'sp_516': _paidDrvCtrl.text,
        'sp_517': _kpAmtCtrl.text,
        'sp_600': _rtiCtrl.text,
        'sp_601': _rtiAmtCtrl.text,
        'sp_602': _cmCtrl.text,
        'sp_603': _cmAmtCtrl.text,
        'sp_556': _sgstCtrl.text,
        'sp_557': _cgstCtrl.text,
        'sp_518': _gstUnq ?? '',
        'sp_519': _gstAmtCtrl.text,
        'sp_539': _afterIdvCtrl.text,
        'sp_540': _insAmtCtrl.text,
        'sp_541': _afterDisCtrl.text,
        'sp_542': _paAmtCtrl.text,
        'sp_543': _afterPdCtrl.text,
        'sp_634': _cngPerCtrl.text,
        'sp_635': _cngAmtCtrl.text,
        'sp_544': _addLessCtrl.text,
        'sp_615': _ncbCtrl.text,
        'sp_560': _insExShowCtrl.text,

        // RTO
        'sp_533': _rtoCityId ?? '',
        'sp_534': _rtoFrom == 'In House'
            ? 'in'
            : (_rtoFrom == 'Out House' ? 'out' : 'bh'),
        'sp_492': _rtoRateCtrl.text,
        'sp_493': _rtoSurCtrl.text,
        'sp_494': _greenTaxCtrl.text,
        'sp_495': _regFeeCtrl.text,
        'sp_496': _finType == 'Cash' ? '0.00' : _hpnRtoCtrl.text,
        'sp_497': _dupCtrl.text,
        'sp_498': _smartCtrl.text,
        'sp_499': _otherRtoCtrl.text,
        'sp_500': _rtoAmtCtrl.text,
        'sp_614': _rtoTempCtrl.text,
        'sp_636': _bhPerCtrl.text,
        'sp_637': _bhYearCtrl.text,
        'sp_549': _rtoExShowCtrl.text,

        'sp_653': _scrappagePercent.toStringAsFixed(2),
        'sp_654': _scrappageAmount.toStringAsFixed(0),

        // Other amounts
        'sp_617': _oth1Ctrl.text,
        'sp_620': _amt1Ctrl.text,
        'sp_618': _oth2Ctrl.text,
        'sp_621': _amt2Ctrl.text,
        'sp_619': _oth3Ctrl.text,
        'sp_622': _amt3Ctrl.text,
        'sp_623': _workshopInvNo.text,
        'sp_624': _workshopInvAmt.text,
        'sp_477': _trcCtrl.text,
        'sp_478': _compAccCtrl.text,
        'sp_573': _ownAccCtrl.text,
        'sp_479': _warrantyCtrl.text,
        'sp_480': _warrantyYrCtrl.text,
        'sp_481': _warrantyCtrl.text,
        'sp_474': _fastTagCtrl.text,
        'sp_476': _tcsCtrl.text,
        'sp_521': _totalCtrl.text,

        // Remarks
        'sp_616': _remarkCtrl.text,
        'sp_585': _appRemarkCtrl.text,
        'sp_581': _rejRemarkCtrl.text,
        'sp_591': '0',
        'sp_592': '0',
      };

      if (_isEditing) {
        if (!mounted) return;

        _snack('Challan updated — No. $_challanNo');
      } else {
        print('Flutter sp_483: ${payload['sp_483']}');
        print('Flutter sp_509: ${payload['sp_509']}');
        print('Flutter sp_510: ${payload['sp_510']}');
        await ApiService.saveChallanNew(payload);
        if (!mounted) return;
        _snack('Challan saved — No. $_challanNo');
      }

      Navigator.pop(context, true);
    } catch (e) {
      if (!mounted) return;
      _snack('Error: $e', isError: true);
    } finally {
      if (mounted) setState(() => _saving = false);
    }
  }

  void _snack(String m, {bool isError = false}) =>
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(m),
          behavior: SnackBarBehavior.floating,
          backgroundColor: isError
              ? const Color(0xFFE53935)
              : const Color(0xFF1B8A5A),
        ),
      );

  // ═══════════════════════════════════════════════════════════════════════════
  //  BUILD
  // ═══════════════════════════════════════════════════════════════════════════
  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final bg = isDark ? const Color(0xFF0B1422) : const Color(0xFFF4F7FC);

    return Scaffold(
      backgroundColor: bg,
      body: Column(
        children: [
          _appBar(isDark),
          Expanded(
            child: _loading
                ? _loader()
                : _initError != null
                ? _errWidget()
                : FadeTransition(
                    opacity: _fadeAnim,
                    child: Form(
                      key: _formKey,
                      child: SingleChildScrollView(
                        controller: _scrollCtrl,
                        physics: const BouncingScrollPhysics(),
                        padding: const EdgeInsets.fromLTRB(10, 10, 10, 150),
                        child: Column(
                          children: [
                            _pageTitleBar(),
                            const SizedBox(height: 16),
                            _pad(_secHeader()),
                            const SizedBox(height: 16),
                            _sectionDivider('Finance'),
                            _pad(_secFinance()),
                            const SizedBox(height: 16),
                            _sectionDivider('Discounts & Offers'),
                            _pad(_secDiscounts()),
                            const SizedBox(height: 16),
                            _sectionDivider('Insurance'),
                            _pad(_secInsurance()),
                            const SizedBox(height: 16),
                            _sectionDivider('RTO'),
                            _pad(_secRto()),
                            const SizedBox(height: 16),
                            _sectionDivider('Others'),
                            _pad(_secOthers()),
                            const SizedBox(height: 16),
                            _sectionDivider('Final Details'),
                            _pad(_secBottomAmounts()),
                            const SizedBox(height: 16),
                            _sectionDivider('Receipts'),
                            _pad(_secReceipts()),
                            const SizedBox(height: 16),
                            _sectionDivider('Balances'),
                            _pad(_secBalances()),
                            const SizedBox(height: 16),
                            _sectionDivider('Remarks'),
                            _pad(_secRemarks()),
                          ],
                        ),
                      ),
                    ),
                  ),
          ),
        ],
      ),
      bottomNavigationBar: _bottomBar(isDark),
    );
  }

  // ── Modern app bar ────────────────────────────────────────────────────────
  Widget _appBar(bool isDark) {
    return LayoutBuilder(
      builder: (context, constraints) {
        final mobile = constraints.maxWidth < 600;
        return Container(
          decoration: BoxDecoration(
            gradient: LinearGradient(
              colors: isDark
                  ? const [
                      Color(0xFF071B35),
                      Color(0xFF123E78),
                      Color(0xFF0D5BB5),
                    ]
                  : const [
                      Color(0xFF082B5C),
                      Color(0xFF0D55A7),
                      Color(0xFF1675D1),
                    ],
              stops: const [0.0, 0.52, 1.0],
            ),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withValues(alpha: 0.20),
                blurRadius: 20,
                offset: const Offset(0, 6),
              ),
            ],
          ),
          child: SafeArea(
            bottom: false,
            child: Padding(
              padding: EdgeInsets.fromLTRB(
                12,
                mobile ? 8 : 12,
                12,
                mobile ? 9 : 14,
              ),
              child: mobile
                  ? Row(
                      children: [
                        _headerIconButton(
                          Icons.arrow_back_rounded,
                          () => Navigator.pop(context),
                        ),
                        const SizedBox(width: 8),
                        Container(
                          width: 42,
                          height: 42,
                          decoration: BoxDecoration(
                            color: Colors.white.withValues(alpha: 0.13),
                            borderRadius: BorderRadius.circular(13),
                            border: Border.all(
                              color: Colors.white.withValues(alpha: 0.18),
                            ),
                          ),
                          child: const Icon(
                            Icons.receipt_long_rounded,
                            color: Colors.white,
                            size: 22,
                          ),
                        ),
                        const SizedBox(width: 9),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Text(
                                _isEditing ? 'Edit Challan' : 'New Challan',
                                style: TextStyle(
                                  color: Colors.white,
                                  fontSize: 18,
                                  fontWeight: FontWeight.w800,
                                ),
                              ),
                              SizedBox(height: 2),
                              Text(
                                'Customer • Vehicle • Finance',
                                maxLines: 1,
                                overflow: TextOverflow.ellipsis,
                                style: TextStyle(
                                  color: Colors.white70,
                                  fontSize: 10.5,
                                  fontWeight: FontWeight.w500,
                                ),
                              ),
                            ],
                          ),
                        ),
                        const SizedBox(width: 7),
                        Flexible(
                          child: Container(
                            constraints: const BoxConstraints(maxWidth: 118),
                            padding: const EdgeInsets.symmetric(
                              horizontal: 9,
                              vertical: 7,
                            ),
                            decoration: BoxDecoration(
                              color: Colors.white.withValues(alpha: 0.12),
                              borderRadius: BorderRadius.circular(12),
                              border: Border.all(
                                color: Colors.white.withValues(alpha: 0.20),
                              ),
                            ),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.end,
                              children: [
                                Text(
                                  'CHALLAN NO.',
                                  maxLines: 1,
                                  overflow: TextOverflow.ellipsis,
                                  style: TextStyle(
                                    color: Colors.white.withValues(alpha: 0.65),
                                    fontSize: 7,
                                    fontWeight: FontWeight.w700,
                                  ),
                                ),
                                const SizedBox(height: 1),
                                FittedBox(
                                  fit: BoxFit.scaleDown,
                                  alignment: Alignment.centerRight,
                                  child: Text(
                                    '$_challanNo',
                                    style: const TextStyle(
                                      color: Colors.white,
                                      fontSize: 12.5,
                                      fontWeight: FontWeight.w900,
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ],
                    )
                  : Row(
                      children: [
                        _headerIconButton(
                          Icons.arrow_back_rounded,
                          () => Navigator.pop(context),
                        ),
                        const SizedBox(width: 12),
                        Container(
                          width: 48,
                          height: 48,
                          decoration: BoxDecoration(
                            color: Colors.white.withValues(alpha: 0.13),
                            borderRadius: BorderRadius.circular(15),
                            border: Border.all(
                              color: Colors.white.withValues(alpha: 0.18),
                            ),
                          ),
                          child: const Icon(
                            Icons.receipt_long_rounded,
                            color: Colors.white,
                            size: 25,
                          ),
                        ),
                        const SizedBox(width: 13),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              const Text(
                                'New Challan',
                                style: TextStyle(
                                  color: Colors.white,
                                  fontSize: 21,
                                  fontWeight: FontWeight.w800,
                                ),
                              ),
                              const SizedBox(height: 3),
                              Text(
                                'Create customer • vehicle • finance details',
                                style: TextStyle(
                                  color: Colors.white.withValues(alpha: 0.72),
                                  fontSize: 11.5,
                                  fontWeight: FontWeight.w500,
                                ),
                              ),
                            ],
                          ),
                        ),
                        Container(
                          padding: const EdgeInsets.symmetric(
                            horizontal: 15,
                            vertical: 9,
                          ),
                          decoration: BoxDecoration(
                            color: Colors.white.withValues(alpha: 0.12),
                            borderRadius: BorderRadius.circular(14),
                            border: Border.all(
                              color: Colors.white.withValues(alpha: 0.22),
                            ),
                          ),
                          child: Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              const Icon(
                                Icons.confirmation_number_outlined,
                                color: Colors.white,
                                size: 18,
                              ),
                              const SizedBox(width: 8),
                              Column(
                                crossAxisAlignment: CrossAxisAlignment.end,
                                children: [
                                  Text(
                                    'CHALLAN NO.',
                                    style: TextStyle(
                                      color: Colors.white.withValues(
                                        alpha: 0.65,
                                      ),
                                      fontSize: 8,
                                      fontWeight: FontWeight.w700,
                                      letterSpacing: 0.8,
                                    ),
                                  ),
                                  const SizedBox(height: 2),
                                  Text(
                                    '$_challanNo',
                                    style: const TextStyle(
                                      color: Colors.white,
                                      fontSize: 14,
                                      fontWeight: FontWeight.w900,
                                    ),
                                  ),
                                ],
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
            ),
          ),
        );
      },
    );
  }

  Widget _headerIconButton(IconData icon, VoidCallback onTap) => Material(
    color: Colors.transparent,
    child: InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(12),
      child: Container(
        width: 42,
        height: 42,
        decoration: BoxDecoration(
          color: Colors.white.withValues(alpha: 0.12),
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: Colors.white.withValues(alpha: 0.22)),
        ),
        child: Icon(icon, color: Colors.white, size: 21),
      ),
    ),
  );

  Widget _pageTitleBar() {
    return LayoutBuilder(
      builder: (context, constraints) {
        final mobile = constraints.maxWidth < 600;
        return Container(
          width: double.infinity,
          padding: EdgeInsets.fromLTRB(
            mobile ? 14 : 18,
            mobile ? 12 : 14,
            mobile ? 14 : 18,
            mobile ? 12 : 14,
          ),
          decoration: BoxDecoration(
            gradient: const LinearGradient(
              colors: [Color(0xFF0A1B32), Color(0xFF1675D1), Color(0xFF69B5F6)],
              begin: Alignment.centerLeft,
              end: Alignment.centerRight,
            ),
            borderRadius: BorderRadius.circular(16),
            boxShadow: [
              BoxShadow(
                color: const Color(0xFF0A1B32).withValues(alpha: 0.18),
                blurRadius: 16,
                offset: const Offset(0, 6),
              ),
            ],
          ),
          child: Row(
            children: [
              Container(
                width: mobile ? 38 : 44,
                height: mobile ? 38 : 44,
                decoration: BoxDecoration(
                  color: Colors.white.withValues(alpha: 0.16),
                  borderRadius: BorderRadius.circular(13),
                  border: Border.all(
                    color: Colors.white.withValues(alpha: 0.25),
                  ),
                ),
                child: Icon(
                  Icons.receipt_long_rounded,
                  color: Colors.white,
                  size: mobile ? 20 : 23,
                ),
              ),
              const SizedBox(width: 10),
              const Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'CHALLAN DETAILS',
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 15,
                        fontWeight: FontWeight.w800,
                        letterSpacing: 0.5,
                      ),
                    ),
                    SizedBox(height: 3),
                    Text(
                      'Customer, vehicle and financial information',
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: TextStyle(color: Colors.white70, fontSize: 10.5),
                    ),
                  ],
                ),
              ),
              if (!mobile) ...[
                const SizedBox(width: 10),
                Container(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 13,
                    vertical: 9,
                  ),
                  decoration: BoxDecoration(
                    color: Colors.white.withValues(alpha: 0.14),
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(
                      color: Colors.white.withValues(alpha: 0.25),
                    ),
                  ),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      const Icon(
                        Icons.confirmation_number_outlined,
                        color: Colors.white,
                        size: 17,
                      ),
                      const SizedBox(width: 7),
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.end,
                        children: [
                          Text(
                            'CHALLAN NO.',
                            style: TextStyle(
                              color: Colors.white.withValues(alpha: 0.70),
                              fontSize: 8,
                              fontWeight: FontWeight.w700,
                              letterSpacing: 0.7,
                            ),
                          ),
                          const SizedBox(height: 2),
                          Text(
                            '$_challanNo',
                            style: const TextStyle(
                              color: Colors.white,
                              fontSize: 14,
                              fontWeight: FontWeight.w900,
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ],
            ],
          ),
        );
      },
    );
  }

  Widget _sectionDivider(String title) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    IconData icon;
    switch (title) {
      case 'Finance':
        icon = Icons.account_balance_wallet_rounded;
        break;
      case 'Discounts & Offers':
        icon = Icons.local_offer_rounded;
        break;
      case 'Insurance':
        icon = Icons.verified_user_rounded;
        break;
      case 'RTO':
        icon = Icons.directions_car_filled_rounded;
        break;
      case 'Others':
        icon = Icons.widgets_rounded;
        break;
      case 'Final Details':
        icon = Icons.fact_check_rounded;
        break;
      case 'Receipts':
        icon = Icons.receipt_long_rounded;
        break;
      case 'Balances':
        icon = Icons.account_balance_rounded;
        break;
      default:
        icon = Icons.notes_rounded;
    }
    return Container(
      margin: const EdgeInsets.only(bottom: 8),
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 11),
      decoration: BoxDecoration(
        color: isDark ? const Color(0xFF15253A) : const Color(0xFFEAF2FF),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(
          color: isDark
              ? Colors.white.withValues(alpha: 0.08)
              : const Color(0xFFD3E3FA),
        ),
      ),
      child: Row(
        children: [
          Container(
            width: 34,
            height: 34,
            decoration: BoxDecoration(
              color: isDark ? const Color(0xFF214D88) : const Color(0xFFDCEAFF),
              borderRadius: BorderRadius.circular(10),
            ),
            child: Icon(
              icon,
              color: isDark ? Colors.white : const Color(0xFF1F64C7),
              size: 18,
            ),
          ),
          const SizedBox(width: 11),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  style: TextStyle(
                    color: isDark ? Colors.white : const Color(0xFF174A88),
                    fontSize: 14,
                    fontWeight: FontWeight.w800,
                  ),
                ),
                const SizedBox(height: 1),
                Text(
                  _sectionSubtitle(title),
                  style: TextStyle(
                    color: isDark ? Colors.white54 : const Color(0xFF6B7D96),
                    fontSize: 9.5,
                    fontWeight: FontWeight.w500,
                  ),
                ),
              ],
            ),
          ),
          Icon(
            Icons.keyboard_arrow_down_rounded,
            color: isDark ? Colors.white54 : const Color(0xFF7E96B5),
            size: 21,
          ),
        ],
      ),
    );
  }

  String _sectionSubtitle(String title) {
    switch (title) {
      case 'Finance':
        return 'Funding and loan information';
      case 'Discounts & Offers':
        return 'Corporate, exchange and scheme adjustments';
      case 'Insurance':
        return 'Policy, coverage and premium details';
      case 'RTO':
        return 'Registration and road tax information';
      case 'Others':
        return 'Additional charges and descriptions';
      case 'Final Details':
        return 'Accessories, warranty and final amounts';
      case 'Receipts':
        return 'Payment collection details';
      case 'Balances':
        return 'Outstanding and received amounts';
      default:
        return 'Notes and approval information';
    }
  }

  Widget _pad(Widget child) => Container(
    width: double.infinity,
    padding: const EdgeInsets.fromLTRB(14, 16, 14, 16),
    decoration: BoxDecoration(
      color: Theme.of(context).brightness == Brightness.dark
          ? const Color(0xFF132033)
          : Colors.white,
      borderRadius: BorderRadius.circular(16),
      border: Border.all(
        color: Theme.of(context).brightness == Brightness.dark
            ? Colors.white.withValues(alpha: 0.08)
            : const Color(0xFFD8E4F3),
      ),
      boxShadow: [
        BoxShadow(
          color: Colors.black.withValues(
            alpha: Theme.of(context).brightness == Brightness.dark
                ? 0.10
                : 0.045,
          ),
          blurRadius: 16,
          offset: const Offset(0, 5),
        ),
      ],
    ),
    child: child,
  );

  Widget _loader() => const Center(
    child: Padding(
      padding: EdgeInsets.all(60),
      child: CircularProgressIndicator(
        strokeWidth: 3,
        color: Color(0xFF0D3F8A),
      ),
    ),
  );

  Widget _errWidget() => Center(
    child: Padding(
      padding: const EdgeInsets.all(32),
      child: _pad(
        Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Icon(
              Icons.error_outline_rounded,
              size: 52,
              color: Color(0xFFE53935),
            ),
            const SizedBox(height: 12),
            Text(
              _initError ?? 'Error loading form',
              textAlign: TextAlign.center,
              style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w600),
            ),
            const SizedBox(height: 16),
            ElevatedButton.icon(
              onPressed: _loadDropdowns,
              icon: const Icon(Icons.refresh_rounded, size: 18),
              style: ElevatedButton.styleFrom(
                backgroundColor: _accent,
                foregroundColor: Colors.white,
                padding: const EdgeInsets.symmetric(
                  horizontal: 18,
                  vertical: 11,
                ),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(10),
                ),
              ),
              label: const Text('Retry'),
            ),
          ],
        ),
      ),
    ),
  );

  Widget _bottomBar(bool isDark) {
    return LayoutBuilder(
      builder: (context, constraints) {
        final mobile = constraints.maxWidth < 600;
        final badge = Container(
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 9),
          decoration: BoxDecoration(
            color: isDark
                ? Colors.white.withValues(alpha: 0.05)
                : const Color(0xFFF5F7FA),
            borderRadius: BorderRadius.circular(12),
          ),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(
                Icons.confirmation_number_outlined,
                size: 17,
                color: isDark ? Colors.white70 : const Color(0xFF687588),
              ),
              const SizedBox(width: 7),
              Text(
                'Challan $_challanNo',
                style: TextStyle(
                  fontSize: 11,
                  fontWeight: FontWeight.w700,
                  color: isDark ? Colors.white70 : const Color(0xFF526074),
                ),
              ),
            ],
          ),
        );

        final saveButton = ElevatedButton.icon(
          // onPressed: _saving ? null : _challansavelatest,
          onPressed: _saving
              ? null
              : _challansavelatest, // Call the new method for saving
          icon: _saving
              ? const SizedBox(
                  width: 18,
                  height: 18,
                  child: CircularProgressIndicator(
                    strokeWidth: 2,
                    color: Colors.white,
                  ),
                )
              : const Icon(Icons.save_rounded, size: 19),
          label: Text(
            _saving
                ? 'Saving...'
                : (_isEditing ? 'Update Challan' : 'Save Challan'),
            style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 14),
          ),
          style: ElevatedButton.styleFrom(
            backgroundColor: _accent,
            foregroundColor: Colors.white,
            elevation: 4,
            shadowColor: _primary.withValues(alpha: 0.28),
            minimumSize: const Size(0, 48),
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(13),
            ),
          ),
        );

        final exitButton = OutlinedButton.icon(
          onPressed: () {
            Navigator.pushReplacement(
              context,
              MaterialPageRoute(
                settings: const RouteSettings(name: 'ChallanGridScreen'),
                builder: (_) => const ChallanGridScreen(),
              ),
            );
          },
          icon: const Icon(Icons.close_rounded, size: 18),
          label: const Text(
            'Exit',
            style: TextStyle(fontWeight: FontWeight.w800, fontSize: 14),
          ),
          style: OutlinedButton.styleFrom(
            foregroundColor: _accent,
            side: BorderSide(
              color: _accent.withValues(alpha: 0.45),
              width: 1.3,
            ),
            minimumSize: const Size(0, 48),
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(13),
            ),
          ),
        );

        return Container(
          padding: EdgeInsets.fromLTRB(
            12,
            mobile ? 8 : 10,
            12,
            mobile ? 10 : 12,
          ),
          decoration: BoxDecoration(
            color: isDark ? const Color(0xFF0B121C) : Colors.white,
            border: Border(
              top: BorderSide(
                color: isDark ? Colors.white10 : const Color(0xFFE2E7EF),
              ),
            ),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withValues(alpha: 0.14),
                blurRadius: 22,
                offset: const Offset(0, -7),
              ),
            ],
          ),
          child: SafeArea(
            top: false,
            child: mobile
                ? Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Align(alignment: Alignment.centerLeft, child: badge),
                      const SizedBox(height: 8),
                      Row(
                        children: [
                          Expanded(child: saveButton),
                          const SizedBox(width: 8),
                          Expanded(child: exitButton),
                        ],
                      ),
                    ],
                  )
                : Row(
                    children: [
                      badge,
                      const SizedBox(width: 12),
                      Expanded(child: saveButton),
                      const SizedBox(width: 10),
                      SizedBox(width: 130, child: exitButton),
                    ],
                  ),
          ),
        );
      },
    );
  }

  Widget _secHeader() {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final surface = isDark ? const Color(0xFF162231) : const Color(0xFFF8FAFD);
    final valueColor = isDark ? Colors.white : const Color(0xFF253247);
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Container(
          margin: const EdgeInsets.only(bottom: 16),
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
          decoration: BoxDecoration(
            color: surface,
            borderRadius: BorderRadius.circular(12),
            border: Border.all(
              color: isDark ? Colors.white10 : const Color(0xFFE8EDF4),
            ),
          ),
          child: LayoutBuilder(
            builder: (context, constraints) {
              final mobile = constraints.maxWidth < 520;
              final title = Row(
                children: [
                  Container(
                    width: 30,
                    height: 30,
                    decoration: BoxDecoration(
                      color: const Color(0xFF1675D1).withValues(alpha: 0.10),
                      borderRadius: BorderRadius.circular(9),
                    ),
                    child: const Icon(
                      Icons.person_outline_rounded,
                      color: Color(0xFF1675D1),
                      size: 18,
                    ),
                  ),
                  const SizedBox(width: 9),
                  Expanded(
                    child: Text(
                      'Customer & Vehicle Information',
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: TextStyle(
                        fontSize: 12.5,
                        fontWeight: FontWeight.w800,
                        color: valueColor,
                      ),
                    ),
                  ),
                ],
              );
              if (mobile) {
                return Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    title,
                    const SizedBox(height: 4),
                    Text(
                      'Required details',
                      style: TextStyle(
                        fontSize: 9.5,
                        fontWeight: FontWeight.w600,
                        color: isDark
                            ? Colors.white38
                            : const Color(0xFF8A95A5),
                      ),
                    ),
                  ],
                );
              }
              return Row(
                children: [
                  Expanded(child: title),
                  const SizedBox(width: 8),
                  Text(
                    'Required details',
                    style: TextStyle(
                      fontSize: 9.5,
                      fontWeight: FontWeight.w600,
                      color: isDark ? Colors.white38 : const Color(0xFF8A95A5),
                    ),
                  ),
                ],
              );
            },
          ),
        ),
        _r3(
          _dropMapField('Branch', _branchId, _branches, _onBranchSelected),
          _dropStrField(
            'Challan Type',
            _challanType,
            _challanTypes
                .map(
                  (t) => DropdownMenuItem(
                    value: t,
                    child: Text(t, style: _s13),
                  ),
                )
                .toList(),
            _onChallanTypeSelected,
          ),
          _customerSelector(),
        ),
        _vg,
        _r3(
          _datePicker(),
          Container(
            height: 48,
            padding: const EdgeInsets.symmetric(horizontal: 13),
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: Theme.of(context).brightness == Brightness.dark
                    ? [
                        const Color(0xFF1675D1).withValues(alpha: 0.18),
                        const Color(0xFF1675D1).withValues(alpha: 0.08),
                      ]
                    : [
                        const Color(0xFF1675D1).withValues(alpha: 0.08),
                        const Color(0xFF1675D1).withValues(alpha: 0.03),
                      ],
              ),
              border: Border.all(
                color: const Color(0xFF1675D1).withValues(
                  alpha: Theme.of(context).brightness == Brightness.dark
                      ? 0.55
                      : 0.28,
                ),
              ),
              borderRadius: BorderRadius.circular(12),
            ),
            child: Row(
              children: [
                Container(
                  width: 30,
                  height: 30,
                  decoration: BoxDecoration(
                    color: _accent.withValues(alpha: 0.11),
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: const Icon(
                    Icons.tag_rounded,
                    color: const Color(0xFF1675D1),
                    size: 17,
                  ),
                ),
                const SizedBox(width: 9),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Text(
                      'CHALLAN NO.',
                      style: TextStyle(
                        fontSize: 8.5,
                        color: Theme.of(context).brightness == Brightness.dark
                            ? const Color(0xFF7EB8FF).withValues(alpha: 0.80)
                            : const Color(0xFF8C5960),
                        fontWeight: FontWeight.w800,
                        letterSpacing: 0.5,
                      ),
                    ),
                    const SizedBox(height: 1),
                    Text(
                      '$_challanNo',
                      style: TextStyle(
                        fontSize: 15,
                        color: Theme.of(context).brightness == Brightness.dark
                            ? Colors.white
                            : const Color(0xFF0A1B32),
                        fontWeight: FontWeight.w900,
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
          _txt('Address', _addressCtrl, maxLines: 1),
        ),
        _vg,
        _r3(
          _dropMapField('State', _stateId, _states, (v) {
            _onStateSelected(v);
          }),
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Expanded(
                child: _dropMapField('City', _cityId, _cities, (v) {
                  if (v == '__CLEAR__' || v == null) {
                    setState(() {
                      _cityId = null;
                      _cityName = '';
                      _areaId = null;
                      _areaName = '';
                    });
                    return;
                  }
                  final city = _cities.firstWhere(
                    (e) => (e['data'] ?? e['sp_572']).toString() == v,
                    orElse: () => {},
                  );
                  setState(() {
                    _cityId = v;
                    _cityName = (city['value'] ?? city['sp_578'] ?? v)
                        .toString();
                    _areaId = null;
                    _areaName = '';
                  });
                }),
              ),
              const SizedBox(width: 7),
              _plusBtn(_openCitySheet),
            ],
          ),
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Expanded(
                child: _dropMapField('Area', _areaId, _areas, (v) {
                  if (v == '__CLEAR__' || v == null) {
                    setState(() {
                      _areaId = null;
                      _areaName = '';
                    });
                    return;
                  }
                  final area = _areas.firstWhere(
                    (e) => (e['data'] ?? e['sp_212']).toString() == v,
                    orElse: () => {},
                  );
                  setState(() {
                    _areaId = v;
                    _areaName = (area['value'] ?? area['sp_217'] ?? v)
                        .toString();
                  });
                }),
              ),
              const SizedBox(width: 7),
              _plusBtn(_openAreaSheet),
            ],
          ),
        ),
        _vg,
        _r3(
          _txt('Location', _locationCtrl, readOnly: true),

          _txt(
            'Mobile No.',
            _mobileCtrl,
            inputType: TextInputType.phone,
            inputFormatters: [
              FilteringTextInputFormatter.digitsOnly,
              LengthLimitingTextInputFormatter(10),
            ],
            validator: (value) {
              final mobile = (value ?? '').trim();

              // Keep the field optional, but validate it if entered.
              if (mobile.isEmpty) return null;

              if (!RegExp(r'^[6-9][0-9]{9}$').hasMatch(mobile)) {
                return 'Enter a valid 10-digit mobile number';
              }

              return null;
            },
          ),

          _txt('Aadhar No.', _aadharCtrl, inputType: TextInputType.number),
        ),
        _vg,
        _r3(
          _txt('Email Id', _emailCtrl, inputType: TextInputType.emailAddress),
          _txt('PAN', _panCtrl, inputFormatters: [UpperCaseFormatter()]),
          _txt('Nominee Name', _nomineeCtrl),
        ),
        _vg,
        _r3(
          _txt('Age', _ageCtrl, inputType: TextInputType.number),
          _dropStrField(
            'Relation',
            _relation,
            [
                  'CHOOSE RELATIONSHIP',
                  'Son',
                  'Daughter',
                  'Spouse',
                  'Father',
                  'Mother',
                  'Other',
                ]
                .map(
                  (r) => DropdownMenuItem(
                    value: r,
                    child: Text(r, style: _s13),
                  ),
                )
                .toList(),
            (v) => setState(() => _relation = v!),
          ),
          _txt(
            'GST No.',
            _gstinCtrl,
            inputFormatters: [
              FilteringTextInputFormatter.allow(RegExp(r'[a-zA-Z0-9]')),
              UpperCaseFormatter(),
              LengthLimitingTextInputFormatter(15),
            ],
            validator: (value) {
              final gstin = (value ?? '').trim().toUpperCase();

              // GSTIN remains optional; validate only when entered.
              if (gstin.isEmpty) return null;

              final gstinRegex = RegExp(
                r'^[0-9]{2}[A-Z]{5}[0-9]{4}[A-Z][A-Z0-9]Z[A-Z0-9]$',
              );

              if (!gstinRegex.hasMatch(gstin)) {
                return 'Enter a valid 15-character GSTIN';
              }

              return null;
            },
          ),
        ),
        _vg,
        _r3(
          _txt('SC Name', _scCtrl, readOnly: true),
          _txt('TL Name', _tlCtrl, readOnly: true),
          _txt('Manager', _managerCtrl, readOnly: true),
        ),
        _vg,
        _r3(
          _dropMapField('Model', _modelId, _models, _onModel, disabled: true),
          _loadingVar
              ? _loadBox()
              : _dropMapField(
                  'Variant',
                  _variantId,
                  _variants,
                  _onVariant,
                  disabled: true,
                ),
          _loadingCol
              ? _loadBox()
              : _dropMapField(
                  'Color',
                  _colorId,
                  _colors,
                  _onColor,
                  disabled: true,
                ),
        ),
        _vg,
        _r3(
          _loadingVin
              ? _loadBox()
              : _dropMapField(
                  'VIN',
                  _vinNo,
                  _vins,
                  _onVinSelected,
                  labelFn: (e) =>
                      '${e['value'] ?? ''} ${e['mfcyr'] ?? ''}'.trim(),
                  disabled: true,
                ),
          _txt('Engine No.', _engineCtrl, readOnly: true),
          const SizedBox(),
        ),
      ],
    );
  }

  Widget _customerSelector() {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final name = _custId == null
        ? 'SELECT CUSTOMER'
        : (_customers.firstWhere(
                    (e) => e['data'] == _custId,
                    orElse: () => {},
                  )['value']
                  as String? ??
              'SELECT CUSTOMER');
    return InkWell(
      onTap: _openCustomerSheet,
      borderRadius: BorderRadius.circular(12),
      child: InputDecorator(
        decoration: _dec('Customer Name'),
        child: Row(
          children: [
            Icon(
              Icons.person_search_rounded,
              size: 18,
              color: _custId == null
                  ? (isDark ? Colors.white38 : const Color(0xFF9BA5B4))
                  : _accent,
            ),
            const SizedBox(width: 8),
            Expanded(
              child: Text(
                name,
                overflow: TextOverflow.ellipsis,
                style: TextStyle(
                  fontSize: 12.5,
                  fontWeight: FontWeight.w600,
                  color: _custId == null
                      ? (isDark ? Colors.white38 : const Color(0xFF9BA5B4))
                      : null,
                ),
              ),
            ),
            const Icon(
              Icons.keyboard_arrow_down_rounded,
              size: 19,
              color: Color(0xFF8C97A7),
            ),
          ],
        ),
      ),
    );
  }

  // ── Finance section ───────────────────────────────────────────────────────
  // ── Finance section ───────────────────────────────────────────────────────
  Widget _secFinance() => Column(
    children: [
      // ─────────────────────────────────────────────────────────────
      // FINANCE TYPE
      // ─────────────────────────────────────────────────────────────
      Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _lbl('Finance Type'),
          const SizedBox(height: 4),
          Wrap(
            children: [
              _radio('In House', _finType, (v) {
                if (v == null) return;

                setState(() {
                  _finType = 'In House';
                  _hpnRtoCtrl.text = _f(_hpnMasterAmount);
                });

                _recalculateAspNet();
              }),

              _radio('Out House', _finType, (v) {
                if (v == null) return;

                setState(() {
                  _finType = 'Out House';
                  _hpnRtoCtrl.text = _f(_hpnMasterAmount);
                });

                _recalculateAspNet();
              }),

              _radio('Cash', _finType, (v) {
                if (v == null) return;

                setState(() {
                  _finType = 'Cash';

                  // Cash finance:
                  // HPN must be zero.
                  _hpnRtoCtrl.text = '0.00';

                  // Keep Customer Received Amt as the actual receipt amount.
                  // Only the receipt-summary Customer Amt is zero for Cash.
                  _receiptCustAmt = 0.0;
                });

                _recalculateAspNet();
              }),
            ],
          ),
        ],
      ),

      _vg,

      _r4(
        // ─────────────────────────────────────────────────────────────
        // HYPOTHECATION / LESSOR
        //
        // Cash  -> Disabled
        // In/Out -> Enabled
        // ─────────────────────────────────────────────────────────────
        _dropMapField(
          'Hypothecation / Lessor',
          _hpnParentId,
          _hpnList,
          (v) {
            if (v == null) return;

            setState(() {
              _hpnParentId = v;
              _hpnChildId = null;
              _hpnBranches = [];
              _branchNameCtrl.clear();
            });

            _loadHpnBranches(v);

            _recalculateAspNet();
          },
          disabled: _financeFieldsDisabled,
        ),

        // ─────────────────────────────────────────────────────────────
        // BRANCH NAME
        //
        // Cash  -> Disabled
        // In/Out -> Enabled
        // ─────────────────────────────────────────────────────────────
        _dropMapField('Branch Name', _hpnChildId, _hpnBranches, (v) {
          if (v == null) return;

          setState(() {
            _hpnChildId = v;

            final selected = _hpnBranches.firstWhere(
              (e) => e['data']?.toString() == v.toString(),
              orElse: () => <String, dynamic>{},
            );

            _branchNameCtrl.text = selected['value']?.toString() ?? '';
          });

          _recalculateAspNet();
        }, disabled: _financeFieldsDisabled),

        // ─────────────────────────────────────────────────────────────
        // LOAN AMOUNT
        //
        // Cash  -> Disabled
        // In/Out -> Enabled
        // ─────────────────────────────────────────────────────────────
        _num('Loan Amount', _loanAmtCtrl, ro: _financeFieldsDisabled),

        // ─────────────────────────────────────────────────────────────
        // NET DISBURSED AMOUNT
        //
        // Cash  -> Disabled
        // In/Out -> Enabled
        // ─────────────────────────────────────────────────────────────
        _num('Net Disbursed Amount', _netDisCtrl, ro: _financeFieldsDisabled),
      ),
    ],
  );

  // ── Discounts section ─────────────────────────────────────────────────────

  // ── Discounts section ─────────────────────────────────────────────
  Widget _secDiscounts() => LayoutBuilder(
    builder: (context, constraints) {
      final mobile = constraints.maxWidth < 600;

      return Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          // Column headings
          Padding(
            padding: const EdgeInsets.only(bottom: 5),
            child: Row(
              children: [
                const Expanded(flex: 4, child: SizedBox()),
                Expanded(
                  flex: 3,
                  child: Center(
                    child: mobile
                        ? const Text(
                            'Amount',
                            style: TextStyle(
                              fontSize: 10,
                              fontWeight: FontWeight.w700,
                              color: Color(0xFF5F6F85),
                            ),
                          )
                        : _lbl('Amount'),
                  ),
                ),
                Expanded(
                  flex: 5,
                  child: Center(
                    child: mobile
                        ? const Text(
                            'Given',
                            style: TextStyle(
                              fontSize: 10,
                              fontWeight: FontWeight.w700,
                              color: Color(0xFF5F6F85),
                            ),
                          )
                        : _lbl('Given'),
                  ),
                ),
              ],
            ),
          ),

          const SizedBox(height: 4),

          // 1. Corporate
          _discRow(
            'Corporate',
            _corpYn,
            (v) {
              if (v == null) return;
              setState(() => _corpYn = v);
              _recalculateAspNet();
            },
            _corpValCtrl,
            _corpGiven,
            (v) {
              if (v == null) return;
              setState(() => _corpGiven = v);
              _recalculateAspNet();
            },
            null,
            '',
          ),

          // 2. Exchange
          _discRow(
            'Exchange',
            _exchYn,
            (v) {
              if (v == null) return;
              setState(() => _exchYn = v);
              _recalculateAspNet();
            },
            _exchValCtrl,
            _exchGiven,
            (v) {
              if (v == null) return;
              setState(() => _exchGiven = v);
              _recalculateAspNet();
            },
            null,
            '',
          ),

          // 3. Dealer Discount
          _discRow(
            'Dealer Discount',
            _dealYn,
            (v) {
              if (v == null) return;
              setState(() => _dealYn = v);
              _recalculateAspNet();
            },
            _dealValCtrl,
            _dealGiven,
            (v) {
              if (v == null) return;
              setState(() => _dealGiven = v);
              _recalculateAspNet();
            },
            null,
            '',
          ),

          // 4. Loyalty
          _discRow(
            'Loyalty',
            _loyYn,
            (v) {
              if (v == null) return;
              setState(() => _loyYn = v);
              _recalculateAspNet();
            },
            _loyValCtrl,
            _loyGiven,
            (v) {
              if (v == null) return;
              setState(() => _loyGiven = v);
              _recalculateAspNet();
            },
            null,
            '',
          ),

          const SizedBox(height: 5),

          // Calculated fields shown after all discount rows
          _num('Ex-Showroom', _exShowCtrl, bold: true),
          const SizedBox(height: 8),

          _num('Schemes Less', _schemesCtrl),
          const SizedBox(height: 8),

          _num('SubTotal', _subTotalCtrl, ro: true, bold: true),
        ],
      );
    },
  );

  // ── Responsive discount row ──────────────────────────────────────
  Widget _discRow(
    String lbl,
    String yn,
    ValueChanged<String?> onYn,
    TextEditingController amtC,
    String given,
    ValueChanged<String?> onGiven,
    TextEditingController? rightC,
    String rightLbl, {
    bool ro = false,
  }) => LayoutBuilder(
    builder: (context, constraints) {
      final mobile = constraints.maxWidth < 600;

      if (mobile) {
        // MOBILE: label, amount and Given stay on one row.
        return Padding(
          padding: const EdgeInsets.only(bottom: 9),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              Expanded(
                flex: 4,
                child: Text(
                  lbl,
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(
                    fontSize: 11.5,
                    fontWeight: FontWeight.w700,
                  ),
                ),
              ),

              const SizedBox(width: 6),

              Expanded(flex: 3, child: _num('', amtC)),

              const SizedBox(width: 5),

              Expanded(
                flex: 5,
                child: FittedBox(
                  fit: BoxFit.scaleDown,
                  alignment: Alignment.centerRight,
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      _radio('Yes', given, onGiven),
                      _radio('No', given, onGiven),
                    ],
                  ),
                ),
              ),
            ],
          ),
        );
      }

      // DESKTOP / TABLET: retain the existing four-column layout.
      return Padding(
        padding: const EdgeInsets.only(bottom: 8),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Expanded(
              flex: 3,
              child: Row(
                children: [
                  Expanded(
                    child: Text(
                      lbl,
                      style: const TextStyle(
                        fontSize: 12,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ),
                  _radio('Yes', yn, onYn),
                  _radio('No', yn, onYn),
                ],
              ),
            ),

            Expanded(flex: 2, child: _num('', amtC)),

            Expanded(
              flex: 2,
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  _radio('Yes', given, onGiven),
                  _radio('No', given, onGiven),
                ],
              ),
            ),

            Expanded(
              flex: 3,
              child: rightC != null
                  ? _num(rightLbl, rightC, ro: ro)
                  : const SizedBox(),
            ),
          ],
        ),
      );
    },
  );

  // ── Insurance section (4-column grid) ────────────────────────────────────
  Widget _secInsurance() => Column(
    children: [
      LayoutBuilder(
        builder: (context, constraints) {
          final mobile = constraints.maxWidth < 600;
          final typeRow = Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Text(
                'Insurance',
                style: TextStyle(fontSize: 13, fontWeight: FontWeight.w600),
              ),
              const SizedBox(width: 5),
              _radio('In House', _insType, (v) {
                if (v == null) return;
                setState(() => _insType = v);
                _recalculateAspNet();
              }),
              _radio('Out House', _insType, (v) {
                if (v == null) return;
                setState(() => _insType = v);
                _recalculateAspNet();
              }),
            ],
          );
          final right = mobile
              ? Column(
                  children: [
                    _num('Insurance Discount%', _insDisCtrl),
                    const SizedBox(height: 8),
                    _num('Insurance Ex-Showroom', _insExShowCtrl),
                  ],
                )
              : Row(
                  children: [
                    SizedBox(
                      width: 110,
                      child: _num('Insurance Discount%', _insDisCtrl),
                    ),
                    const SizedBox(width: 8),
                    Expanded(
                      child: _num('Insurance Ex-Showroom', _insExShowCtrl),
                    ),
                  ],
                );
          return mobile
              ? Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [typeRow, const SizedBox(height: 9), right],
                )
              : Row(
                  children: [
                    Expanded(child: typeRow),
                    const SizedBox(width: 12),
                    SizedBox(width: 320, child: right),
                  ],
                );
        },
      ),
      _vg,
      Wrap(
        spacing: 8,
        runSpacing: 4,
        children: [
          _chk('EP Amount Add', _epAdd, (v) async {
            final checked = v ?? false;
            setState(() => _epAdd = checked);

            if (_insuranceCompanyId != null &&
                _insuranceCompanyId!.trim().isNotEmpty &&
                _modelId != null &&
                _modelId!.trim().isNotEmpty) {
              await _fetchInsuranceCalculation();
            }

            if (!mounted) return;

            setState(() {
              _epCtrl.text = _epAdd && _epMasterRate != null
                  ? _f(_epMasterRate)
                  : '0.00';

              if (!_epAdd) _epAmtCtrl.text = '0.00';
            });

            _recalculateAspNet();
          }),
          _chk('RTI Amount Add', _rtiAdd, (v) async {
            final checked = v ?? false;
            setState(() => _rtiAdd = checked);

            if (_insuranceCompanyId != null &&
                _insuranceCompanyId!.trim().isNotEmpty &&
                _modelId != null &&
                _modelId!.trim().isNotEmpty) {
              await _fetchInsuranceCalculation();
            }

            if (!mounted) return;

            setState(() {
              _rtiCtrl.text = _rtiAdd && _rtiMasterRate != null
                  ? _f(_rtiMasterRate)
                  : '0.00';

              if (!_rtiAdd) _rtiAmtCtrl.text = '0.00';
            });

            _recalculateAspNet();
          }),
          _chk('CM Amount Add', _cmAdd, (v) async {
            final checked = v ?? false;
            setState(() => _cmAdd = checked);

            if (_insuranceCompanyId != null &&
                _insuranceCompanyId!.trim().isNotEmpty &&
                _modelId != null &&
                _modelId!.trim().isNotEmpty) {
              await _fetchInsuranceCalculation();
            }

            if (!mounted) return;

            setState(() {
              _cmCtrl.text = _cmAdd && _cmMasterRate != null
                  ? _f(_cmMasterRate)
                  : '0.00';

              if (!_cmAdd) _cmAmtCtrl.text = '0.00';
            });

            _recalculateAspNet();
          }),
        ],
      ),
      _vg,
      _i4(
        'CESS',
        _cessCtrl,
        'Amount',
        _cessAmtCtrl,
        'IDV',
        _idvCtrl,
        'IDV Amount',
        c4: _idvAmtCtrl,
      ),
      _vg,
      _i4(
        'After IDV',
        _afterIdvCtrl,
        'Amount',
        _insAmtCtrl,
        'Insurance %',
        _insPerCtrl,
        'Insurance Amount',
        c4: _insCalcAmtCtrl,
      ),
      _vg,
      _i4(
        'Discount Amount',
        _disAmtCtrl,
        'After Discount',
        _afterDisCtrl,
        'CNG %',
        _cngPerCtrl,
        'CNG Amount',
        c4: _cngAmtCtrl,
      ),
      _vg,
      _i4(
        'PA Cover',
        _paCoverCtrl,
        'Amount',
        _paAmtCtrl,
        'ZD',
        _zdCtrl,
        'ZD Amount',
        c4: _zdAmtCtrl,
      ),
      _vg,
      _i4(
        'EP',
        _epCtrl,
        'EP Amount',
        _epAmtCtrl,
        'Third Party',
        _thirdPartyCtrl,
        'PB',
        c4: _pbCtrl,
      ),
      _vg,
      _i4(
        'KP',
        _kpCtrl,
        'Amount',
        _kpAmtCtrl,
        'Paid Driver',
        _paidDrvCtrl,
        'After PD',
        c4: _afterPdCtrl,
      ),
      _vg,
      _i4(
        'RTI',
        _rtiCtrl,
        'RTI Amount',
        _rtiAmtCtrl,
        'CM',
        _cmCtrl,
        'CM Amount',
        c4: _cmAmtCtrl,
      ),
      _vg,
      LayoutBuilder(
        builder: (context, constraints) {
          final mobile = constraints.maxWidth < 600;
          final fields = [
            _dropStrField(
              'GST',
              _gstUnq ?? '',
              [
                const DropdownMenuItem(
                  value: '',
                  child: Text('--', style: TextStyle(fontSize: 13)),
                ),
                const DropdownMenuItem(
                  value: '18',
                  child: Text('18', style: TextStyle(fontSize: 13)),
                ),
                const DropdownMenuItem(
                  value: '28',
                  child: Text('28', style: TextStyle(fontSize: 13)),
                ),
              ],
              (v) {
                setState(() => _gstUnq = v);
                _recalculateAspNet();
              },
            ),
            _num('CGST', _cgstCtrl),
            _num('SGST', _sgstCtrl),
            _num('GST Amount', _gstAmtCtrl),
          ];
          return mobile
              ? Column(
                  children: fields
                      .map(
                        (w) => Padding(
                          padding: const EdgeInsets.only(bottom: 8),
                          child: w,
                        ),
                      )
                      .toList(),
                )
              : Row(
                  children: [
                    for (int i = 0; i < fields.length; i++) ...[
                      Expanded(child: fields[i]),
                      if (i < fields.length - 1) const SizedBox(width: 8),
                    ],
                  ],
                );
        },
      ),
      _vg,
      LayoutBuilder(
        builder: (context, constraints) {
          final mobile = constraints.maxWidth < 600;
          final fields = [
            _num('Add / Less', _addLessCtrl),
            _num('NCB', _ncbCtrl),
            _num('Insurance Amount', _insAmtFinalCtrl, bold: true),
          ];
          return mobile
              ? Column(
                  children: fields
                      .map(
                        (w) => Padding(
                          padding: const EdgeInsets.only(bottom: 8),
                          child: w,
                        ),
                      )
                      .toList(),
                )
              : Row(
                  children: [
                    Expanded(child: fields[0]),
                    const SizedBox(width: 8),
                    Expanded(child: fields[1]),
                    const SizedBox(width: 8),
                    Expanded(flex: 2, child: fields[2]),
                  ],
                );
        },
      ),
    ],
  );

  Widget _i4(
    String l1,
    TextEditingController c1,
    String l2,
    TextEditingController c2,
    String l3,
    TextEditingController c3,
    String l4, {
    TextEditingController? c4,
  }) => LayoutBuilder(
    builder: (context, constraints) {
      final fields = <Widget>[
        _num(l1, c1),
        _num(l2, c2),
        _num(l3, c3),
        if (c4 != null && l4.isNotEmpty) _num(l4, c4),
      ];
      if (constraints.maxWidth < 600) {
        return Column(
          children: fields
              .map(
                (w) => Padding(
                  padding: const EdgeInsets.only(bottom: 8),
                  child: w,
                ),
              )
              .toList(),
        );
      }
      return Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          for (int i = 0; i < fields.length; i++) ...[
            Expanded(child: fields[i]),
            if (i < fields.length - 1) const SizedBox(width: 8),
          ],
        ],
      );
    },
  );

  // ── RTO section ───────────────────────────────────────────────────────────
  Widget _secRto() => Column(
    children: [
      LayoutBuilder(
        builder: (context, constraints) {
          final mobile = constraints.maxWidth < 600;
          final radios = Wrap(
            spacing: 0,
            runSpacing: 2,
            children: [
              _radio('In House', _rtoFrom, (v) {
                if (v == null) return;
                setState(() => _rtoFrom = v);
                _recalculateAspNet();
              }),
              _radio('Out House', _rtoFrom, (v) {
                if (v == null) return;
                setState(() => _rtoFrom = v);
                _recalculateAspNet();
              }),
              _radio('BH', _rtoFrom, (v) {
                if (v == null) return;
                setState(() => _rtoFrom = v);
                _recalculateAspNet();
              }),
            ],
          );
          final scrap = Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              Checkbox(
                value: _scrappage,
                onChanged: (v) {
                  if (v == null) return;

                  setState(() {
                    _scrappage = v;
                  });

                  _recalculateAspNet();

                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(
                      duration: const Duration(seconds: 4),
                      content: Text(
                        'Scrappage: $_scrappage | '
                        'Percent: $_scrappagePercent | '
                        'RTO Amount: ${_rtoAmtCtrl.text}',
                      ),
                    ),
                  );
                },
              ),
              const Text('Scrappage', style: TextStyle(fontSize: 12)),
            ],
          );
          final exShow = _num('RTO Ex-Showroom', _rtoExShowCtrl);
          if (mobile) {
            return Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                const Text(
                  'RTO',
                  style: TextStyle(fontSize: 13, fontWeight: FontWeight.w700),
                ),
                const SizedBox(height: 4),
                radios,
                const SizedBox(height: 6),
                scrap,
                const SizedBox(height: 7),
                exShow,
              ],
            );
          }
          return Row(
            children: [
              const SizedBox(
                width: 36,
                child: Text(
                  'RTO',
                  style: TextStyle(fontSize: 13, fontWeight: FontWeight.w600),
                ),
              ),
              radios,
              const Spacer(),
              scrap,
              const SizedBox(width: 12),
              SizedBox(width: 140, child: exShow),
            ],
          );
        },
      ),
      _vg,
      _r4(
        _num('RTO Rate', _rtoRateCtrl, ro: true),
        _num('RTO Tax Surcharge', _rtoSurCtrl, ro: true),
        _num('Green Tax', _greenTaxCtrl, ro: true),
        _num('Reg Fee', _regFeeCtrl, ro: true),
      ),
      _vg,
      _r4(
        _num('HPN', _hpnRtoCtrl, ro: true),
        _num('Duplicate', _dupCtrl, ro: true),
        _num('Smart Card', _smartCtrl, ro: true),
        _num('Other', _otherRtoCtrl, ro: true),
      ),
      _vg,
      _r4(
        _num('BH RTO %', _bhPerCtrl, ro: true),
        _txt('BH Year', _bhYearCtrl),
        _num('RTO Temporary', _rtoTempCtrl, ro: true),
        _num('RTO Amount', _rtoAmtCtrl, ro: true, bold: true),
      ),
    ],
  );

  // ── Others section ────────────────────────────────────────────────────────

  Widget _secOthers() {
    Widget otherRow(
      String label,
      TextEditingController otherCtrl,
      TextEditingController amountCtrl,
    ) {
      final currentValue = otherCtrl.text.trim();

      // Preserve the current selection when it exists in the API options.
      final selectedValue =
          _otherOptions.any(
            (item) => (item['data'] ?? '').toString() == currentValue,
          )
          ? currentValue
          : null;

      return LayoutBuilder(
        builder: (context, constraints) {
          final dropdown = _dropMapField<String>(
            label,
            selectedValue,
            _otherOptions,
            (value) {
              setState(() {
                otherCtrl.text = value ?? '';
              });
            },
          );

          final amountField = _num('Amount', amountCtrl);

          if (constraints.maxWidth < 600) {
            return Column(children: [dropdown, _vg, amountField]);
          }

          return Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Expanded(child: dropdown),
              const SizedBox(width: 8),
              Expanded(child: amountField),
            ],
          );
        },
      );
    }

    return Column(
      children: [
        otherRow('Other 1', _oth1Ctrl, _amt1Ctrl),
        _vg,
        otherRow('Other 2', _oth2Ctrl, _amt2Ctrl),
        _vg,
        otherRow('Other 3', _oth3Ctrl, _amt3Ctrl),
      ],
    );
  }

  Widget _r2t(
    String l1,
    TextEditingController c1,
    String l2,
    TextEditingController c2,
  ) => LayoutBuilder(
    builder: (context, constraints) {
      if (constraints.maxWidth < 600) {
        return Column(children: [_txt(l1, c1), _vg, _num(l2, c2)]);
      }
      return Row(
        children: [
          Expanded(child: _txt(l1, c1)),
          const SizedBox(width: 8),
          Expanded(child: _num(l2, c2)),
        ],
      );
    },
  );

  // ── Company Accessories Dialog ───────────────────────────────────────────
  void _showAccessoriesDialog() {
    final hmiDiscountCtrl = TextEditingController(text: '0.00');
    final ownDiscountCtrl = TextEditingController(text: '0.00');

    // The API rows come from A_SP_FOR_Challan with what = gridaccdata.
    // Read keys defensively because SQL/JSON aliases can vary in casing.
    dynamic field(Map<String, dynamic> row, String key, [String? alternate]) {
      if (row.containsKey(key)) return row[key];
      final match = row.entries.where(
        (entry) => entry.key.toLowerCase() == key.toLowerCase(),
      );
      if (match.isNotEmpty) return match.first.value;

      if (alternate != null) {
        if (row.containsKey(alternate)) return row[alternate];
        final alternateMatch = row.entries.where(
          (entry) => entry.key.toLowerCase() == alternate.toLowerCase(),
        );
        if (alternateMatch.isNotEmpty) return alternateMatch.first.value;
      }
      return '';
    }

    String textValue(
      Map<String, dynamic> row,
      String key, [
      String? alternate,
    ]) {
      final value = field(row, key, alternate);
      return value == null ? '' : value.toString();
    }

    double amountValue(Map<String, dynamic> row, String key) {
      final value = field(row, key);
      return double.tryParse(value?.toString() ?? '') ?? 0.0;
    }

    double sumColumn(String key) {
      return _accessoryGridRows.fold<double>(
        0.0,
        (total, row) => total + amountValue(row, key),
      );
    }

    double discountValue(TextEditingController controller) =>
        double.tryParse(controller.text.trim()) ?? 0.0;

    showDialog<void>(
      context: context,
      barrierDismissible: false,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setDlg) {
          final hmiAmount = sumColumn('Hamt');
          final ownAmount = sumColumn('OAMT');
          final hmiDiscount = discountValue(hmiDiscountCtrl);
          final ownDiscount = discountValue(ownDiscountCtrl);
          final hmiTotal = (hmiAmount - hmiDiscount).clamp(
            0.0,
            double.infinity,
          );
          final ownTotal = (ownAmount - ownDiscount).clamp(
            0.0,
            double.infinity,
          );
          final screenWidth = MediaQuery.sizeOf(ctx).width;
          final mobile = screenWidth < 700;
          final isDlgDark = Theme.of(ctx).brightness == Brightness.dark;
          final dlgBg = isDlgDark ? const Color(0xFF1A2535) : Colors.white;
          final footerBg = isDlgDark
              ? const Color(0xFF0F1923)
              : const Color(0xFFF6F8FC);

          Widget accessoryCard(Map<String, dynamic> item, int index) {
            final partNo = textValue(item, 'item');
            final name = textValue(item, 'itemname');
            return Card(
              margin: const EdgeInsets.only(bottom: 8),
              child: Padding(
                padding: const EdgeInsets.all(10),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      '$partNo  •  $name',
                      style: TextStyle(
                        fontWeight: FontWeight.w800,
                        color: isDlgDark
                            ? const Color(0xFFE8EDF5)
                            : const Color(0xFF0A1B32),
                      ),
                    ),
                    const SizedBox(height: 8),
                    Wrap(
                      spacing: 14,
                      runSpacing: 6,
                      children: [
                        Text('Issue Qty: ${textValue(item, 'qty')}'),
                        Text('Required Qty: ${textValue(item, 'reqqty')}'),
                        Text('MRP: ${textValue(item, 'mrp')}'),
                        Text('Stock Qty: ${textValue(item, 'qins')}'),
                        Text('HMI Amount: ${textValue(item, 'Hamt')}'),
                        Text('Own Amount: ${textValue(item, 'OAMT')}'),
                      ],
                    ),
                  ],
                ),
              ),
            );
          }

          Widget amountSummaryField(String label, String value) {
            return _dialogAmountField(label, value);
          }

          Widget discountField(String label, TextEditingController controller) {
            return _dialogEditableAmountField(label, controller, setDlg);
          }

          Widget totalsSection() {
            final hmiFields = [
              amountSummaryField('HMI Amount', hmiAmount.toStringAsFixed(2)),
              discountField('HMI Discount Amount', hmiDiscountCtrl),
              amountSummaryField(
                'HMI Total Amount',
                hmiTotal.toStringAsFixed(2),
              ),
            ];
            final ownFields = [
              amountSummaryField('OWN Amount', ownAmount.toStringAsFixed(2)),
              discountField('OWN Discount Amount', ownDiscountCtrl),
              amountSummaryField(
                'OWN Total Amount',
                ownTotal.toStringAsFixed(2),
              ),
            ];

            Widget fieldsRow(List<Widget> fields) {
              if (mobile) {
                return Column(
                  children: fields
                      .map(
                        (widget) => Padding(
                          padding: const EdgeInsets.only(bottom: 8),
                          child: widget,
                        ),
                      )
                      .toList(),
                );
              }
              return Row(
                children: [
                  for (var i = 0; i < fields.length; i++) ...[
                    Expanded(child: fields[i]),
                    if (i < fields.length - 1) const SizedBox(width: 10),
                  ],
                ],
              );
            }

            return Column(
              children: [
                fieldsRow(hmiFields),
                const SizedBox(height: 8),
                fieldsRow(ownFields),
              ],
            );
          }

          return Dialog(
            backgroundColor: dlgBg,
            insetPadding: EdgeInsets.symmetric(
              horizontal: mobile ? 10 : 28,
              vertical: 18,
            ),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(8),
            ),
            child: ConstrainedBox(
              constraints: BoxConstraints(
                maxWidth: 1200,
                maxHeight: MediaQuery.sizeOf(ctx).height * 0.90,
              ),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Container(
                    width: double.infinity,
                    padding: const EdgeInsets.symmetric(
                      horizontal: 18,
                      vertical: 13,
                    ),
                    decoration: const BoxDecoration(
                      gradient: LinearGradient(
                        colors: [Color(0xFF0A1B32), Color(0xFF0D5BB5)],
                        begin: Alignment.centerLeft,
                        end: Alignment.centerRight,
                      ),
                      borderRadius: BorderRadius.vertical(
                        top: Radius.circular(8),
                      ),
                    ),
                    child: Row(
                      children: [
                        const Expanded(
                          child: Text(
                            'Accessories Details',
                            style: TextStyle(
                              color: Colors.white,
                              fontSize: 19,
                              fontWeight: FontWeight.w800,
                            ),
                          ),
                        ),
                        IconButton(
                          onPressed: () => Navigator.pop(ctx),
                          icon: const Icon(
                            Icons.close_rounded,
                            color: Colors.white70,
                          ),
                          tooltip: 'Close',
                        ),
                      ],
                    ),
                  ),
                  Flexible(
                    child: Padding(
                      padding: const EdgeInsets.fromLTRB(14, 12, 14, 6),
                      child: _accessoryGridRows.isEmpty
                          ? const Center(
                              child: Padding(
                                padding: EdgeInsets.all(24),
                                child: Text(
                                  'No accessories found for this customer.',
                                ),
                              ),
                            )
                          : mobile
                          ? ListView.builder(
                              shrinkWrap: true,
                              itemCount: _accessoryGridRows.length,
                              itemBuilder: (context, index) => accessoryCard(
                                _accessoryGridRows[index],
                                index,
                              ),
                            )
                          : SingleChildScrollView(
                              scrollDirection: Axis.horizontal,
                              child: SingleChildScrollView(
                                child: DataTable(
                                  headingRowHeight: 38,
                                  dataRowMinHeight: 42,
                                  dataRowMaxHeight: 58,
                                  columnSpacing: 14,
                                  horizontalMargin: 8,
                                  headingTextStyle: TextStyle(
                                    fontSize: 11,
                                    fontWeight: FontWeight.w800,
                                    color: isDlgDark
                                        ? const Color(0xFFB0BEC5)
                                        : const Color(0xFF0A1B32),
                                  ),
                                  columns: const [
                                    DataColumn(label: Text('Part No')),
                                    DataColumn(
                                      label: Text('Own Accessories Name'),
                                    ),
                                    DataColumn(label: Text('Issue Qty')),
                                    DataColumn(label: Text('Required Qty')),
                                    DataColumn(label: Text('MRP')),
                                    DataColumn(label: Text('Qty')),
                                    DataColumn(label: Text('HMI Amount')),
                                    DataColumn(label: Text('Own Amount')),
                                  ],
                                  rows: _accessoryGridRows.map((item) {
                                    String value(String key) {
                                      final result = item[key];
                                      return result == null
                                          ? ''
                                          : result.toString();
                                    }

                                    return DataRow(
                                      cells: [
                                        DataCell(Text(value('item'))),
                                        DataCell(
                                          SizedBox(
                                            width: 190,
                                            child: Text(
                                              value('itemname'),
                                              overflow: TextOverflow.ellipsis,
                                            ),
                                          ),
                                        ),
                                        DataCell(Text(value('qty'))),
                                        DataCell(Text(value('reqqty'))),
                                        DataCell(Text(value('mrp'))),
                                        DataCell(Text(value('qty'))),
                                        DataCell(Text(value('Hamt'))),
                                        DataCell(Text(value('OAMT'))),
                                      ],
                                    );
                                  }).toList(),
                                ),
                              ),
                            ),
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.fromLTRB(18, 4, 18, 12),
                    child: totalsSection(),
                  ),
                  Container(
                    width: double.infinity,
                    padding: const EdgeInsets.fromLTRB(18, 10, 18, 14),
                    decoration: BoxDecoration(
                      color: footerBg,
                      borderRadius: BorderRadius.vertical(
                        bottom: Radius.circular(8),
                      ),
                    ),
                    child: Wrap(
                      alignment: WrapAlignment.end,
                      spacing: 10,
                      runSpacing: 8,
                      children: [
                        OutlinedButton(
                          onPressed: () => Navigator.pop(ctx),
                          style: OutlinedButton.styleFrom(
                            foregroundColor: const Color(0xFFC0392B),
                            side: const BorderSide(color: Color(0xFFC0392B)),
                            minimumSize: const Size(90, 44),
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(6),
                            ),
                          ),
                          child: const Text('Cancel'),
                        ),
                        Visibility(
                          visible: false,
                          child: ElevatedButton.icon(
                            onPressed: () {
                              setState(() {
                                _compAccCtrl.text = hmiTotal.toStringAsFixed(2);
                                _ownAccCtrl.text = ownTotal.toStringAsFixed(2);
                                _accAmtCtrl.text = (hmiTotal + ownTotal)
                                    .toStringAsFixed(2);
                              });
                              Navigator.pop(ctx);
                              _snack('Accessories details saved');
                            },
                            icon: const Icon(Icons.save_rounded, size: 17),
                            label: const Text('Save'),
                            style: ElevatedButton.styleFrom(
                              backgroundColor: _secondary,
                              foregroundColor: Colors.white,
                              minimumSize: const Size(100, 44),
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(6),
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          );
        },
      ),
    ).then((_) {
      hmiDiscountCtrl.dispose();
      ownDiscountCtrl.dispose();
    });
  }

  Widget _dialogField(
    String label,
    TextEditingController controller, {
    bool number = false,
    ValueChanged<String>? onChanged,
  }) {
    return TextField(
      controller: controller,
      keyboardType: number
          ? const TextInputType.numberWithOptions(decimal: true)
          : TextInputType.text,
      textAlign: number ? TextAlign.right : TextAlign.left,
      style: const TextStyle(fontSize: 12),
      onChanged: onChanged,
      decoration: _dlgDec().copyWith(labelText: label.isEmpty ? null : label),
    );
  }

  Widget _dialogAmountField(String label, String value) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    return InputDecorator(
      decoration: _dlgDec().copyWith(
        labelText: label,
        labelStyle: const TextStyle(
          fontSize: 10.5,
          color: Color(0xFF0D5BB5),
          fontWeight: FontWeight.w600,
        ),
      ),
      child: Align(
        alignment: Alignment.centerRight,
        child: Text(
          value,
          style: TextStyle(
            fontSize: 12,
            fontWeight: FontWeight.w600,
            color: isDark ? const Color(0xFFE8EDF5) : const Color(0xFF263238),
          ),
        ),
      ),
    );
  }

  Widget _dialogEditableAmountField(
    String label,
    TextEditingController controller,
    StateSetter setDlg,
  ) {
    return TextField(
      controller: controller,
      keyboardType: const TextInputType.numberWithOptions(decimal: true),
      textAlign: TextAlign.right,
      style: const TextStyle(fontSize: 12),
      onChanged: (_) => setDlg(() {}),
      decoration: _dlgDec().copyWith(
        labelText: label,
        labelStyle: const TextStyle(
          fontSize: 10.5,
          color: Color(0xFF0D5BB5),
          fontWeight: FontWeight.w600,
        ),
      ),
    );
  }

  // ── Bottom amounts ────────────────────────────────────────────────────────
  Widget _secBottomAmounts() => Column(
    children: [
      Row(
        children: [
          Expanded(child: _txt('Workshop INV No.', _workshopInvNo)),
          const SizedBox(width: 8),
          Expanded(child: _num('Workshop INV Amt', _workshopInvAmt)),
        ],
      ),
      _vg,
      Row(
        children: [
          Expanded(
            child: _dropMapField(
              'RTO City',
              _rtoCityId,
              _rtoCities,
              _onRtoCitySelected,
            ),
          ),
          const SizedBox(width: 4),
          _plusBtn(_showAddAccountDialog),
          const SizedBox(width: 12),
          Expanded(child: _txt('TRC', _trcCtrl)),
        ],
      ),
      _vg,
      _r3(
        Row(
          children: [
            Expanded(child: _num('Company Accessories', _compAccCtrl)),
            const SizedBox(width: 6),
            _plusBtn(_loadAccessoriesGrid),
          ],
        ),
        _num('Own Accessories', _ownAccCtrl),
        _num('Accessories Amount', _accAmtCtrl, ro: true),
      ),
      _vg,
      _r3(
        _num('Warranty', _warrantyCtrl),
        _num('RSA', _rsaCtrl),
        Row(
          children: [
            SizedBox(
              width: 72,
              child: _dropStrField(
                '',
                _sotType,
                ['SOT', 'Fitment', 'Painting', 'Labour Charge', 'Other Charge']
                    .map(
                      (t) => DropdownMenuItem(
                        value: t,
                        child: Text(t, style: _s13),
                      ),
                    )
                    .toList(),
                (v) => setState(() => _sotType = v!),
              ),
            ),
            const SizedBox(width: 4),
            Expanded(child: _num('', _sotAmtCtrl)),
          ],
        ),
      ),
      _vg,
      _r3(
        _num('Fast Tag', _fastTagCtrl),
        _num('TCS', _tcsCtrl),
        _num('Total', _totalCtrl, ro: true, bold: true),
      ),
    ],
  );

  // ── Receipts grid ─────────────────────────────────────────────────────────

  Widget _secReceipts() {
    final isDark = Theme.of(context).brightness == Brightness.dark;

    final cols = [
      'RNo',
      'Date',
      'Mode',
      'Cheque No.',
      'Cash',
      'Cheque',
      'UPI',
      'RTGS',
      'Wallet',
      'Card',
      'Received',
    ];

    final tableBackground = isDark ? const Color(0xFF15253A) : Colors.white;

    final alternateBackground = isDark
        ? const Color(0xFF1B2E45)
        : const Color(0xFFF6F9FF);

    final tableBorder = isDark ? const Color(0xFF34465C) : _border;

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        _vg,
        if (_loadingReceipts)
          const Padding(
            padding: EdgeInsets.symmetric(vertical: 16),
            child: Center(child: CircularProgressIndicator(strokeWidth: 2)),
          )
        else ...[
          SingleChildScrollView(
            scrollDirection: Axis.horizontal,
            child: Container(
              decoration: BoxDecoration(
                color: tableBackground,
                border: Border.all(color: tableBorder),
                borderRadius: BorderRadius.circular(6),
              ),
              clipBehavior: Clip.antiAlias,
              child: Column(
                children: [
                  // Keep the existing blue header.
                  Container(
                    color: _accent,
                    child: Row(children: cols.map((h) => _th(h)).toList()),
                  ),

                  if (_receiptRows.isEmpty)
                    Container(
                      color: tableBackground,
                      child: Row(children: cols.map((_) => _td('-')).toList()),
                    )
                  else
                    ..._receiptRows.asMap().entries.map((entry) {
                      final index = entry.key;
                      final row = entry.value;

                      final rno =
                          row['rcl_9']?.toString() ??
                          row['Rcl_9']?.toString() ??
                          '';

                      final date =
                          row['rcl_7']?.toString() ??
                          row['Rcl_7']?.toString() ??
                          '';

                      final mode =
                          row['rcl_16']?.toString() ??
                          row['rcl_66']?.toString() ??
                          '';

                      final chqno = row['rcl_13']?.toString() ?? '';
                      final cash = row['rcl_40']?.toString() ?? '0';
                      final chqAmt = row['Cheque']?.toString() ?? '0';
                      final upi = row['upi']?.toString() ?? '0';
                      final rtgs = row['Rtgs']?.toString() ?? '0';
                      final wallet = row['rcl_41']?.toString() ?? '0';
                      final card = row['rcl_42']?.toString() ?? '0';

                      final recv =
                          row['rcl_58']?.toString() ??
                          row['RCL_58']?.toString() ??
                          '0';

                      return Container(
                        color: index.isEven
                            ? tableBackground
                            : alternateBackground,
                        child: Row(
                          children: [
                            _td(rno),
                            _td(date),
                            _td(mode),
                            _td(chqno),
                            _td(cash),
                            _td(chqAmt),
                            _td(upi),
                            _td(rtgs),
                            _td(wallet),
                            _td(card),
                            _td(recv),
                          ],
                        ),
                      );
                    }),
                ],
              ),
            ),
          ),

          const SizedBox(height: 8),

          Wrap(
            spacing: 10,
            runSpacing: 8,
            children: [
              _rcTotalChip('Total Received', _receiptTotal),
              _rcTotalChip('Finance Amt', _receiptFinanceAmt),
              _rcTotalChip('Customer Amt', _receiptCustAmt),
            ],
          ),
        ],
      ],
    );
  }

  Widget _rcTotalChip(String label, double value) {
    final isDark = Theme.of(context).brightness == Brightness.dark;

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
      decoration: BoxDecoration(
        color: isDark ? const Color(0xFF203752) : const Color(0xFFEAF2FF),
        borderRadius: BorderRadius.circular(8),
        border: Border.all(
          color: isDark ? const Color(0xFF3B526E) : const Color(0xFFD3E3FA),
        ),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Text(
            label,
            style: TextStyle(
              fontSize: 11,
              fontWeight: FontWeight.w600,
              color: isDark ? const Color(0xFFCBD8E8) : const Color(0xFF3B5B88),
            ),
          ),
          const SizedBox(width: 6),
          Text(
            '₹ ${value.toStringAsFixed(2)}',
            style: TextStyle(
              fontSize: 12,
              fontWeight: FontWeight.w800,
              color: isDark ? const Color(0xFF8FC2FF) : const Color(0xFF0A3D91),
            ),
          ),
        ],
      ),
    );
  }

  Widget _th(String t) => Container(
    width: 80,
    padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 7),
    decoration: BoxDecoration(
      border: Border(right: BorderSide(color: Colors.white24, width: 0.5)),
    ),
    child: Text(
      t,
      style: const TextStyle(
        color: Colors.white,
        fontSize: 10,
        fontWeight: FontWeight.w700,
      ),
      maxLines: 1,
      overflow: TextOverflow.ellipsis,
    ),
  );

  Widget _td(String t) {
    final isDark = Theme.of(context).brightness == Brightness.dark;

    return Container(
      width: 80,
      padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 9),
      decoration: BoxDecoration(
        border: Border(
          right: BorderSide(
            color: isDark ? const Color(0xFF34465C) : _border,
            width: 0.5,
          ),
        ),
      ),
      child: Text(
        t,
        maxLines: 1,
        overflow: TextOverflow.ellipsis,
        style: TextStyle(
          fontSize: 10,
          color: isDark ? const Color(0xFFE2EAF5) : const Color(0xFF26364A),
        ),
      ),
    );
  }

  // ── Balances ──────────────────────────────────────────────────────────────
  Widget _secBalances() => Column(
    children: [
      _vg,
      Row(
        children: [
          Expanded(
            child: _num('HPN Received Amt', _hpnReceivedCtrl, ro: false),
          ),
          const SizedBox(width: 12),
          Expanded(child: _num('HPN Balance', _hpnBalanceCtrl, ro: true)),
        ],
      ),
      _vg,
      Row(
        children: [
          Expanded(
            child: _num(
              'Customer Received Amt',
              _customerReceivedCtrl,
              ro: false,
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: _num('Customer Balance', _customerBalanceCtrl, ro: true),
          ),
        ],
      ),
      _vg,
      Row(
        children: [
          Expanded(child: _num('Received Amt', _receivedCtrl, ro: false)),
          const SizedBox(width: 12),
          Expanded(child: _num('Balance', _balanceCtrl, ro: true, bold: true)),
        ],
      ),
    ],
  );

  // ── Remarks ───────────────────────────────────────────────────────────────
  Widget _secRemarks() => Column(
    children: [
      _vg,
      _txt('Remark', _remarkCtrl, maxLines: 3),
      _vg,
      _txt('Approval Remark', _appRemarkCtrl, maxLines: 2),
      _vg,
      _txt('Reject Remark', _rejRemarkCtrl, maxLines: 2),
    ],
  );

  // ═══════════════════════════════════════════════════════════════════════════
  //  SHARED FIELD BUILDERS
  // ═══════════════════════════════════════════════════════════════════════════
  static const Widget _vg = SizedBox(height: 10);
  static const TextStyle _s13 = TextStyle(
    fontSize: 13,
    fontWeight: FontWeight.w500,
  );

  Widget _lbl(String t) => Padding(
    padding: const EdgeInsets.only(bottom: 5),
    child: Text(
      t,
      style: TextStyle(
        fontSize: 11,
        fontWeight: FontWeight.w700,
        color: Theme.of(context).brightness == Brightness.dark
            ? Colors.white70
            : const Color(0xFF465266),
      ),
    ),
  );

  InputDecoration _dec(String label, {bool ro = false}) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final border = isDark
        ? Colors.white.withValues(alpha: 0.10)
        : const Color(0xFFD3E1F2);
    return InputDecoration(
      labelText: label.isEmpty ? null : label,
      labelStyle: TextStyle(
        fontSize: 10.5,
        fontWeight: FontWeight.w600,
        color: isDark ? Colors.white54 : const Color(0xFF61738C),
      ),
      floatingLabelStyle: const TextStyle(
        fontSize: 10.5,
        fontWeight: FontWeight.w700,
        color: Color(0xFF1F64C7),
      ),
      filled: true,
      fillColor: ro
          ? (isDark ? const Color(0xFF18283D) : const Color(0xFFF1F6FD))
          : (isDark ? const Color(0xFF122033) : const Color(0xFFFAFCFF)),
      border: OutlineInputBorder(
        borderRadius: BorderRadius.circular(11),
        borderSide: BorderSide(color: border),
      ),
      enabledBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(11),
        borderSide: BorderSide(color: border),
      ),
      focusedBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(11),
        borderSide: const BorderSide(color: Color(0xFF1675D1), width: 1.5),
      ),
      disabledBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(11),
        borderSide: BorderSide(color: border),
      ),
      contentPadding: const EdgeInsets.symmetric(horizontal: 13, vertical: 12),
      isDense: true,
    );
  }

  Widget _txt(
    String label,
    TextEditingController ctrl, {
    int maxLines = 1,
    TextInputType? inputType,
    List<TextInputFormatter>? inputFormatters,
    bool readOnly = false,
    String? Function(String?)? validator,
  }) => TextFormField(
    controller: ctrl,
    maxLines: maxLines,
    keyboardType: inputType,
    inputFormatters: inputFormatters,
    readOnly: readOnly,
    validator: validator,
    autovalidateMode: AutovalidateMode.onUserInteraction,
    style: _s13,
    decoration: _dec(label, ro: readOnly),
  );

  Widget _num(
    String label,
    TextEditingController ctrl, {
    bool ro = false,
    bool bold = false,
    ValueChanged<String>? onChanged,
  }) => TextFormField(
    controller: ctrl,
    readOnly: ro,
    onChanged: (value) {
      onChanged?.call(value);
      if (!ro) _recalculateAspNet();
    },
    keyboardType: const TextInputType.numberWithOptions(decimal: true),
    inputFormatters: [
      FilteringTextInputFormatter.allow(RegExp(r'^\d*\.?\d{0,2}')),
    ],
    textAlign: TextAlign.right,
    style: bold ? _s13.copyWith(fontWeight: FontWeight.w700) : _s13,
    decoration: _dec(label, ro: ro),
  );

  /// Searchable map-based dropdown — tapping opens a full search bottom sheet.
  Widget _dropMapField<T>(
    String label,
    T? value,
    List<Map<String, dynamic>> items,
    ValueChanged<T?> onChanged, {
    String Function(Map<String, dynamic>)? labelFn,
    bool disabled = false,
  }) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final displayLabel = value == null
        ? null
        : () {
            final match = items.firstWhere(
              (e) => e['data'] == value,
              orElse: () => <String, dynamic>{},
            );
            if (match.isEmpty) return null;
            return labelFn != null
                ? labelFn(match)
                : (match['value'] as String? ??
                      match['data']?.toString() ??
                      '');
          }();

    final field = InputDecorator(
      decoration: _dec(label, ro: disabled),
      child: Row(
        children: [
          Expanded(
            child: Text(
              displayLabel ?? 'SELECT',
              overflow: TextOverflow.ellipsis,
              style: TextStyle(
                fontSize: 13,
                fontWeight: FontWeight.w500,
                color: displayLabel == null
                    ? (isDark ? Colors.white38 : const Color(0xFF9AA3AF))
                    : disabled
                    ? (isDark ? Colors.white54 : const Color(0xFF6B7888))
                    : (isDark ? Colors.white : const Color(0xFF1A2740)),
              ),
            ),
          ),
          Icon(
            disabled ? Icons.lock_outline_rounded : Icons.search_rounded,
            size: disabled ? 15 : 18,
            color: disabled
                ? (isDark ? Colors.white24 : const Color(0xFFBBC5D1))
                : (isDark ? Colors.white38 : const Color(0xFF8A97AB)),
          ),
        ],
      ),
    );

    if (disabled) return field;

    return InkWell(
      onTap: () async {
        final strItems = items.map((e) {
          final lbl = labelFn != null
              ? labelFn(e)
              : (e['value'] as String? ?? e['data']?.toString() ?? '');
          return <String, dynamic>{'data': e['data'], 'value': lbl};
        }).toList();

        final result = await showModalBottomSheet<String>(
          context: context,
          isScrollControlled: true,
          backgroundColor: Colors.transparent,
          builder: (_) => _SearchSheet(
            items: strItems,
            labelKey: 'value',
            valueKey: 'data',
            hint: 'Search $label...',
            selectedValue: value?.toString(),
            title: label,
          ),
        );
        if (result == '__CLEAR__') {
          onChanged(null);
        } else if (result != null) {
          onChanged(result as T?);
        }
      },
      borderRadius: BorderRadius.circular(11),
      child: field,
    );
  }

  /// Searchable string-based dropdown — tapping opens a full search bottom sheet.
  Widget _dropStrField(
    String label,
    String value,
    List<DropdownMenuItem<String>> items,
    ValueChanged<String?> onChanged,
  ) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    // Convert DropdownMenuItems into the map format _SearchSheet expects
    final sheetItems = items.where((i) => i.value != null).map((i) {
      final txt = (i.child is Text)
          ? (i.child as Text).data ?? i.value!
          : i.value!;
      return <String, dynamic>{'data': i.value, 'value': txt};
    }).toList();

    return InkWell(
      onTap: () async {
        final result = await showModalBottomSheet<String>(
          context: context,
          isScrollControlled: true,
          backgroundColor: Colors.transparent,
          builder: (_) => _SearchSheet(
            items: sheetItems,
            labelKey: 'value',
            valueKey: 'data',
            hint: 'Search $label...',
            selectedValue: value,
            title: label,
          ),
        );
        if (result != null && result != '__CLEAR__') onChanged(result);
      },
      borderRadius: BorderRadius.circular(11),
      child: InputDecorator(
        decoration: _dec(label),
        child: Row(
          children: [
            Expanded(
              child: Text(
                value,
                overflow: TextOverflow.ellipsis,
                style: TextStyle(
                  fontSize: 13,
                  fontWeight: FontWeight.w500,
                  color: isDark ? Colors.white : const Color(0xFF1A2740),
                ),
              ),
            ),
            Icon(
              Icons.search_rounded,
              size: 18,
              color: isDark ? Colors.white38 : const Color(0xFF8A97AB),
            ),
          ],
        ),
      ),
    );
  }

  Widget _datePicker() => InkWell(
    onTap: _pickDate,
    borderRadius: BorderRadius.circular(12),
    child: InputDecorator(
      decoration: _dec('Date'),
      child: Row(
        children: [
          Container(
            width: 27,
            height: 27,
            decoration: BoxDecoration(
              color: const Color(0xFF1675D1).withValues(alpha: 0.10),
              borderRadius: BorderRadius.circular(7),
            ),
            child: const Icon(
              Icons.calendar_month_rounded,
              size: 16,
              color: Color(0xFF0D5BB5),
            ),
          ),
          const SizedBox(width: 8),
          Text(DateFormat('dd/MM/yyyy').format(_challanDate), style: _s13),
          const Spacer(),
          const Icon(
            Icons.edit_calendar_rounded,
            size: 16,
            color: Color(0xFF9AA5B5),
          ),
        ],
      ),
    ),
  );

  Widget _radio(String val, String group, ValueChanged<String?> fn) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        Radio<String>(
          value: val,
          groupValue: group,
          onChanged: fn,
          activeColor: isDark ? const Color(0xFF4DA3FF) : _primary,
          fillColor: WidgetStateProperty.resolveWith((states) {
            if (states.contains(WidgetState.selected)) {
              return isDark ? const Color(0xFF4DA3FF) : _primary;
            }
            return isDark ? const Color(0xFF7A8FA6) : const Color(0xFF8899BB);
          }),
          materialTapTargetSize: MaterialTapTargetSize.shrinkWrap,
          visualDensity: const VisualDensity(horizontal: -4, vertical: -4),
        ),
        Text(
          val,
          style: TextStyle(
            fontSize: 10,
            fontWeight: FontWeight.w600,
            color: isDark ? Colors.white70 : null,
          ),
        ),
      ],
    );
  }

  Widget _chk(String label, bool val, ValueChanged<bool?> fn) => Row(
    mainAxisSize: MainAxisSize.min,
    children: [
      Checkbox(
        value: val,
        onChanged: fn,
        activeColor: _primary,
        materialTapTargetSize: MaterialTapTargetSize.shrinkWrap,
        visualDensity: const VisualDensity(horizontal: -3, vertical: -3),
      ),
      Text(
        label,
        style: const TextStyle(fontSize: 11.5, fontWeight: FontWeight.w600),
      ),
      const SizedBox(width: 6),
    ],
  );

  Widget _plusBtn(VoidCallback onTap) => Material(
    color: Colors.transparent,
    child: InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(10),
      child: Container(
        width: 38,
        height: 42,
        decoration: BoxDecoration(
          gradient: const LinearGradient(
            colors: [Color(0xFF0A1B32), Color(0xFF1675D1)],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
          borderRadius: BorderRadius.circular(10),
          boxShadow: [
            BoxShadow(
              color: const Color(0xFF0A1B32).withValues(alpha: 0.18),
              blurRadius: 7,
              offset: const Offset(0, 3),
            ),
          ],
        ),
        child: const Icon(Icons.add_rounded, color: Colors.white, size: 20),
      ),
    ),
  );

  Widget _loadBox() => Container(
    height: 42,
    decoration: BoxDecoration(
      color: Theme.of(context).brightness == Brightness.dark
          ? const Color(0xFF1D2631)
          : const Color(0xFFF8FAFC),
      border: Border.all(
        color: Theme.of(context).brightness == Brightness.dark
            ? Colors.white12
            : const Color(0xFFDCE2EA),
      ),
      borderRadius: BorderRadius.circular(10),
    ),
    child: const Padding(
      padding: EdgeInsets.symmetric(horizontal: 12, vertical: 11),
      child: LinearProgressIndicator(minHeight: 3),
    ),
  );

  Widget _r3(Widget a, Widget b, Widget c) => LayoutBuilder(
    builder: (context, constraints) {
      final stacked = constraints.maxWidth < 800;
      if (stacked) {
        return Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [a, _vg, b, _vg, c],
        );
      }
      return Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Expanded(child: a),
          const SizedBox(width: 12),
          Expanded(child: b),
          const SizedBox(width: 12),
          Expanded(child: c),
        ],
      );
    },
  );

  Widget _r4(Widget a, Widget b, Widget c, Widget d) => LayoutBuilder(
    builder: (context, constraints) {
      if (constraints.maxWidth < 600) {
        return Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [a, _vg, b, _vg, c, _vg, d],
        );
      }
      if (constraints.maxWidth < 900) {
        return Column(
          children: [
            Row(
              children: [
                Expanded(child: a),
                const SizedBox(width: 10),
                Expanded(child: b),
              ],
            ),
            _vg,
            Row(
              children: [
                Expanded(child: c),
                const SizedBox(width: 10),
                Expanded(child: d),
              ],
            ),
          ],
        );
      }
      return Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Expanded(child: a),
          const SizedBox(width: 10),
          Expanded(child: b),
          const SizedBox(width: 10),
          Expanded(child: c),
          const SizedBox(width: 10),
          Expanded(child: d),
        ],
      );
    },
  );

  // ── Customer bottom sheet ─────────────────────────────────────────────────
  void _openCustomerSheet() async {
    final result = await showModalBottomSheet<String>(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (_) => _SearchSheet(
        items: _customers,
        labelKey: 'value',
        valueKey: 'data',
        hint: 'Search customer name...',
        selectedValue: _custId,
        title: 'Customer Name',
      ),
    );
    if (result != null && result != '__CLEAR__') {
      _onCustomerSelected(result);
    } else if (result == '__CLEAR__') {
      setState(() {
        _custId = null;
        _addressCtrl.clear();
        _mobileCtrl.clear();
        _panCtrl.clear();
        _aadharCtrl.clear();
        _gstinCtrl.clear();
        _fatherCtrl.clear();
        _emailCtrl.clear();
        _ageCtrl.clear();
        _nomineeCtrl.clear();
        _scCtrl.clear();
        _tlCtrl.clear();
        _managerCtrl.clear();
      });
    }
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// Searchable selection bottom sheet
// ─────────────────────────────────────────────────────────────────────────────
class _SearchSheet extends StatefulWidget {
  final List<Map<String, dynamic>> items;
  final String labelKey, valueKey, hint;
  final String? selectedValue;
  final String title;

  const _SearchSheet({
    required this.items,
    required this.labelKey,
    required this.valueKey,
    required this.hint,
    required this.title,
    this.selectedValue,
  });

  @override
  State<_SearchSheet> createState() => _SearchSheetState();
}

class _SearchSheetState extends State<_SearchSheet> {
  late List<Map<String, dynamic>> _filtered;
  final _searchCtrl = TextEditingController();
  final _focusNode = FocusNode();

  static const Color _accent = Color(0xFF0D5BB5);
  static const Color _primary = Color(0xFF0A1B32);

  @override
  void initState() {
    super.initState();
    _filtered = widget.items;
  }

  @override
  void dispose() {
    _searchCtrl.dispose();
    _focusNode.dispose();
    super.dispose();
  }

  void _filter(String q) {
    final lq = q.toLowerCase().trim();
    setState(() {
      _filtered = lq.isEmpty
          ? widget.items
          : widget.items
                .where(
                  (e) => (e[widget.labelKey] as String? ?? '')
                      .toLowerCase()
                      .contains(lq),
                )
                .toList();
    });
  }

  @override
  Widget build(BuildContext ctx) {
    final isDark = Theme.of(ctx).brightness == Brightness.dark;
    final bg = isDark ? const Color(0xFF131E2D) : Colors.white;
    final surfaceBg = isDark
        ? const Color(0xFF1A2637)
        : const Color(0xFFF4F8FF);
    final borderColor = isDark ? Colors.white12 : const Color(0xFFD3E1F2);
    final textColor = isDark ? Colors.white : const Color(0xFF1A2740);
    final subColor = isDark ? Colors.white38 : const Color(0xFF8A97AB);

    return DraggableScrollableSheet(
      initialChildSize: 0.75,
      minChildSize: 0.45,
      maxChildSize: 0.95,
      expand: false,
      builder: (_, sc) => Container(
        decoration: BoxDecoration(
          color: bg,
          borderRadius: const BorderRadius.vertical(top: Radius.circular(20)),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withValues(alpha: 0.22),
              blurRadius: 28,
              offset: const Offset(0, -6),
            ),
          ],
        ),
        child: Column(
          children: [
            // ── drag handle ─────────────────────────────────────────
            Center(
              child: Container(
                width: 40,
                height: 4,
                margin: const EdgeInsets.only(top: 10, bottom: 4),
                decoration: BoxDecoration(
                  color: isDark ? Colors.white24 : const Color(0xFFCDD7E8),
                  borderRadius: BorderRadius.circular(2),
                ),
              ),
            ),

            // ── header ──────────────────────────────────────────────
            Container(
              margin: const EdgeInsets.fromLTRB(14, 6, 14, 10),
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
              decoration: BoxDecoration(
                gradient: const LinearGradient(
                  colors: [Color(0xFF082B5C), Color(0xFF1675D1)],
                  begin: Alignment.centerLeft,
                  end: Alignment.centerRight,
                ),
                borderRadius: BorderRadius.circular(14),
              ),
              child: Row(
                children: [
                  Container(
                    width: 34,
                    height: 34,
                    decoration: BoxDecoration(
                      color: Colors.white.withValues(alpha: 0.15),
                      borderRadius: BorderRadius.circular(10),
                    ),
                    child: const Icon(
                      Icons.search_rounded,
                      color: Colors.white,
                      size: 18,
                    ),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          widget.title,
                          style: const TextStyle(
                            color: Colors.white,
                            fontSize: 14,
                            fontWeight: FontWeight.w800,
                          ),
                        ),
                        const SizedBox(height: 2),
                        Text(
                          '${_filtered.length} of ${widget.items.length} items',
                          style: TextStyle(
                            color: Colors.white.withValues(alpha: 0.70),
                            fontSize: 10,
                            fontWeight: FontWeight.w500,
                          ),
                        ),
                      ],
                    ),
                  ),
                  // Clear selection button
                  if (widget.selectedValue != null &&
                      widget.selectedValue!.isNotEmpty)
                    InkWell(
                      onTap: () => Navigator.pop(ctx, '__CLEAR__'),
                      borderRadius: BorderRadius.circular(8),
                      child: Container(
                        padding: const EdgeInsets.symmetric(
                          horizontal: 10,
                          vertical: 6,
                        ),
                        decoration: BoxDecoration(
                          color: Colors.white.withValues(alpha: 0.15),
                          borderRadius: BorderRadius.circular(8),
                          border: Border.all(
                            color: Colors.white.withValues(alpha: 0.25),
                          ),
                        ),
                        child: const Text(
                          'Clear',
                          style: TextStyle(
                            color: Colors.white,
                            fontSize: 11,
                            fontWeight: FontWeight.w700,
                          ),
                        ),
                      ),
                    ),
                  const SizedBox(width: 4),
                  InkWell(
                    onTap: () => Navigator.pop(ctx),
                    borderRadius: BorderRadius.circular(8),
                    child: Container(
                      width: 30,
                      height: 30,
                      decoration: BoxDecoration(
                        color: Colors.white.withValues(alpha: 0.15),
                        borderRadius: BorderRadius.circular(8),
                      ),
                      child: const Icon(
                        Icons.close_rounded,
                        color: Colors.white,
                        size: 16,
                      ),
                    ),
                  ),
                ],
              ),
            ),

            // ── search box ──────────────────────────────────────────
            Padding(
              padding: const EdgeInsets.fromLTRB(14, 0, 14, 10),
              child: TextField(
                controller: _searchCtrl,
                focusNode: _focusNode,
                onChanged: _filter,
                autofocus: true,
                style: TextStyle(
                  fontSize: 13.5,
                  color: textColor,
                  fontWeight: FontWeight.w500,
                ),
                decoration: InputDecoration(
                  hintText: widget.hint,
                  hintStyle: TextStyle(fontSize: 13, color: subColor),
                  prefixIcon: Icon(
                    Icons.search_rounded,
                    size: 20,
                    color: _accent,
                  ),
                  suffixIcon: _searchCtrl.text.isNotEmpty
                      ? IconButton(
                          icon: Icon(
                            Icons.clear_rounded,
                            size: 18,
                            color: subColor,
                          ),
                          onPressed: () {
                            _searchCtrl.clear();
                            _filter('');
                          },
                        )
                      : null,
                  filled: true,
                  fillColor: surfaceBg,
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(12),
                    borderSide: BorderSide(color: borderColor),
                  ),
                  enabledBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(12),
                    borderSide: BorderSide(color: borderColor),
                  ),
                  focusedBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(12),
                    borderSide: const BorderSide(color: _accent, width: 1.5),
                  ),
                  contentPadding: const EdgeInsets.symmetric(
                    horizontal: 14,
                    vertical: 12,
                  ),
                  isDense: true,
                ),
              ),
            ),

            // ── divider ─────────────────────────────────────────────
            Divider(height: 1, color: borderColor),

            // ── list ────────────────────────────────────────────────
            Expanded(
              child: _filtered.isEmpty
                  ? Center(
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Icon(
                            Icons.search_off_rounded,
                            size: 48,
                            color: isDark
                                ? Colors.white24
                                : const Color(0xFFBBC8DA),
                          ),
                          const SizedBox(height: 10),
                          Text(
                            'No results found',
                            style: TextStyle(
                              fontSize: 13,
                              color: subColor,
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                          const SizedBox(height: 4),
                          Text(
                            'Try a different search term',
                            style: TextStyle(fontSize: 11, color: subColor),
                          ),
                        ],
                      ),
                    )
                  : ListView.separated(
                      controller: sc,
                      padding: const EdgeInsets.fromLTRB(14, 6, 14, 24),
                      itemCount: _filtered.length,
                      separatorBuilder: (_, __) =>
                          Divider(height: 1, color: borderColor),
                      itemBuilder: (_, i) {
                        final item = _filtered[i];
                        final lbl = item[widget.labelKey] as String? ?? '';
                        final val = item[widget.valueKey]?.toString();
                        final isSelected = val == widget.selectedValue;

                        return InkWell(
                          onTap: () => Navigator.pop(ctx, val),
                          borderRadius: BorderRadius.circular(10),
                          child: Container(
                            margin: const EdgeInsets.symmetric(vertical: 3),
                            padding: const EdgeInsets.symmetric(
                              horizontal: 12,
                              vertical: 11,
                            ),
                            decoration: BoxDecoration(
                              color: isSelected
                                  ? (isDark
                                        ? const Color(0xFF153358)
                                        : const Color(0xFFE8F0FE))
                                  : Colors.transparent,
                              borderRadius: BorderRadius.circular(10),
                              border: isSelected
                                  ? Border.all(
                                      color: isDark
                                          ? const Color(0xFF2A5BAD)
                                          : const Color(0xFFB8D0F8),
                                    )
                                  : null,
                            ),
                            child: Row(
                              children: [
                                // index badge
                                Container(
                                  width: 26,
                                  height: 26,
                                  decoration: BoxDecoration(
                                    color: isSelected
                                        ? _accent
                                        : (isDark
                                              ? const Color(0xFF1F3347)
                                              : const Color(0xFFEEF3FB)),
                                    borderRadius: BorderRadius.circular(7),
                                  ),
                                  alignment: Alignment.center,
                                  child: isSelected
                                      ? const Icon(
                                          Icons.check_rounded,
                                          color: Colors.white,
                                          size: 14,
                                        )
                                      : Text(
                                          '${i + 1}',
                                          style: TextStyle(
                                            fontSize: 10,
                                            fontWeight: FontWeight.w700,
                                            color: isDark
                                                ? Colors.white54
                                                : const Color(0xFF6B82A0),
                                          ),
                                        ),
                                ),
                                const SizedBox(width: 10),
                                Expanded(
                                  child: Text(
                                    lbl,
                                    style: TextStyle(
                                      fontSize: 13.5,
                                      fontWeight: isSelected
                                          ? FontWeight.w700
                                          : FontWeight.w500,
                                      color: isSelected
                                          ? (isDark ? Colors.white : _primary)
                                          : textColor,
                                    ),
                                  ),
                                ),
                                if (isSelected)
                                  Container(
                                    padding: const EdgeInsets.symmetric(
                                      horizontal: 8,
                                      vertical: 3,
                                    ),
                                    decoration: BoxDecoration(
                                      color: _accent,
                                      borderRadius: BorderRadius.circular(6),
                                    ),
                                    child: const Text(
                                      'Selected',
                                      style: TextStyle(
                                        color: Colors.white,
                                        fontSize: 9.5,
                                        fontWeight: FontWeight.w700,
                                      ),
                                    ),
                                  ),
                              ],
                            ),
                          ),
                        );
                      },
                    ),
            ),
          ],
        ),
      ),
    );
  }
}

// ─────────────────────────────────────────────────────────────────────────────
class UpperCaseFormatter extends TextInputFormatter {
  @override
  TextEditingValue formatEditUpdate(TextEditingValue o, TextEditingValue n) =>
      n.copyWith(text: n.text.toUpperCase(), selection: n.selection);
}
